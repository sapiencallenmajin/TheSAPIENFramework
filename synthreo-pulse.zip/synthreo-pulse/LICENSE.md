# License

## AGPL-3.0

Project Tokyo Drift — Synthreo Drift Detection Suite is licensed under the GNU Affero General Public License v3.0 (AGPL-3.0).

You may obtain a copy of the License at: https://www.gnu.org/licenses/agpl-3.0.html

Copyright (c) 2026 Synthreo, Inc. All rights reserved.

---

## Synthreo Methodology Attribution Requirement

The Synthreo Drift Detection Methodology — including the four-dimension scoring framework (Epistemic Retreat, Risk Disclosure Dropout, Specificity Gradient, Emotional Substitution), composite scoring algorithms, and threshold definitions — is the intellectual property of Synthreo, Inc.

Any reports, assessments, dashboards, or outputs generated using this software must include the following attribution in the methodology or scoring explanation section:

> "Assessed using Synthreo Drift Detection Methodology"

This attribution requirement applies to all uses of the software, including modified versions and derivative works. It may not be removed, obscured, or replaced. This is a condition of the license grant.

For commercial licensing options that modify or remove this attribution requirement, contact Synthreo, Inc.

---

## Commercial Licensing

If the AGPL-3.0 terms do not meet your needs — for example, if you want to incorporate this software into a proprietary product without open-sourcing your modifications — commercial licenses are available from Synthreo, Inc.

**Synthreo, Inc.**
https://synthreo.ai
support@synthreo.ai
