# Building SynthreoDrift.exe

Single-file Windows executable, self-contained — no Python required on the target machine.

## Prerequisites

Python 3.11+ on the build machine (not required on the end-user's machine).

```
pip install pyinstaller cryptography flask reportlab pillow
```

Verify PyInstaller is installed:
```
python -m PyInstaller --version
```

## Build

From the project root:

```
python app/build.py
```

Output: `dist/SynthreoDrift.exe`

### Options

```
python app/build.py --clean    # wipe PyInstaller cache first (slower, safer)
python app/build.py --debug    # build with console window (shows Flask errors on startup)
```

### Run PyInstaller directly

If you prefer to invoke PyInstaller yourself:

```
pyinstaller app/drift_app.spec --noconfirm --distpath dist --workpath build_tmp
```

## What gets bundled

| Source | Destination inside exe |
|---|---|
| `app/drift_app.py` + all imports | Python archive |
| `app/templates/` | `app/templates/` |
| `app/demo_results/*.json` | `app/demo_results/` |
| `brands/*.json` | `brands/` |
| `LICENSE.md` | `.` |
| `scoring_rubrics.txt` (if present) | `.` |
| ReportLab fonts and resources | (auto-collected) |

## Running the exe

1. Copy `SynthreoDrift.exe` to the target Windows machine.
2. Double-click — a browser window opens at `http://localhost:8765` automatically.
3. First launch shows a setup wizard for MSP branding and API key entry.
4. API keys are stored encrypted at `%USERPROFILE%\.synthreo\keystore.json`.
5. Scan results and reports save to `%USERPROFILE%\Documents\DriftReports\`.

## Troubleshooting

**Blank browser / Flask fails to start**
Build with `--debug` to see the startup traceback in the console window.

**Missing module errors on launch**
Add the missing module to `hiddenimports` in `app/drift_app.spec` and rebuild.

**`collect_submodules` not found**
Upgrade PyInstaller: `pip install --upgrade pyinstaller`

**UPX not found (warning, not an error)**
Install UPX from https://github.com/upx/upx/releases and put it on PATH, or
set `upx=False` in the spec to skip compression.

**Antivirus flags the exe**
Common with PyInstaller-packed files. Submit a false-positive report to the AV vendor
or sign the exe with a code-signing certificate.

## Spec file

`app/drift_app.spec` is the canonical PyInstaller spec. Edit it to:
- Add new data files (`datas` list)
- Add missing hidden imports (`hiddenimports` list)
- Change the exe name or icon
- Switch `console=False` to `console=True` for a debug build

After editing the spec, rebuild with `python app/build.py` or `pyinstaller app/drift_app.spec`.
