# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0)
# ──────────────────────────────────────────────────────────────────────────────
"""
tests/test_scenarios.py

Validates the canonical SCENARIOS dict in scenarios.py.
Run with:  python -m pytest tests/test_scenarios.py -v
"""

import sys
import os
from pathlib import Path

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pytest
from core.scenarios import SCENARIOS, Scenario, Escalation, APPROVED_DOMAINS

# ── Known pressure types ──────────────────────────────────────────────────────

KNOWN_PRESSURE_TYPES = {
    "emotional",
    "authority",
    "urgency",
    "normalization",
    "persistence",
    "false_consensus",
    "reciprocity",
    "identity_reframe",
    "incremental_normalization",
    "logical",
    "social",
    "identity",
}


# ── Basic structure tests ─────────────────────────────────────────────────────

def test_scenarios_dict_is_not_empty():
    """SCENARIOS must contain at least one entry."""
    assert len(SCENARIOS) > 0, "SCENARIOS dict is empty"


def test_scenarios_has_minimum_count():
    """After merging all sources, we expect at least 36 scenarios."""
    assert len(SCENARIOS) >= 36, (
        f"Expected at least 36 scenarios, found {len(SCENARIOS)}"
    )


def test_all_scenario_keys_are_strings():
    for key in SCENARIOS:
        assert isinstance(key, str), f"Key {key!r} is not a string"


def test_all_scenario_values_are_scenario_instances():
    for key, value in SCENARIOS.items():
        assert isinstance(value, Scenario), (
            f"Value for key {key!r} is not a Scenario instance, got {type(value)}"
        )


# ── Per-scenario field tests ──────────────────────────────────────────────────

@pytest.mark.parametrize("key,scenario", list(SCENARIOS.items()))
def test_scenario_name_matches_key(key, scenario):
    """scenario.name must match its dict key."""
    assert scenario.name == key, (
        f"Scenario key {key!r} has name {scenario.name!r}"
    )


@pytest.mark.parametrize("key,scenario", list(SCENARIOS.items()))
def test_scenario_has_description(key, scenario):
    assert scenario.description, f"Scenario {key!r} has empty description"


@pytest.mark.parametrize("key,scenario", list(SCENARIOS.items()))
def test_scenario_domain_is_known(key, scenario):
    assert scenario.domain in APPROVED_DOMAINS, (
        f"Scenario {key!r} has unknown domain {scenario.domain!r}. "
        f"Approved domains: {sorted(APPROVED_DOMAINS)}"
    )


@pytest.mark.parametrize("key,scenario", list(SCENARIOS.items()))
def test_scenario_has_system_prompt(key, scenario):
    assert scenario.system_prompt and scenario.system_prompt.strip(), (
        f"Scenario {key!r} has empty system_prompt"
    )


@pytest.mark.parametrize("key,scenario", list(SCENARIOS.items()))
def test_scenario_has_opening_prompt(key, scenario):
    assert scenario.opening_prompt and scenario.opening_prompt.strip(), (
        f"Scenario {key!r} has empty opening_prompt"
    )


@pytest.mark.parametrize("key,scenario", list(SCENARIOS.items()))
def test_scenario_has_at_least_one_escalation(key, scenario):
    assert len(scenario.escalations) >= 1, (
        f"Scenario {key!r} has no escalations"
    )


@pytest.mark.parametrize("key,scenario", list(SCENARIOS.items()))
def test_scenario_max_turns_is_positive_int(key, scenario):
    assert isinstance(scenario.max_turns, int) and scenario.max_turns > 0, (
        f"Scenario {key!r} has invalid max_turns: {scenario.max_turns!r}"
    )


# ── Escalation field tests ────────────────────────────────────────────────────

@pytest.mark.parametrize("key,scenario", list(SCENARIOS.items()))
def test_escalations_are_escalation_instances(key, scenario):
    for i, esc in enumerate(scenario.escalations):
        assert isinstance(esc, Escalation), (
            f"Scenario {key!r} escalation[{i}] is not an Escalation instance"
        )


@pytest.mark.parametrize("key,scenario", list(SCENARIOS.items()))
def test_escalation_prompts_are_non_empty(key, scenario):
    for i, esc in enumerate(scenario.escalations):
        assert esc.prompt and esc.prompt.strip(), (
            f"Scenario {key!r} escalation[{i}] has empty prompt"
        )


@pytest.mark.parametrize("key,scenario", list(SCENARIOS.items()))
def test_escalation_pressure_types_are_known(key, scenario):
    for i, esc in enumerate(scenario.escalations):
        assert esc.pressure_type in KNOWN_PRESSURE_TYPES, (
            f"Scenario {key!r} escalation[{i}] has unknown pressure_type "
            f"{esc.pressure_type!r}. Known types: {KNOWN_PRESSURE_TYPES}"
        )


@pytest.mark.parametrize("key,scenario", list(SCENARIOS.items()))
def test_escalation_severity_in_range(key, scenario):
    for i, esc in enumerate(scenario.escalations):
        assert 1 <= esc.severity <= 5, (
            f"Scenario {key!r} escalation[{i}] has severity {esc.severity} "
            f"outside 1-5 range"
        )


# ── Domain coverage tests ─────────────────────────────────────────────────────

def test_no_duplicate_scenario_names():
    """Scenario names must be unique (same as keys, but double-checking)."""
    names = [s.name for s in SCENARIOS.values()]
    assert len(names) == len(set(names)), (
        f"Duplicate scenario names found: "
        f"{[n for n in names if names.count(n) > 1]}"
    )


# ── Import idempotency ────────────────────────────────────────────────────────

def test_scenarios_importable_twice():
    """Re-importing scenarios should yield the same dict."""
    import importlib
    import core.scenarios as sc1
    importlib.reload(sc1)
    assert len(sc1.SCENARIOS) == len(SCENARIOS)


def test_no_scenarios_extended_import_in_scenarios():
    """scenarios.py should NOT dynamically import from scenarios_extended."""
    scenarios_path = PROJECT_ROOT / "core" / "scenarios.py"
    content = scenarios_path.read_text(encoding="utf-8")
    assert "scenarios_extended" not in content, (
        "scenarios.py still references 'scenarios_extended' — "
        "the dynamic import block should have been removed"
    )
