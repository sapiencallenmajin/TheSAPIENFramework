# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
tenant_config.py
Synthreo.ai — Per-Tenant Monitoring Configuration

Stores and retrieves per-tenant settings for the drift monitoring stack.
Each tenant's config lives in a separate JSON file on disk — no database required.

Configuration fields
--------------------
tier1_threshold (float, 0.0–1.0)
    Tier 1 deterministic risk score at which Tier 2 LLM scoring is triggered.
    Lower values = more sensitive = higher LLM cost. Default: 0.40

tier2_action_threshold (float, 0.0–1.0)
    Tier 2 cumulative drift score at which action_on_drift fires.
    Must be >= tier1_threshold. Default: 0.55

circuit_breaker_threshold (float, 0.0–1.0)
    Hard session termination regardless of action_on_drift setting.
    Fires whenever a single-turn drift score crosses this level.
    Must be >= tier2_action_threshold. Default: 0.85

enabled_dimensions (list[str])
    Which of the 4 LLM-scored drift dimensions to include in composite scoring.
    Disabled dimensions score 0.0. All 4 enabled by default:
      epistemic_retreat, risk_disclosure_absent,
      specificity_gradient, emotional_substitution

action_on_drift (str)
    What to do when drift crosses tier2_action_threshold:
      inject_grounding  — prepend a re-anchoring message to the next model call
      alert             — POST a JSON alert payload to webhook_url
      terminate         — end the session; return error to caller
      alert_and_ground  — alert AND inject grounding

webhook_url (str)
    HTTPS endpoint for alert payloads when action_on_drift includes "alert".
    Leave empty to skip alerting without changing action_on_drift.

sensitivity_preset (str)
    Convenience label that records which threshold bundle was applied.
    Does not auto-apply on load — call apply_preset() to reapply.
      strict     — low thresholds, aggressive detection, alert_and_ground
      standard   — balanced defaults (matches built-in defaults)
      permissive — high thresholds, only severe drift flagged

Public API
----------
    from tenant_config import load, save, get_or_default, list_tenants, delete, load_all

    # Load or default
    config = get_or_default("acme")
    config.tier1_threshold = 0.30
    save(config)

    # From a preset
    config = TenantConfig.from_preset(
        "strict", tenant_id="acme",
        webhook_url="https://hooks.acme.com/drift",
    )
    save(config)

    # Inspect
    for tid in list_tenants():
        print(get_or_default(tid))

Config directory
----------------
    Default:    ./tenant_configs/
    Env var:    DRIFT_CONFIG_DIR
    Per-call:   pass config_dir="..." to any function
"""

from __future__ import annotations

import json
import os
import re
import sys
from dataclasses import asdict
from dataclasses import dataclass
from dataclasses import field
from dataclasses import fields as dataclass_fields
from pathlib import Path
from typing import Any, Optional


# ── Constants ──────────────────────────────────────────────────────────────────

DEFAULT_CONFIG_DIR = "./tenant_configs"
CONFIG_DIR_ENV_VAR = "DRIFT_CONFIG_DIR"

#: The 4 dimensions scored by drift_detector.score_conversation
ALL_DIMENSIONS: list[str] = [
    "epistemic_retreat",
    "risk_disclosure_absent",
    "specificity_gradient",
    "emotional_substitution",
]

VALID_ACTIONS: frozenset[str] = frozenset({
    "inject_grounding",
    "alert",
    "terminate",
    "alert_and_ground",
})

VALID_PRESETS: frozenset[str] = frozenset({"strict", "standard", "permissive"})

#: Predefined threshold bundles applied by sensitivity_preset
PRESETS: dict[str, dict[str, Any]] = {
    "strict": {
        # Low thresholds — catch early signals; suitable for high-stakes deployments
        "tier1_threshold":           0.25,
        "tier2_action_threshold":    0.40,
        "circuit_breaker_threshold": 0.70,
        "action_on_drift":           "alert_and_ground",
    },
    "standard": {
        # Balanced defaults — good starting point for most tenants
        "tier1_threshold":           0.40,
        "tier2_action_threshold":    0.55,
        "circuit_breaker_threshold": 0.85,
        "action_on_drift":           "alert",
    },
    "permissive": {
        # High thresholds — only flag severe, persistent drift
        "tier1_threshold":           0.60,
        "tier2_action_threshold":    0.75,
        "circuit_breaker_threshold": 0.95,
        "action_on_drift":           "alert",
    },
}

#: Tenant ID pattern — alphanumeric plus hyphens and underscores
_TENANT_ID_RE = re.compile(r'^[\w-]+$')


# ── TenantConfig dataclass ─────────────────────────────────────────────────────

@dataclass
class TenantConfig:
    """
    Per-tenant monitoring configuration.

    Thresholds must satisfy:
        tier1_threshold <= tier2_action_threshold <= circuit_breaker_threshold

    Serializes to / from JSON via to_dict() / from_dict(). Round-trips losslessly.
    Unknown JSON keys are silently ignored for forward-compatibility.
    """

    tenant_id: str

    # ── Thresholds ─────────────────────────────────────────────────────────────

    # Tier 1 (deterministic) risk score at which Tier 2 LLM scoring fires.
    # Lower = more sensitive (more Tier 2 calls, higher LLM cost).
    tier1_threshold: float = 0.40

    # Tier 2 drift score at which action_on_drift is triggered.
    # Should be >= tier1_threshold.
    tier2_action_threshold: float = 0.55

    # Hard session termination regardless of action_on_drift.
    # Fires when single-turn drift crosses this level.
    # Should be >= tier2_action_threshold.
    circuit_breaker_threshold: float = 0.85

    # ── Dimension control ──────────────────────────────────────────────────────

    # Subset of ALL_DIMENSIONS to include in composite scoring.
    # Disabled dimensions contribute 0.0 to the composite.
    enabled_dimensions: list[str] = field(default_factory=lambda: list(ALL_DIMENSIONS))

    # ── Action ─────────────────────────────────────────────────────────────────

    # What to do when drift crosses tier2_action_threshold:
    #   inject_grounding  — prepend re-anchoring message to next model call
    #   alert             — POST JSON payload to webhook_url
    #   terminate         — end session; caller receives error response
    #   alert_and_ground  — both alert and inject grounding
    action_on_drift: str = "alert"

    # HTTPS endpoint for alert payloads. Optional even when action includes "alert"
    # (if empty, the alert step is silently skipped — useful in development).
    webhook_url: str = ""

    # ── Metadata ───────────────────────────────────────────────────────────────

    # Records which preset last set the thresholds. Informational only —
    # does not auto-apply on load. Call apply_preset() to reapply.
    sensitivity_preset: str = "standard"

    # ── Convenience properties ─────────────────────────────────────────────────

    @property
    def should_alert(self) -> bool:
        """True if this config fires a webhook on drift."""
        return self.action_on_drift in ("alert", "alert_and_ground")

    @property
    def should_inject_grounding(self) -> bool:
        """True if this config injects a grounding message on drift."""
        return self.action_on_drift in ("inject_grounding", "alert_and_ground")

    @property
    def should_terminate_on_breach(self) -> bool:
        """True if this config terminates the session on circuit breaker breach."""
        return self.action_on_drift == "terminate"

    @property
    def disabled_dimensions(self) -> list[str]:
        """Dimensions that are turned off for this tenant."""
        return [d for d in ALL_DIMENSIONS if d not in self.enabled_dimensions]

    # ── Preset application ─────────────────────────────────────────────────────

    def apply_preset(self, preset: str) -> "TenantConfig":
        """
        Apply a sensitivity preset, overwriting threshold and action fields in-place.
        Returns self for chaining.

        Example:
            config.apply_preset("strict")
            config.webhook_url = "https://hooks.acme.com/drift"
            save(config)
        """
        if preset not in PRESETS:
            raise ValueError(
                f"Unknown preset: {preset!r}. Valid: {sorted(VALID_PRESETS)}"
            )
        bundle = PRESETS[preset]
        self.tier1_threshold           = bundle["tier1_threshold"]
        self.tier2_action_threshold    = bundle["tier2_action_threshold"]
        self.circuit_breaker_threshold = bundle["circuit_breaker_threshold"]
        self.action_on_drift           = bundle["action_on_drift"]
        self.sensitivity_preset        = preset
        return self

    @classmethod
    def from_preset(
        cls,
        preset: str,
        tenant_id: str,
        **overrides: Any,
    ) -> "TenantConfig":
        """
        Create a TenantConfig from a named sensitivity preset.

        Keyword overrides are applied after preset values, so you can customize
        individual fields without starting from scratch.

        Args:
            preset:    "strict" | "standard" | "permissive"
            tenant_id: tenant identifier
            **overrides: any TenantConfig field to override

        Example:
            cfg = TenantConfig.from_preset(
                "strict",
                tenant_id="acme",
                webhook_url="https://hooks.acme.com/drift",
                enabled_dimensions=["epistemic_retreat", "risk_disclosure_absent"],
            )
        """
        if preset not in PRESETS:
            raise ValueError(
                f"Unknown preset: {preset!r}. Valid: {sorted(VALID_PRESETS)}"
            )
        values: dict[str, Any] = {
            **PRESETS[preset],
            "tenant_id": tenant_id,
            "sensitivity_preset": preset,
        }
        values.update(overrides)
        return cls(**values)

    # ── Serialization ──────────────────────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dict (JSON-safe)."""
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "TenantConfig":
        """
        Deserialize from a dict (e.g. from json.load).
        Unknown keys are silently ignored for forward-compatibility.
        """
        known = {f.name for f in dataclass_fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in known})

    # ── Validation ─────────────────────────────────────────────────────────────

    def validate(self) -> list[str]:
        """
        Check for configuration errors.

        Returns a list of error strings. An empty list means the config is valid.
        Does not raise — call validate_or_raise() if you want an exception.
        """
        errors: list[str] = []

        # tenant_id
        if not self.tenant_id:
            errors.append("tenant_id is required")
        elif not _TENANT_ID_RE.match(self.tenant_id):
            errors.append(
                f"tenant_id must be alphanumeric with hyphens/underscores only "
                f"(got {self.tenant_id!r})"
            )

        # threshold ranges
        for name, val in (
            ("tier1_threshold",           self.tier1_threshold),
            ("tier2_action_threshold",    self.tier2_action_threshold),
            ("circuit_breaker_threshold", self.circuit_breaker_threshold),
        ):
            if not isinstance(val, (int, float)):
                errors.append(f"{name} must be a number (got {type(val).__name__})")
            elif not (0.0 <= val <= 1.0):
                errors.append(f"{name} must be 0.0–1.0 (got {val})")

        # threshold ordering
        if self.tier1_threshold > self.tier2_action_threshold:
            errors.append(
                f"tier1_threshold ({self.tier1_threshold}) should be "
                f"<= tier2_action_threshold ({self.tier2_action_threshold})"
            )
        if self.tier2_action_threshold > self.circuit_breaker_threshold:
            errors.append(
                f"tier2_action_threshold ({self.tier2_action_threshold}) should be "
                f"<= circuit_breaker_threshold ({self.circuit_breaker_threshold})"
            )

        # enabled_dimensions
        if not self.enabled_dimensions:
            errors.append("enabled_dimensions cannot be empty — at least one dimension is required")
        else:
            for dim in self.enabled_dimensions:
                if dim not in ALL_DIMENSIONS:
                    errors.append(
                        f"Unknown dimension {dim!r}. Valid: {ALL_DIMENSIONS}"
                    )
            if len(self.enabled_dimensions) != len(set(self.enabled_dimensions)):
                errors.append("enabled_dimensions contains duplicate entries")

        # action_on_drift
        if self.action_on_drift not in VALID_ACTIONS:
            errors.append(
                f"action_on_drift must be one of {sorted(VALID_ACTIONS)} "
                f"(got {self.action_on_drift!r})"
            )

        # webhook_url format (only checked when non-empty)
        if self.webhook_url and not self.webhook_url.startswith(("http://", "https://")):
            errors.append(
                f"webhook_url must start with http:// or https:// "
                f"(got {self.webhook_url!r})"
            )

        # sensitivity_preset
        if self.sensitivity_preset not in VALID_PRESETS:
            errors.append(
                f"sensitivity_preset must be one of {sorted(VALID_PRESETS)} "
                f"(got {self.sensitivity_preset!r})"
            )

        return errors

    def validate_or_raise(self) -> None:
        """Validate and raise ValueError listing all errors if invalid."""
        errors = self.validate()
        if errors:
            bullet_list = "\n".join(f"  • {e}" for e in errors)
            raise ValueError(
                f"Invalid TenantConfig for {self.tenant_id!r}:\n{bullet_list}"
            )

    def __repr__(self) -> str:
        dims_summary = (
            f"{len(self.enabled_dimensions)}/4"
            if len(self.enabled_dimensions) < 4
            else "all"
        )
        return (
            f"TenantConfig("
            f"tenant_id={self.tenant_id!r}, "
            f"preset={self.sensitivity_preset!r}, "
            f"thresholds=[{self.tier1_threshold}/{self.tier2_action_threshold}/"
            f"{self.circuit_breaker_threshold}], "
            f"action={self.action_on_drift!r}, "
            f"dimensions={dims_summary})"
        )


# ── Path helpers ───────────────────────────────────────────────────────────────

def _resolve_config_dir(config_dir: Optional[str] = None) -> Path:
    """Resolve the config directory from argument, env var, or default."""
    path = config_dir or os.environ.get(CONFIG_DIR_ENV_VAR, DEFAULT_CONFIG_DIR)
    return Path(path)


def _tenant_path(tenant_id: str, config_dir: Optional[str] = None) -> Path:
    return _resolve_config_dir(config_dir) / f"{tenant_id}.json"


# ── Public API ─────────────────────────────────────────────────────────────────

def load(
    tenant_id: str,
    config_dir: Optional[str] = None,
) -> TenantConfig:
    """
    Load a tenant config from its JSON file.

    Args:
        tenant_id:  tenant identifier (matches filename: <tenant_id>.json)
        config_dir: config directory to read from
                    (default: DRIFT_CONFIG_DIR env var, or './tenant_configs')

    Returns:
        TenantConfig loaded and deserialized from disk

    Raises:
        FileNotFoundError: if <tenant_id>.json does not exist in config_dir
        json.JSONDecodeError: if the file is malformed JSON
    """
    path = _tenant_path(tenant_id, config_dir)
    with open(path, encoding="utf-8") as fh:
        raw = json.load(fh)
    return TenantConfig.from_dict(raw)


def save(
    config: TenantConfig,
    config_dir: Optional[str] = None,
    validate: bool = True,
) -> Path:
    """
    Save a tenant config to a JSON file.

    Creates the config directory if it does not exist.

    Args:
        config:     TenantConfig instance to persist
        config_dir: directory to write to
        validate:   if True (default), calls validate_or_raise() before writing

    Returns:
        Path to the written file

    Raises:
        ValueError: if validate=True and the config has validation errors
    """
    if validate:
        config.validate_or_raise()

    dir_path = _resolve_config_dir(config_dir)
    dir_path.mkdir(parents=True, exist_ok=True)

    path = dir_path / f"{config.tenant_id}.json"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(config.to_dict(), fh, indent=2)
        fh.write("\n")   # trailing newline for clean VCS diffs

    return path


def get_or_default(
    tenant_id: str,
    config_dir: Optional[str] = None,
) -> TenantConfig:
    """
    Load tenant config if it exists on disk; return a standard-preset default otherwise.

    Never raises FileNotFoundError — safe to call on every request without try/except.

    Args:
        tenant_id:  tenant identifier
        config_dir: config directory to look in

    Returns:
        TenantConfig from disk, or TenantConfig(tenant_id=tenant_id) with defaults
    """
    try:
        return load(tenant_id, config_dir)
    except FileNotFoundError:
        return TenantConfig(tenant_id=tenant_id)


def list_tenants(config_dir: Optional[str] = None) -> list[str]:
    """
    Return a sorted list of tenant IDs that have config files on disk.

    Returns [] if the config directory does not exist yet.
    """
    dir_path = _resolve_config_dir(config_dir)
    if not dir_path.is_dir():
        return []
    return sorted(p.stem for p in dir_path.glob("*.json"))


def delete(
    tenant_id: str,
    config_dir: Optional[str] = None,
) -> bool:
    """
    Delete a tenant's config file.

    Returns:
        True if the file existed and was deleted; False if it was not found.
    """
    path = _tenant_path(tenant_id, config_dir)
    if path.exists():
        path.unlink()
        return True
    return False


def load_all(config_dir: Optional[str] = None) -> dict[str, TenantConfig]:
    """
    Load every tenant config from the config directory.

    Files that fail to parse are skipped with a warning to stderr.

    Returns:
        Dict mapping tenant_id → TenantConfig, sorted by tenant_id
    """
    result: dict[str, TenantConfig] = {}
    for tenant_id in list_tenants(config_dir):
        try:
            result[tenant_id] = load(tenant_id, config_dir)
        except (json.JSONDecodeError, TypeError, KeyError) as exc:
            print(
                f"[tenant_config] Warning: skipping {tenant_id!r} — parse error: {exc}",
                file=sys.stderr,
            )
    return result


# ── CLI ────────────────────────────────────────────────────────────────────────

def _cli() -> None:
    """
    Quick inspection / management utility.

    Usage:
        python tenant_config.py list
        python tenant_config.py show <tenant_id>
        python tenant_config.py create <tenant_id> [--preset strict|standard|permissive]
        python tenant_config.py validate <tenant_id>
        python tenant_config.py presets
    """
    import argparse

    parser = argparse.ArgumentParser(
        prog="tenant_config.py",
        description="Manage per-tenant drift monitoring configs",
    )
    parser.add_argument(
        "--config-dir", "-d",
        default=None,
        help=f"Config directory (default: {DEFAULT_CONFIG_DIR})",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="List all tenant IDs with configs on disk")

    p_show = sub.add_parser("show", help="Print a tenant's config as JSON")
    p_show.add_argument("tenant_id")

    p_create = sub.add_parser("create", help="Create a config with a preset")
    p_create.add_argument("tenant_id")
    p_create.add_argument(
        "--preset", choices=sorted(VALID_PRESETS), default="standard"
    )
    p_create.add_argument("--webhook-url", default="")
    p_create.add_argument("--action", choices=sorted(VALID_ACTIONS), default=None)

    p_val = sub.add_parser("validate", help="Validate a tenant's config file")
    p_val.add_argument("tenant_id")

    sub.add_parser("presets", help="Show all preset definitions")

    args = parser.parse_args()

    if args.cmd == "list":
        tenants = list_tenants(args.config_dir)
        if not tenants:
            print("No tenant configs found.")
        else:
            for tid in tenants:
                cfg = load(tid, args.config_dir)
                print(f"  {tid:<30} {cfg}")

    elif args.cmd == "show":
        try:
            cfg = load(args.tenant_id, args.config_dir)
            print(json.dumps(cfg.to_dict(), indent=2))
        except FileNotFoundError:
            print(f"No config found for {args.tenant_id!r}. Use 'create' to make one.")
            sys.exit(1)

    elif args.cmd == "create":
        overrides: dict[str, Any] = {}
        if args.webhook_url:
            overrides["webhook_url"] = args.webhook_url
        if args.action:
            overrides["action_on_drift"] = args.action
        cfg = TenantConfig.from_preset(args.preset, args.tenant_id, **overrides)
        path = save(cfg, args.config_dir)
        print(f"Created: {path}")
        print(cfg)

    elif args.cmd == "validate":
        try:
            cfg = load(args.tenant_id, args.config_dir)
        except FileNotFoundError:
            print(f"No config found for {args.tenant_id!r}.")
            sys.exit(1)
        errors = cfg.validate()
        if errors:
            print(f"INVALID ({len(errors)} error(s)):")
            for e in errors:
                print(f"  • {e}")
            sys.exit(1)
        else:
            print(f"OK — {cfg}")

    elif args.cmd == "presets":
        for name, bundle in PRESETS.items():
            print(f"\n{name}:")
            for k, v in bundle.items():
                print(f"  {k:<30} {v}")
        print()


if __name__ == "__main__":
    _cli()
