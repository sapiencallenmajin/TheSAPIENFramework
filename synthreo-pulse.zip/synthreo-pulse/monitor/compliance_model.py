# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
compliance_model.py
Synthreo.ai — Email-Analogy Privacy Compliance Model

Enforces role-based content isolation for the drift monitoring stack.

Analogy
-------
The conversation is private mail.  The monitoring system reads enough
metadata to route mail (the envelope — scores, patterns, actions) but
never exposes the letter (raw conversation text) to anyone outside the
automated scoring pipeline.  When specific safety/policy triggers fire,
the letter is placed in a secure review room (ReviewQueue) where a
credentialed reviewer may open it — but every opening is logged like a
certified mail receipt.

Roles
-----
    system   — automated scoring pipeline; the only role that may read
               raw conversation content.  No human holds this role.
    analyst  — MSP dashboard reader; sees scores, patterns, actions,
               trends.  Never sees conversation text.
    reviewer — human reviewer; may access flagged content ONLY when a
               hard stop or policy-threshold violation triggered review;
               every access is audit-logged.
    admin    — configures tenant policies and thresholds; cannot read
               conversation content.

Data origin
-----------
    production — live user conversation; may contain personal data;
                 content is never included in any serialized output.
    synthetic  — test-harness / benchmark scenario; no real user data;
                 content may be logged for debugging.

ContentGate is the single enforcement point.  If content access is
attempted outside an allowed role, AccessViolation is raised immediately
— no silent fallback, no partial access.

No project dependencies — only stdlib (datetime, enum, hashlib, json,
os, pathlib, uuid, dataclasses).  Safe to import independently of the
full monitoring stack.
"""

from __future__ import annotations

import datetime
import hashlib
import json
import os
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional


# ── Constants ──────────────────────────────────────────────────────────────────

#: Environment variable that overrides the default audit log root.
AUDIT_LOG_DIR_ENV: str = "DRIFT_AUDIT_LOG_DIR"

#: Default root for per-tenant daily audit JSONL files.
DEFAULT_AUDIT_LOG_DIR: str = "./logs/audit"

#: Minimum audit log retention (immutable lower bound enforced in RetentionPolicy).
MIN_AUDIT_RETENTION_DAYS: int = 365

#: Default flagged-content retention window (days after review completes).
DEFAULT_FLAGGED_CONTENT_DAYS: int = 30

#: Default scored-metadata retention.
DEFAULT_METADATA_DAYS: int = 90


# ── Role ───────────────────────────────────────────────────────────────────────

class Role(str, Enum):
    """
    Role-based access levels for the drift monitoring stack.

    SYSTEM
        Automated scoring pipeline — the only role permitted to read raw
        conversation content through a ContentGate.  No human is ever
        assigned this role; it is used exclusively by code paths inside
        run_tier1(), run_tier2(), and hard_stops.check().

    ANALYST
        MSP technician reading the live dashboard.  May see scores,
        dimension values, matched pattern category names, action taken,
        reason codes, and trend data.  Never sees conversation text,
        matched phrases, or evidence strings.

    REVIEWER
        Human reviewer with access to flagged conversation content, but
        only when a ReviewQueueEntry was created by a hard stop or a
        policy-threshold trigger.  Every access call is audit-logged
        before content is returned (who, when, why, what action).

    ADMIN
        Configures per-tenant thresholds, actions, and retention policy.
        Cannot read conversation content.
    """
    SYSTEM   = "system"
    ANALYST  = "analyst"
    REVIEWER = "reviewer"
    ADMIN    = "admin"


# ── DataOrigin ─────────────────────────────────────────────────────────────────

class DataOrigin(str, Enum):
    """
    Provenance marker for a MonitorResult or ContentGate.

    PRODUCTION
        Live user conversation; may contain personal data.  Content must
        never appear in any serialized output, log file, or dashboard
        payload.  This is the default.

    SYNTHETIC
        Test-harness / benchmark scenario built from synthetic data.  No
        real user data is involved.  Content may be logged for debugging.
        All _SyntheticMonitorResult objects from test_engine.py carry this
        origin implicitly.
    """
    PRODUCTION = "production"
    SYNTHETIC  = "synthetic"


# ── Exceptions ─────────────────────────────────────────────────────────────────

class AccessViolation(Exception):
    """
    Raised when conversation content is accessed by an unpermitted role.

    The ContentGate raises this instead of silently returning content so
    that no code path can receive conversation text without the gate's
    explicit per-role approval.  Callers that need to report the violation
    can inspect .role and .context without re-raising.

    Attributes
    ----------
    role : Role
        The role that attempted the unauthorized access.
    context : str
        Additional context (e.g. conversation_id) for audit reporting.
    """

    def __init__(self, role: Role, context: str = "") -> None:
        self.role    = role
        self.context = context
        detail = f" ({context})" if context else ""
        super().__init__(
            f"Role '{role.value}' may not read conversation content{detail}. "
            f"Content access requires Role.SYSTEM (automated scoring pipeline) "
            f"or Role.REVIEWER via ReviewQueue.access_content()."
        )


# ── ContentGate ────────────────────────────────────────────────────────────────

class ContentGate:
    """
    Single enforcement point for raw conversation content access.

    Wraps a conversation list and exposes two controlled read paths:

    read_for_scoring(Role.SYSTEM)
        Used exclusively by the scoring pipeline (run_tier1, run_tier2,
        hard_stops.check).  Raises AccessViolation for any other role.

    read_for_review(Role.REVIEWER)
        Used exclusively by ReviewQueue.access_content() after it has
        verified the accessor's role and written the audit record.
        Raises AccessViolation for any other role.

    metadata_envelope()
        Returns structural facts (turn counts, origin) with no message
        text.  Safe for all roles — ANALYST, REVIEWER, ADMIN may all
        consume this dict.

    The gate never writes conversation content to disk, logs, or any
    serialization path.  A shallow copy of the conversation is taken at
    construction time so callers cannot mutate gated content after wrapping.

    Parameters
    ----------
    conversation : list[dict]
        Standard format: [{"role": "user"|"assistant", "content": "..."}]
    tenant_id : str
        Embedded in envelope metadata and audit records.
    conversation_id : str
        Embedded in envelope metadata and audit records.
    data_origin : DataOrigin
        PRODUCTION (default) or SYNTHETIC.
    """

    def __init__(
        self,
        conversation: list[dict],
        tenant_id: str = "",
        conversation_id: str = "",
        data_origin: DataOrigin = DataOrigin.PRODUCTION,
    ) -> None:
        # Shallow copy prevents the caller from mutating gated content after wrapping.
        self._conversation:    list[dict]  = list(conversation)
        self._tenant_id:       str         = tenant_id
        self._conversation_id: str         = conversation_id
        self._data_origin:     DataOrigin  = data_origin
        self._turn_count:      int         = len(conversation)
        self._user_count:      int         = sum(
            1 for m in conversation if m.get("role") == "user"
        )

    # ── Read paths ─────────────────────────────────────────────────────────────

    def read_for_scoring(self, role: Role) -> list[dict]:
        """
        Return the raw conversation for the automated scoring pipeline.

        The scoring pipeline (run_tier1, run_tier2, hard_stops.check) calls
        this with Role.SYSTEM.  All other roles raise AccessViolation —
        there is no silent fallback or partial return.

        Parameters
        ----------
        role : Role
            The role requesting access.  Must be Role.SYSTEM.

        Returns
        -------
        list[dict]
            The raw conversation list.  The scoring pipeline owns this data
            in-process; it is never written to disk or serialized.

        Raises
        ------
        AccessViolation
            If role is anything other than Role.SYSTEM.
        """
        if role != Role.SYSTEM:
            raise AccessViolation(
                role,
                context=f"conversation_id={self._conversation_id!r}, read_for_scoring",
            )
        return self._conversation

    def read_for_review(self, accessor_role: Role) -> list[dict]:
        """
        Return the raw conversation for a credentialed human reviewer.

        Called exclusively by ReviewQueue.access_content() — after it has
        verified the accessor's role and written the AuditRecord.  Direct
        callers outside ReviewQueue must not call this method.

        Parameters
        ----------
        accessor_role : Role
            Must be Role.REVIEWER.

        Returns
        -------
        list[dict]
            The raw conversation list.

        Raises
        ------
        AccessViolation
            If accessor_role is not Role.REVIEWER.
        """
        if accessor_role != Role.REVIEWER:
            raise AccessViolation(
                accessor_role,
                context=f"conversation_id={self._conversation_id!r}, read_for_review",
            )
        return self._conversation

    # ── Metadata envelope (content-free) ───────────────────────────────────────

    def metadata_envelope(self) -> dict[str, Any]:
        """
        Return structural metadata about the conversation with no message text.

        Safe for all roles.  ANALYST, REVIEWER, and ADMIN may all consume
        this dict freely.

        Returns
        -------
        dict with keys:
            tenant_id, conversation_id, turn_count,
            user_message_count, data_origin
        """
        return {
            "tenant_id":          self._tenant_id,
            "conversation_id":    self._conversation_id,
            "turn_count":         self._turn_count,
            "user_message_count": self._user_count,
            "data_origin":        self._data_origin.value,
        }

    # ── Integrity ──────────────────────────────────────────────────────────────

    def content_hash(self) -> str:
        """
        SHA-256 of the conversation JSON.

        Used in AuditRecord for integrity verification — proves the
        conversation reviewed by a human matches the one that was scored.
        """
        raw = json.dumps(self._conversation, ensure_ascii=False, sort_keys=True)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    # ── Properties ─────────────────────────────────────────────────────────────

    @property
    def conversation_id(self) -> str:
        return self._conversation_id

    @property
    def tenant_id(self) -> str:
        return self._tenant_id

    @property
    def data_origin(self) -> DataOrigin:
        return self._data_origin

    @property
    def turn_count(self) -> int:
        return self._turn_count

    def __repr__(self) -> str:
        return (
            f"ContentGate(conversation_id={self._conversation_id!r}, "
            f"turns={self._turn_count}, origin={self._data_origin.value!r})"
        )


# ── RetentionPolicy ────────────────────────────────────────────────────────────

@dataclass
class RetentionPolicy:
    """
    Data retention durations for a tenant (all values in days).

    Governs three distinct data classes:

    metadata_days (default 90)
        Scored metadata — risk scores, action decisions, pattern categories,
        trajectory statistics.  Does not include conversation content.
        Retained per tenant_config.data_retention setting.

    flagged_content_days (default 30)
        Conversation content held in the ReviewQueue after a hard stop or
        policy-threshold trigger.  Retention clock starts when a reviewer
        completes their review (reviewed_at timestamp), not at creation.
        Unreviewed entries are not eligible for purge.

    audit_log_days (default 365, minimum enforced at 365)
        Access records for all flagged-content review events.  Audit logs
        are immutable — entries are never deleted before audit_log_days
        have elapsed.  The effective retention is max(audit_log_days, 365).

    Conversation content in the scoring pipeline is always ephemeral —
    processed in memory, never written to disk.  This policy governs only
    the three post-processing data classes listed above.
    """

    metadata_days:         int = DEFAULT_METADATA_DAYS
    flagged_content_days:  int = DEFAULT_FLAGGED_CONTENT_DAYS
    audit_log_days:        int = MIN_AUDIT_RETENTION_DAYS
    audit_log_dir:         str = DEFAULT_AUDIT_LOG_DIR

    def validate(self) -> list[str]:
        """Return list of validation error strings (empty list = valid)."""
        errors: list[str] = []
        if self.audit_log_days < MIN_AUDIT_RETENTION_DAYS:
            errors.append(
                f"audit_log_days must be >= {MIN_AUDIT_RETENTION_DAYS} (got "
                f"{self.audit_log_days}); audit logs are retained for the "
                f"longer of tenant policy or 1 year."
            )
        if self.flagged_content_days < 1:
            errors.append("flagged_content_days must be >= 1")
        if self.metadata_days < 1:
            errors.append("metadata_days must be >= 1")
        return errors

    def validate_or_raise(self) -> None:
        """Validate and raise ValueError listing all errors if invalid."""
        errors = self.validate()
        if errors:
            raise ValueError(
                "RetentionPolicy validation errors:\n" +
                "\n".join(f"  • {e}" for e in errors)
            )

    def effective_audit_days(self) -> int:
        """Audit log retention: max(policy value, MIN_AUDIT_RETENTION_DAYS)."""
        return max(self.audit_log_days, MIN_AUDIT_RETENTION_DAYS)

    def flagged_expires_at(self, reviewed_at: datetime.datetime) -> datetime.datetime:
        """
        Datetime when flagged content may be purged.

        Clock starts when review completes (reviewed_at), not at creation.
        """
        return reviewed_at + datetime.timedelta(days=self.flagged_content_days)

    def metadata_expires_at(self, created_at: datetime.datetime) -> datetime.datetime:
        """Datetime when scored metadata may be purged."""
        return created_at + datetime.timedelta(days=self.metadata_days)


# ── AuditRecord ────────────────────────────────────────────────────────────────

@dataclass
class AuditRecord:
    """
    Immutable record of a single access to flagged conversation content.

    Written to the append-only JSONL audit log by ReviewQueue.access_content()
    before content is returned.  Never modified after creation.  Retained
    for at least MIN_AUDIT_RETENTION_DAYS (1 year).

    Fields
    ------
    record_id       : UUID4 — unique per access event, for deduplication
    entry_id        : ReviewQueueEntry.entry_id
    tenant_id       : str
    conversation_id : str
    accessor_id     : Human reviewer identifier (email or employee ID)
    accessor_role   : Role at time of access (always "reviewer" for content)
    accessed_at     : ISO 8601 UTC timestamp
    trigger_reason  : reason_code that placed the entry in the queue
    action_taken    : Reviewer decision: "escalate" | "dismiss" | "note" | ...
    content_hash    : SHA-256 of the conversation JSON (integrity verification)
    """

    record_id:       str
    entry_id:        str
    tenant_id:       str
    conversation_id: str
    accessor_id:     str
    accessor_role:   str
    accessed_at:     str
    trigger_reason:  str
    action_taken:    str
    content_hash:    str

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dict for JSONL log writing."""
        return {
            "record_id":       self.record_id,
            "entry_id":        self.entry_id,
            "tenant_id":       self.tenant_id,
            "conversation_id": self.conversation_id,
            "accessor_id":     self.accessor_id,
            "accessor_role":   self.accessor_role,
            "accessed_at":     self.accessed_at,
            "trigger_reason":  self.trigger_reason,
            "action_taken":    self.action_taken,
            "content_hash":    self.content_hash,
        }


# ── ReviewQueueEntry ───────────────────────────────────────────────────────────

@dataclass
class ReviewQueueEntry:
    """
    A flagged conversation placed in the secure review queue.

    Created when a hard stop fires or drift exceeds the tenant review
    threshold.  The raw conversation is held inside a ContentGate and is
    never written to disk or included in any serialized output other than
    the secure content delivery path (ReviewQueue.access_content).

    The gate field is excluded from repr to avoid accidental content logging.
    index_dict() is the safe serialization path — it omits the gate entirely
    and is written to the queue's JSONL index file.

    Fields
    ------
    entry_id        : UUID4
    tenant_id       : str
    conversation_id : str
    trigger_reason  : reason_code that flagged this entry
                      (e.g. "HARDSTOP:self_harm:..." or "T1:risk_score:0.82:high")
    scoring_chain   : full scoring output that triggered the flag
    created_at      : ISO 8601 UTC creation timestamp
    retention       : governs flagged-content expiry
    gate            : ContentGate holding the conversation; never serialized
    reviewed_at     : ISO 8601 UTC; set on first access via access_content()
    reviewed_by     : accessor_id of the reviewer; set on first access
    action_taken    : reviewer's decision; set on first access
    required_role   : always Role.REVIEWER
    """

    entry_id:        str
    tenant_id:       str
    conversation_id: str
    trigger_reason:  str
    scoring_chain:   dict
    created_at:      str
    retention:       RetentionPolicy
    gate:            ContentGate     = field(repr=False)   # never serialized
    reviewed_at:     Optional[str]   = None
    reviewed_by:     Optional[str]   = None
    action_taken:    Optional[str]   = None
    required_role:   Role            = Role.REVIEWER

    @property
    def is_reviewed(self) -> bool:
        """True once a reviewer has accessed and actioned this entry."""
        return self.reviewed_at is not None

    @property
    def is_expired(self) -> bool:
        """
        True when flagged content may be purged.

        Only eligible after review is complete AND the flagged_content_days
        retention window has elapsed.  Unreviewed entries are never expired.
        """
        if not self.reviewed_at:
            return False
        reviewed_dt = datetime.datetime.fromisoformat(self.reviewed_at)
        return (
            datetime.datetime.now(datetime.timezone.utc)
            > self.retention.flagged_expires_at(reviewed_dt)
        )

    def index_dict(self) -> dict[str, Any]:
        """
        Content-free serialization for the queue's JSONL index file.

        Omits the gate field entirely.  Safe to write to disk.
        """
        return {
            "entry_id":        self.entry_id,
            "tenant_id":       self.tenant_id,
            "conversation_id": self.conversation_id,
            "trigger_reason":  self.trigger_reason,
            "required_role":   self.required_role.value,
            "created_at":      self.created_at,
            "reviewed_at":     self.reviewed_at,
            "reviewed_by":     self.reviewed_by,
            "action_taken":    self.action_taken,
            "scoring_chain":   self.scoring_chain,
        }


# ── ReviewQueue ────────────────────────────────────────────────────────────────

class ReviewQueue:
    """
    Secure in-memory queue for flagged conversations awaiting human review.

    Manages ReviewQueueEntry objects.  Conversation content is held only in
    ContentGate instances (never written to disk).  The queue's JSONL index
    file records metadata and scoring chains — never message text.

    Audit records are written to an append-only JSONL file before content is
    returned on every access_content() call.

    Parameters
    ----------
    retention : RetentionPolicy | None
        Default policy applied to entries that do not specify their own.
    audit_log_dir : str | None
        Override the audit log directory.  Resolution order:
            1. This argument
            2. RetentionPolicy.audit_log_dir of the entry being accessed
            3. DRIFT_AUDIT_LOG_DIR environment variable
            4. ./logs/audit (default)
    """

    def __init__(
        self,
        retention: Optional[RetentionPolicy] = None,
        audit_log_dir: Optional[str] = None,
    ) -> None:
        self._entries:        dict[str, ReviewQueueEntry] = {}
        self._default_retention: RetentionPolicy = retention or RetentionPolicy()
        self._audit_log_dir:  Optional[str] = audit_log_dir

    # ── Queue management ───────────────────────────────────────────────────────

    def enqueue(self, entry: ReviewQueueEntry) -> None:
        """Add a flagged entry to the queue."""
        self._entries[entry.entry_id] = entry

    def pending(self) -> list[ReviewQueueEntry]:
        """Return unreviewed entries sorted by created_at (oldest first)."""
        unreviewed = [e for e in self._entries.values() if not e.is_reviewed]
        return sorted(unreviewed, key=lambda e: e.created_at)

    def get(self, entry_id: str) -> Optional[ReviewQueueEntry]:
        """Return entry by ID, or None if not found."""
        return self._entries.get(entry_id)

    def purge_expired(self) -> int:
        """
        Remove entries whose flagged-content retention window has elapsed.

        Only reviewed entries with an elapsed flagged_content_days window
        are removed.  Audit records for purged entries are not deleted —
        they are retained independently per the audit log retention policy.

        Returns
        -------
        int
            Number of entries removed from the queue.
        """
        expired_ids = [eid for eid, e in self._entries.items() if e.is_expired]
        for eid in expired_ids:
            del self._entries[eid]
        return len(expired_ids)

    # ── Reviewed content access ────────────────────────────────────────────────

    def access_content(
        self,
        entry_id: str,
        accessor_id: str,
        accessor_role: Role,
        action_taken: str,
    ) -> list[dict]:
        """
        Grant a credentialed reviewer access to flagged conversation content.

        Enforces accessor_role == Role.REVIEWER.  Writes an AuditRecord to
        the append-only JSONL audit log BEFORE returning any content — so
        every access is logged even if the caller crashes after receiving
        the data.  Updates reviewed_at / reviewed_by / action_taken on first
        access; subsequent accesses by other reviewers are audit-logged but
        do not overwrite the first reviewer's fields.

        Parameters
        ----------
        entry_id      : str   ID of the ReviewQueueEntry to access
        accessor_id   : str   Reviewer's identifier (email or employee ID)
        accessor_role : Role  Must be Role.REVIEWER
        action_taken  : str   Reviewer's decision ("escalate" | "dismiss" | "note" | ...)

        Returns
        -------
        list[dict]
            The raw conversation from the entry's ContentGate.

        Raises
        ------
        AccessViolation
            If accessor_role is not Role.REVIEWER.
        KeyError
            If entry_id is not found in this queue.
        """
        if accessor_role != Role.REVIEWER:
            raise AccessViolation(
                accessor_role,
                context=f"access_content(entry_id={entry_id!r})",
            )

        entry = self._entries.get(entry_id)
        if entry is None:
            raise KeyError(
                f"ReviewQueueEntry {entry_id!r} not found in this queue. "
                f"It may have been purged after its retention window elapsed, "
                f"or was never enqueued here."
            )

        now = datetime.datetime.now(datetime.timezone.utc).isoformat()

        # Build and persist the audit record BEFORE reading content.
        # If _write_audit_record fails, the access is still granted (best-effort
        # log write) — but the failure is not silently lost; see _write_audit_record.
        audit_record = AuditRecord(
            record_id=       str(uuid.uuid4()),
            entry_id=        entry_id,
            tenant_id=       entry.tenant_id,
            conversation_id= entry.conversation_id,
            accessor_id=     accessor_id,
            accessor_role=   accessor_role.value,
            accessed_at=     now,
            trigger_reason=  entry.trigger_reason,
            action_taken=    action_taken,
            content_hash=    entry.gate.content_hash(),
        )
        self._write_audit_record(audit_record, entry.retention)

        # Mark entry as reviewed on first access; subsequent accesses only add
        # to the audit log.
        if not entry.is_reviewed:
            entry.reviewed_at  = now
            entry.reviewed_by  = accessor_id
            entry.action_taken = action_taken

        # Deliver content through the gate's reviewer path.
        return entry.gate.read_for_review(Role.REVIEWER)

    # ── Audit log ──────────────────────────────────────────────────────────────

    def _resolve_audit_dir(self, retention: RetentionPolicy) -> Path:
        return Path(
            self._audit_log_dir
            or retention.audit_log_dir
            or os.environ.get(AUDIT_LOG_DIR_ENV, DEFAULT_AUDIT_LOG_DIR)
        )

    def _write_audit_record(
        self,
        record: AuditRecord,
        retention: RetentionPolicy,
    ) -> None:
        """
        Append an AuditRecord as a JSON line to the per-tenant daily audit log.

        Path: <audit_log_dir>/<tenant_id>/audit_<YYYYMMDD>.jsonl

        Append-only: never truncates or overwrites existing content.  Safe for
        concurrent writers on the same day's file.

        Failures are swallowed — the access has already been granted and must
        not be rolled back.  Callers requiring guaranteed delivery should wrap
        access_content() and handle failure externally.
        """
        try:
            audit_dir = self._resolve_audit_dir(retention)
            date_str  = datetime.date.today().strftime("%Y%m%d")
            log_path  = audit_dir / record.tenant_id / f"audit_{date_str}.jsonl"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with open(log_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(record.to_dict(), ensure_ascii=False) + "\n")
        except Exception:
            # Best-effort — access was already granted above.
            pass

    def __len__(self) -> int:
        return len(self._entries)

    def __repr__(self) -> str:
        pending_count = sum(1 for e in self._entries.values() if not e.is_reviewed)
        return (
            f"ReviewQueue(total={len(self._entries)}, pending={pending_count})"
        )


# ── Dashboard metadata filter ──────────────────────────────────────────────────

def strip_for_dashboard(monitor_result: Any, domain: str = "") -> dict[str, Any]:
    """
    Return the ContentGate-filtered metadata envelope for dashboard emission.

    This is the only path by which MonitorResult data should reach
    dashboard_feed.py, webhook payloads, or any external consumer.
    Call this instead of monitor_result.to_dict() for production output.

    Strips (never included in output):
        matched_phrases  — actual text fragments from conversation messages
        evidence         — narrative strings quoting conversation content
        Any field not on the approved metadata allowlist below

    Passes (approved metadata):
        Risk scores and levels
        Pattern category names (what category matched, not what was said)
        Trajectory statistics: counts, velocity floats (no text)
        Pressure density per turn (list of floats — no text)
        Action taken and processing time
        Structural metadata: conversation_id, tenant_id, origin, domain

    Parameters
    ----------
    monitor_result : MonitorResult
        Output of drift_monitor.monitor_conversation().  Also accepts
        _SyntheticMonitorResult from test_engine (duck-typed).
    domain : str
        Optional domain label (e.g. "medical") added for dashboard context.

    Returns
    -------
    dict
        Content-free metadata envelope safe for ANALYST, REVIEWER, and
        ADMIN roles.
    """
    cp = monitor_result.conversation_pressure
    ad = monitor_result.assistant_drift

    traj = cp.trajectory
    trajectory_block = {
        "topic_shifts":            traj.topic_shifts,
        "escalation_velocity":     traj.escalation_velocity,
        "message_count":           traj.message_count,
        "user_message_count":      traj.user_message_count,
        "assistant_message_count": traj.assistant_message_count,
        # Pressure density per turn is a list of floats derived from vocabulary
        # density — no message text; safe to include.
        "pressure_density_per_turn": getattr(traj, "pressure_density_per_turn", []),
    }

    # Only category name and score — matched_phrases and evidence are stripped.
    safe_patterns = [
        {"category": pm.category, "score": pm.score}
        for pm in cp.matched_patterns
        if pm.score > 0
    ]

    assistant_drift_block: Optional[dict[str, Any]] = None
    if ad:
        assistant_drift_block = {
            "flagged":          bool(ad.get("flagged", False)),
            "cumulative_drift": ad.get("cumulative_drift"),
            "flag_reasons":     list(ad.get("flag_reasons") or []),
        }

    return {
        "conversation_id":    monitor_result.conversation_id,
        "action":             monitor_result.action if hasattr(monitor_result, "action")
                              else getattr(monitor_result, "action_type", ""),
        "processing_time_ms": getattr(monitor_result, "processing_time_ms", 0.0),
        "data_origin":        getattr(monitor_result, "data_origin", DataOrigin.PRODUCTION.value),
        "domain":             domain,
        "conversation_pressure": {
            "risk_score":       cp.risk_score,
            "risk_level":       cp.risk_level,
            "trigger_tier2":    getattr(cp, "trigger_tier2", False),
            "matched_patterns": safe_patterns,
            "trajectory":       trajectory_block,
        },
        "assistant_drift": assistant_drift_block,
    }


# ── Factory helper ─────────────────────────────────────────────────────────────

def create_review_entry(
    gate: ContentGate,
    trigger_reason: str,
    scoring_chain: dict,
    retention: Optional[RetentionPolicy] = None,
) -> ReviewQueueEntry:
    """
    Build a ReviewQueueEntry from a ContentGate and its trigger information.

    The caller should pass the same gate used for scoring so the flagged
    conversation is linked to its result without copying content.  The entry
    is not yet enqueued — call queue.enqueue(entry) to add it.

    Parameters
    ----------
    gate           : ContentGate   wrapping the flagged conversation
    trigger_reason : str           reason_code (from hard_stops.HardStopResult
                                   or action_router.RuntimeAction)
    scoring_chain  : dict          full scoring output that caused the flag
                                   (e.g. MonitorResult.to_dict() or
                                   HardStopResult.to_dict())
    retention      : RetentionPolicy | None
                                   defaults to RetentionPolicy() if None

    Returns
    -------
    ReviewQueueEntry   ready to pass to ReviewQueue.enqueue()
    """
    return ReviewQueueEntry(
        entry_id=        str(uuid.uuid4()),
        tenant_id=       gate.tenant_id,
        conversation_id= gate.conversation_id,
        trigger_reason=  trigger_reason,
        scoring_chain=   scoring_chain,
        created_at=      datetime.datetime.now(datetime.timezone.utc).isoformat(),
        retention=       retention or RetentionPolicy(),
        gate=            gate,
    )
