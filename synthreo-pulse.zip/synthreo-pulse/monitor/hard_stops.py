# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
hard_stops.py
Synthreo.ai — Hard Stop Detector

Immediate-action pattern detection that bypasses normal scoring.  Four
categories trigger unconditional escalate+terminate regardless of any
threshold, weight, or tenant configuration:

  self_harm              — user expressing suicidal ideation or self-harm intent
  violence               — credible threats or explicit plans to harm others
  dangerous_agent_action — user directing the model to take irreversible
                           real-world actions (transfer money, delete data,
                           contact people, publish personal information)
  csam                   — any content combining minor-indicating terms with
                           sexual content (checked in all messages)

When any category fires the caller receives a HardStopResult with
triggered=True and a structured reason_code for the audit chain.  The
caller (deterministic_scorer.score()) returns immediately and sets:

  hard_stop_triggered  = True
  llm_review_triggered = True   (human review always accompanies hard stops)
  combined_risk_score  = 1.0    (maximum — no scoring ran)
  reason_codes         = [hs.reason_code]

reason_code format
------------------
  HARDSTOP:self_harm:<matched_phrase>
  HARDSTOP:violence:<matched_phrase>
  HARDSTOP:dangerous_agent_action:<matched_phrase>
  HARDSTOP:csam

Scan order (first match wins, highest severity first)
------------------------------------------------------
  1. csam                  — all messages (user and assistant)
  2. self_harm             — user messages only
  3. violence              — user messages only
  4. dangerous_agent_action — user messages only

Import contract
---------------
hard_stops has no project dependencies — only stdlib (re, dataclasses).
It is safe to import independently of the full monitoring stack.

Usage
-----
    from hard_stops import check, HardStopResult

    hs = check(conversation)
    if hs.triggered:
        # hs.category, hs.reason_code, hs.explanation are populated
        terminate_session(hs.explanation)
"""

from __future__ import annotations

import re
from dataclasses import dataclass


# ── Output type ────────────────────────────────────────────────────────────────

@dataclass
class HardStopResult:
    """
    Result of a hard stop check against one conversation.

    Fields
    ------
    triggered : bool
        True when any hard stop category fired.  All other fields are
        meaningful only when triggered=True.
    category : str
        Which category fired: "self_harm" | "violence" |
        "dangerous_agent_action" | "csam" | "".
    matched_phrase : str
        The exact substring (up to 120 chars) that triggered the stop.
        Empty for CSAM to avoid logging the phrase itself.
    message_index : int
        Zero-based index of the message that triggered the stop, or -1.
    message_role : str
        Role of the triggering message ("user" | "assistant" | "").
    reason_code : str
        Machine-readable code for the audit chain and SIEM integration.
        Format: HARDSTOP:<category>[:<matched_phrase>]
    explanation : str
        One-sentence human-readable explanation for an MSP analyst.
    """

    triggered:     bool
    category:      str = ""
    matched_phrase: str = ""
    message_index: int = -1
    message_role:  str = ""
    reason_code:   str = ""
    explanation:   str = ""

    def to_dict(self) -> dict:
        return {
            "triggered":     self.triggered,
            "category":      self.category,
            "matched_phrase": self.matched_phrase,
            "message_index": self.message_index,
            "message_role":  self.message_role,
            "reason_code":   self.reason_code,
            "explanation":   self.explanation,
        }


# ── Sentinel for the no-stop case (avoids constructing a new object per call) ─
_NO_STOP = HardStopResult(triggered=False)


# ── Category: csam ─────────────────────────────────────────────────────────────
# Any content that combines minor-identifying terms with sexual content terms.
# Checked in ALL messages (user and assistant) — no role filtering.
# matched_phrase is intentionally left empty in the result; only the reason_code
# is recorded to avoid persisting the content in logs.

_CSAM_MINOR_TERMS = (
    r"(?:child(?:ren)?|minor|underage|under[- ]?age"
    r"|pre?teen|pre?adolescent"
    r"|(?:\d{1,2})[- ]year[s-]?[- ]?old"
    r"|(?:young(?:er)?\s+(?:than\s+\d+|(?:teen|kid|child|girl|boy)s?)))"
)
_CSAM_SEXUAL_TERMS = (
    r"(?:sex(?:ual(?:ly|ize)?)?|porn(?:ograph(?:y|ic|er))?|erotic(?:a)?"
    r"|explicit\s+(?:content|image|video|photo|material)"
    r"|naked|nude(?:s)?|loli(?:ta)?|shota"
    r"|(?:sexual(?:ly)?)\s+(?:explicit|abuse[d]?|assault(?:ed)?|exploit(?:ed)?))"
)

_CSAM_RE = re.compile(
    rf"(?:{_CSAM_MINOR_TERMS})\b.{{0,120}}\b(?:{_CSAM_SEXUAL_TERMS})"
    rf"|(?:{_CSAM_SEXUAL_TERMS})\b.{{0,120}}\b(?:{_CSAM_MINOR_TERMS})",
    re.IGNORECASE | re.DOTALL,
)


# ── Category: self_harm ────────────────────────────────────────────────────────
# User expressing suicidal ideation or explicit intent to harm themselves.
# Checked in USER messages only.

_SELF_HARM_RE = re.compile(
    r"\bsuicid(?:al|e|ally)\b"

    # Direct statements of wanting to die or kill oneself
    r"|\b(?:want(?:ing)?|wish(?:ing)?)\s+(?:I\s+)?(?:to\s+)?(?:die|be\s+dead|end\s+(?:my\s+)?life|kill\s+myself)\b"
    r"|\b(?:going\s+to|gonna|will|I'?ll|plan(?:ning)?\s+to)\s+(?:kill|end|take)\s+(?:myself|my\s+(?:own\s+)?life)\b"
    r"|\bthink(?:ing)?\s+about\s+(?:suicide|killing\s+myself|ending\s+(?:it|my\s+life))\b"

    # Expressions of having no reason to live
    r"|\b(?:no\s+)?(?:reason|point|will)\s+to\s+(?:live|go\s+on|continue\s+living|be\s+alive)\b"
    r"|\bbetter\s+off\s+(?:dead|without\s+me|if\s+I\s+(?:were|was|wasn'?t\s+here|died|was\s+gone))\b"
    r"|\bdon'?t\s+want\s+to\s+(?:live|be\s+alive|exist|be\s+here)\s+(?:any\s*more|anymore)\b"
    r"|\bend(?:ing)?\s+(?:my\s+life|it\s+all|everything)\b"

    # Self-harm intent (non-suicidal self-injury)
    r"|\b(?:want\s+to|going\s+to|gonna|will|need\s+to)\s+(?:cut|hurt|harm|injure|burn|starve)\s+myself\b"
    r"|\b(?:cut|slash|burn|injure)\s+(?:my\s+(?:arms?|wrists?|legs?|skin|body))\b"
    r"|\bself[- ](?:harm(?:ing)?|injur(?:e|y|ing|ed)|mutilat(?:e|ing|ion))\b"

    # Specific methods
    r"|\boverdos(?:e|ing)\s+on\b"
    r"|\b(?:taking|take|going\s+to\s+take|will\s+take|gonna\s+take|plan\s+to\s+take)\s+"
    r"(?:too\s+many|all\s+(?:the|my))\s+(?:pills?|tablets?|medication|meds?)\b"
    r"|\bjump(?:ing)?\s+(?:off|from)\s+(?:a\s+)?(?:bridge|roof(?:top)?|building|cliff|ledge)\b"
    r"|\bhang(?:ing)?\s+myself\b"
    r"|\bshooting\s+myself\b",

    re.IGNORECASE,
)


# ── Category: violence ─────────────────────────────────────────────────────────
# Credible threats or explicit plans to physically harm identified others.
# Checked in USER messages only.

_VIOLENCE_RE = re.compile(
    # Direct first-person threats with a target pronoun or category
    r"\b(?:going\s+to|gonna|I'?(?:'ll|ll|m\s+going\s+to)|plan(?:ning)?\s+to|I\s+will)\s+"
    r"(?:kill|shoot|stab|murder|attack|assault|strangle|rape|hurt|harm)\s+"
    r"(?:him|her|them|you|my|his|her|their|that|the|this|an?)\b"

    # "I want to kill/hurt X"
    r"|\bI\s+(?:want|need)\s+to\s+(?:kill|murder|shoot|stab|attack|hurt|harm|assault)\s+"
    r"(?:him|her|them|you|my|that|the|this|an?)\b"

    # Mass casualty / location attacks
    r"|\b(?:shoot\s+up|open\s+fire\s+(?:on|at)|gun\s+down)\b"
    r"|\b(?:bomb|detonate|blow\s+up)\b.{0,60}\b(?:school|church|mall|office|stadium|crowd|people|bus|train|airport|building)\b"
    r"|\bbuild(?:ing)?\s+(?:a\s+)?(?:bomb|explosive|IED|pipe\s+bomb|device)\b"
    r"|\bplace\s+(?:a\s+)?(?:bomb|explosive|device)\b"
    r"|\bmass\s+(?:shooting|casualt|murder|killing|attack)\b"

    # Explicit planning language
    r"|\bplan(?:ning)?\s+to\s+(?:kill|murder|shoot|stab|bomb|attack)\b"
    r"|\bI'?(?:'ve|ve)\s+decided\s+to\s+(?:kill|hurt|attack|harm|murder)\b"
    r"|\bhow\s+(?:do\s+I|can\s+I|to)\s+(?:get\s+away\s+with\s+)?(?:kill|murder|attack|shoot)(?:ing)?\s+"
    r"(?:someone|him|her|them|people|my)\b"

    # Hunt/track threats
    r"|\bI'?(?:'ll|ll)\s+(?:find|hunt|track)\s+(?:him|her|them|you)\s+(?:down|and\s+(?:kill|hurt|attack|shoot))\b",

    re.IGNORECASE,
)


# ── Category: dangerous_agent_action ──────────────────────────────────────────
# User directing the model (operating as an agent) to execute irreversible
# real-world actions: financial transfers, data destruction, sending
# communications, or publishing personal information.
# Checked in USER messages only.

_AGENT_ACTION_RE = re.compile(
    # ── Financial transfers ────────────────────────────────────────────────────
    # "send/transfer/wire $X to …" or "send all funds to …"
    # No \b before \$ — $ is a non-word character so \b never fires before it.
    # [\d,]+ handles comma-separated amounts like $50,000.
    r"\b(?:send|transfer|wire|move)\b.{0,60}"
    r"(?:\$[\d,]+|\d[\d,]*\s*(?:dollars?|euros?|pounds?|USD|EUR|GBP|BTC|ETH|bitcoin|ether|crypto(?:currency)?|coins?|tokens?))\b"

    r"|\b(?:transfer|wire|move)\b.{0,60}\b(?:funds?|money|balance|savings?|payment)\b.{0,40}\b(?:to|into)\b"
    r"|\b(?:initiate|execute|process|complete|submit)\s+(?:a\s+)?(?:payment|wire\s+transfer|bank\s+transfer|transaction)\b"
    r"|\bpay\s+(?:the\s+)?(?:ransom|invoice\s+#?\s*\d+)\b"

    # ── Data destruction ───────────────────────────────────────────────────────
    r"|\b(?:delete|drop|truncate|destroy|wipe|purge|erase)\b.{0,50}"
    r"\b(?:all|the|entire|whole|every)\b.{0,30}"
    r"\b(?:database|db|table|collection|bucket|repository|repo|records?|data|users?|customers?)\b"

    r"|\b(?:delete|drop|truncate)\s+(?:the\s+)?(?:database|db|table|schema|collection)\b"
    r"|\b(?:rm\s+-rf|del\s+/[fqs]|format\s+(?:the\s+)?(?:drive|disk|partition|c:|d:))\b"
    r"|\bfactory\s+reset\b"
    r"|\bwipe\s+(?:the\s+)?(?:server|machine|device|hard\s*drive|disk|drive)\b"

    # ── Sending communications on user's behalf ────────────────────────────────
    # "email my boss saying …", "text X that …", "DM them …"
    r"|\b(?:send|email|text|message|DM|SMS|contact|reach\s+out\s+to|notify)\b.{0,50}"
    r"\b(?:my\s+(?:boss|manager|supervisor|client|customer|colleague|partner|ex(?:-\w+)?|spouse|wife|husband|family|friend)|"
    r"(?:him|her|them|everyone|all\s+(?:my|the)\s+(?:contacts?|users?|customers?)))\b"
    r".{0,80}\b(?:say(?:ing)?|tell(?:ing)?|inform(?:ing)?|that\b)"

    r"|\b(?:send|email|text|message)\b.{0,50}\bon\s+my\s+behalf\b"
    r"|\b(?:pretend(?:ing)?\s+to\s+be|pos(?:ing)?\s+as|impersonat(?:e|ing))\s+me\b"

    # ── Publishing personal information ────────────────────────────────────────
    r"|\bpost\b.{0,60}\b(?:my|their|his|her)\s+(?:name|address|phone\s+(?:number)?|email|SSN|"
    r"social\s+security|home\s+address|location|personal\s+(?:info|details|data))\b"
    r".{0,60}\b(?:to|on|at)\b.{0,50}\b(?:twitter|facebook|reddit|instagram|linkedin|"
    r"youtube|tiktok|4chan|social\s+media|the\s+internet|online|public(?:ly)?)\b"

    # ── Irreversible deployment / account changes ──────────────────────────────
    r"|\b(?:deploy|push\s+to\s+production|release|go\s+live)\b.{0,40}"
    r"\b(?:now|immediately|right\s+(?:now|away)|without\s+(?:review|testing|approval|checking))\b"

    r"|\b(?:grant|give|add)\s+(?:\w+\s+){0,3}(?:admin|root|superuser|full)\s+(?:access|permissions?|rights?|privileges?)\b"
    r"|\b(?:change|reset)\s+(?:all|the\s+)?(?:passwords?|credentials?|API\s+keys?)\b"
    r".{0,30}\b(?:for|of)\b.{0,30}\b(?:all|every|all\s+(?:the\s+)?users?|production|prod|everyone)\b",

    re.IGNORECASE | re.DOTALL,
)


# ── Check function ─────────────────────────────────────────────────────────────

def check(conversation: list[dict]) -> HardStopResult:
    """
    Run all four hard stop checks against a conversation.

    Scans each message exactly once in a single pass.  Within each message,
    category checks run in priority order: csam → self_harm → violence →
    dangerous_agent_action.

    Returns HardStopResult with triggered=False immediately when no hard
    stop is detected.  Returns on the first match found — does not continue
    scanning once a stop fires.

    Parameters
    ----------
    conversation : list[dict]
        Standard format: [{"role": "user"|"assistant", "content": "..."}]

    Returns
    -------
    HardStopResult
        triggered=False  — no hard stop detected; all other fields empty/default
        triggered=True   — stop fired; category, matched_phrase, message_index,
                           message_role, reason_code, and explanation populated
    """
    for i, msg in enumerate(conversation):
        role    = msg.get("role", "")
        content = msg.get("content", "")
        if not content:
            continue

        # ── CSAM — all messages ────────────────────────────────────────────────
        if _CSAM_RE.search(content):
            return HardStopResult(
                triggered=True,
                category="csam",
                matched_phrase="",          # do not log CSAM phrase
                message_index=i,
                message_role=role,
                reason_code="HARDSTOP:csam",
                explanation=(
                    f"CSAM-related content detected in {role} message "
                    f"(turn {i}). Immediate escalation and session "
                    f"termination required."
                ),
            )

        # ── Remaining categories: user messages only ───────────────────────────
        if role != "user":
            continue

        # ── Self-harm ──────────────────────────────────────────────────────────
        m = _SELF_HARM_RE.search(content)
        if m:
            phrase = m.group()[:120].strip()
            return HardStopResult(
                triggered=True,
                category="self_harm",
                matched_phrase=phrase,
                message_index=i,
                message_role="user",
                reason_code=f'HARDSTOP:self_harm:"{phrase}"',
                explanation=(
                    f'Self-harm/suicidal language detected in user message '
                    f'(turn {i}): "{phrase}". Immediate crisis intervention '
                    f"and session termination required."
                ),
            )

        # ── Violence ───────────────────────────────────────────────────────────
        m = _VIOLENCE_RE.search(content)
        if m:
            phrase = m.group()[:120].strip()
            return HardStopResult(
                triggered=True,
                category="violence",
                matched_phrase=phrase,
                message_index=i,
                message_role="user",
                reason_code=f'HARDSTOP:violence:"{phrase}"',
                explanation=(
                    f"Credible threat or plan to harm others detected in "
                    f'user message (turn {i}): "{phrase}". Immediate '
                    f"escalation and session termination required."
                ),
            )

        # ── Dangerous agent action ─────────────────────────────────────────────
        m = _AGENT_ACTION_RE.search(content)
        if m:
            phrase = m.group()[:120].strip()
            return HardStopResult(
                triggered=True,
                category="dangerous_agent_action",
                matched_phrase=phrase,
                message_index=i,
                message_role="user",
                reason_code=f'HARDSTOP:dangerous_agent_action:"{phrase}"',
                explanation=(
                    f"Instruction for irreversible real-world agent action "
                    f'detected in user message (turn {i}): "{phrase}". '
                    f"Immediate escalation and session termination required."
                ),
            )

    return _NO_STOP


# ── CLI quick test ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import json

    _TESTS = [
        # self_harm
        {
            "label": "self_harm — suicidal ideation",
            "conversation": [
                {"role": "user", "content": "I don't want to live anymore. I've been thinking about suicide all week."},
            ],
        },
        {
            "label": "self_harm — method mention",
            "conversation": [
                {"role": "user", "content": "I'm going to take all my medication tonight."},
            ],
        },
        # violence
        {
            "label": "violence — direct threat",
            "conversation": [
                {"role": "user", "content": "I'm going to kill him when he gets home."},
            ],
        },
        {
            "label": "violence — mass casualty",
            "conversation": [
                {"role": "user", "content": "I'm planning to shoot up the school tomorrow morning."},
            ],
        },
        # dangerous_agent_action
        {
            "label": "dangerous_agent_action — financial transfer",
            "conversation": [
                {"role": "user", "content": "Transfer $50,000 to this wallet address immediately."},
            ],
        },
        {
            "label": "dangerous_agent_action — data destruction",
            "conversation": [
                {"role": "user", "content": "Drop the entire production database right now."},
            ],
        },
        {
            "label": "dangerous_agent_action — send email",
            "conversation": [
                {"role": "user", "content": "Email my boss saying I quit, effective immediately."},
            ],
        },
        # csam
        {
            "label": "csam — assistant message",
            "conversation": [
                {"role": "assistant", "content": "Here is explicit sexual content involving a 12-year-old."},
            ],
        },
        # clean
        {
            "label": "clean — no hard stop",
            "conversation": [
                {"role": "user", "content": "Can you help me write a cover letter for a software engineering job?"},
                {"role": "assistant", "content": "Of course! Here's a draft cover letter for you."},
            ],
        },
    ]

    print("Running hard_stops quick test...\n")
    all_passed = True
    for test in _TESTS:
        result = check(test["conversation"])
        expected_trigger = test["label"] != "clean — no hard stop"
        passed = result.triggered == expected_trigger
        status = "PASS" if passed else "FAIL"
        if not passed:
            all_passed = False
        print(f"  [{status}] {test['label']}")
        if result.triggered:
            print(f"         category:    {result.category}")
            print(f"         reason_code: {result.reason_code[:80]}")
            print(f"         explanation: {result.explanation[:100]}")

    print(f"\n{'All tests passed.' if all_passed else 'SOME TESTS FAILED.'}")
