# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
action_router.py
Synthreo.ai — Drift Action Router

Translates a MonitorResult + TenantConfig into a concrete RuntimeAction:
what to do, what to send, and what to inject into the model's system prompt.

Severity order (first matching rule wins)
-----------------------------------------
    terminate       → drift score >= circuit_breaker_threshold, OR action_on_drift
                      is "terminate" and the action threshold is crossed
    escalate        → alert + flag for human review; fires when action_on_drift is
                      "alert_and_ground", or when plain "alert" is configured but
                      the score is deep in the escalation zone
    alert           → fire webhook only
    inject_grounding → prepend re-anchoring text to the next model call (no webhook)
    allow           → drift within thresholds, no action needed

Audit chain
-----------
Every RuntimeAction now carries a complete, machine-readable audit trail:

    matched_patterns          list[str]        what fired and at what score
    triggered_rules           list[PolicyRule]  every rule that evaluated True,
                                               in descending-severity order
    reason_codes              list[str]        SOURCE:SIGNAL:DETAIL codes for
                                               SIEM / alerting integrations
    human_readable_explanation str             full narrative for MSP analysts:
                                               evidence → thresholds → policy
                                               → decision

reason_codes format
-------------------
  PATTERN:<category>:<score>            user-pressure pattern matched
  T1:risk_score:<value>:<level>         Tier 1 composite risk score
  T2:max_turn_drift:<value>             Tier 2 highest single-turn drift
  T2:cumulative_drift:<value>           Tier 2 cumulative drift
  T2:flagged:true                       Tier 2 LLM flagged the conversation
  PRIMARY:score:<value>:source=<src>    score used for threshold comparison
  THRESHOLD:<name>:crossed:<detail>     a threshold was crossed
  THRESHOLD:<name>:clear:<detail>       a threshold evaluated as clear
  POLICY:<tenant>:action_on_drift=<x>  tenant policy rule applied
  ACTION:<type>:rule=<rule_id>:<detail> final action and governing rule

Import contract
---------------
action_router imports from:
  · drift_intervention  — generate_grounding_message (grounding LLM call)
  · tenant_config       — TenantConfig, get_or_default
  · drift_monitor       — MonitorResult (TYPE_CHECKING only; not a runtime import)

Nothing in drift_monitor, drift_intervention, or tenant_config imports from
action_router, so there are no circular dependencies.

Usage
-----
    from action_router import route, route_for_tenant, RuntimeAction, PolicyRule
    # ActionResponse is also available as a backward-compatible alias.

    response = route(monitor_result, tenant_config, conversation=messages, api_key=key)

    # MSP analyst audit trail
    logging.debug(response.human_readable_explanation)
    for code in response.reason_codes:
        logging.debug(code)
    for rule in response.triggered_rules:
        logging.debug("%s %s", rule.rule_id, rule.explanation)

    # Operational routing
    if response.should_terminate:
        return error_response(response.termination_message)
    if response.should_inject_grounding:
        system_prompt += response.grounding_message
    if response.should_alert and tenant_config.webhook_url:
        post_webhook(tenant_config.webhook_url, response.webhook_payload)
"""

from __future__ import annotations

import datetime
import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Optional

# Runtime imports — lightweight; neither pulls in the scoring stack
try:
    from .drift_intervention import generate_grounding_message
    from .tenant_config import TenantConfig, get_or_default
except ImportError:
    from monitor.drift_intervention import generate_grounding_message
    from monitor.tenant_config import TenantConfig, get_or_default

# Type-checking-only import: MonitorResult is referenced in signatures but never
# constructed here, so we guard the import to keep action_router independently
# importable without requiring drift_monitor and its transitive dependencies.
if TYPE_CHECKING:
    try:
        from .drift_monitor import MonitorResult
    except ImportError:
        from monitor.drift_monitor import MonitorResult


# ── Constants ──────────────────────────────────────────────────────────────────

#: Static grounding message used when an LLM call is not possible (no api_key or
#: no conversation context).  Mirrors the fallback in drift_intervention.py.
_FALLBACK_GROUNDING = (
    "I want to make sure I'm giving you accurate and safe information. "
    "Let me be clear about my position on this."
)

#: Safe user-facing message returned with every "terminate" response.
_TERMINATION_MESSAGE = (
    "I want to make sure I'm giving you accurate and safe information. "
    "Let me suggest we approach this differently, or connect you with a specialist."
)

#: Within the range [tier2_action_threshold, circuit_breaker_threshold], how far
#: along before a plain "alert" is upgraded to "escalate".
#: 0.0 = escalate immediately at the action threshold.
#: 1.0 = only escalate at the circuit-breaker boundary.
_ESCALATE_ZONE_FRACTION = 0.5

# Valid action_type values emitted by the router
ACTION_ALLOW            = "allow"
ACTION_INJECT_GROUNDING = "inject_grounding"
ACTION_ALERT            = "alert"
ACTION_ESCALATE         = "escalate"
ACTION_TERMINATE        = "terminate"


# ── PolicyRule ─────────────────────────────────────────────────────────────────

@dataclass
class PolicyRule:
    """
    A single evaluated policy rule in the routing decision chain.

    Every RuntimeAction is the result of evaluating rules in descending severity
    order — the first rule whose condition is True determines the action.  Attaching
    the full evaluated chain to RuntimeAction gives MSP analysts a complete,
    reproducible audit trail.

    Fields
    ------
    rule_id : str
        Stable identifier for this rule type (e.g., "RULE-CB-01").
        Suitable for SIEM correlation, alerting filters, and audit logging.
    condition : str
        Machine-readable boolean condition tested at evaluation time, including
        the actual values (e.g., "primary_score(0.85) >= circuit_breaker(0.80)").
    action : str
        The action this rule produces when its condition is True.
    explanation : str
        One-sentence human-readable explanation for an MSP analyst.
    score_at_trigger : float | None
        The score value that caused this rule to fire, or None for rules where
        no single score is the determinant.
    threshold_crossed : float | None
        The threshold this score was compared against, or None when N/A.
    """

    rule_id:           str
    condition:         str
    action:            str
    explanation:       str
    score_at_trigger:  Optional[float] = None
    threshold_crossed: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "rule_id":           self.rule_id,
            "condition":         self.condition,
            "action":            self.action,
            "explanation":       self.explanation,
            "score_at_trigger":  self.score_at_trigger,
            "threshold_crossed": self.threshold_crossed,
        }


# ── RuntimeAction ──────────────────────────────────────────────────────────────

@dataclass
class RuntimeAction:
    """
    Output of the action router — what the system decided to do.

    Operational fields
    ------------------
    action_type : str
        One of: "allow", "inject_grounding", "alert", "escalate", "terminate".
    reason : str
        Short human-readable summary of why this action was chosen.
    grounding_message : str | None
        Re-anchoring text to prepend to the system prompt.  Populated for
        "inject_grounding" and "escalate"; None otherwise.
    webhook_payload : dict | None
        JSON payload to POST to the tenant's webhook_url.  Populated for
        "alert", "escalate", and "terminate"; None otherwise.
    termination_message : str
        Safe user-facing string returned when the session is terminated.
    human_review_flagged : bool
        True when action_type is "escalate".

    Audit chain fields
    ------------------
    matched_patterns : list[str]
        Formatted as "category(score)" for every pattern with score > 0.
        Empty list when no patterns fired.
    triggered_rules : list[PolicyRule]
        Every PolicyRule that evaluated True, in descending severity order.
        The last entry is the rule that determined action_type.
    reason_codes : list[str]
        Machine-readable SOURCE:SIGNAL:DETAIL codes covering:
          · every matched pattern and its score
          · all ConversationPressure / AssistantDrift scores
          · every threshold comparison (crossed and clear)
          · the tenant policy that was applied
          · the final action and governing rule ID
    human_readable_explanation : str
        Full narrative formatted for an MSP analyst:
          EVIDENCE → THRESHOLD EVALUATION → TENANT POLICY → DECISION
        An analyst reading this should understand exactly what happened
        without consulting any other document.
    """

    # ── Operational ────────────────────────────────────────────────────────────
    action_type:          str
    reason:               str
    grounding_message:    Optional[str]  = None
    webhook_payload:      Optional[dict] = None
    termination_message:  str            = ""
    human_review_flagged: bool           = False

    # ── Audit chain ────────────────────────────────────────────────────────────
    matched_patterns:            list = field(default_factory=list)  # list[str]
    triggered_rules:             list = field(default_factory=list)  # list[PolicyRule]
    reason_codes:                list = field(default_factory=list)  # list[str]
    human_readable_explanation:  str  = ""

    # ── Convenience properties ─────────────────────────────────────────────────

    @property
    def should_terminate(self) -> bool:
        """True when the session must be hard-stopped."""
        return self.action_type == ACTION_TERMINATE

    @property
    def should_alert(self) -> bool:
        """True when a webhook POST should be fired."""
        return self.action_type in (ACTION_ALERT, ACTION_ESCALATE, ACTION_TERMINATE)

    @property
    def should_inject_grounding(self) -> bool:
        """True when grounding_message should be prepended to the system prompt."""
        return self.action_type in (ACTION_INJECT_GROUNDING, ACTION_ESCALATE)

    @property
    def is_escalation(self) -> bool:
        """True when the conversation has been flagged for human review."""
        return self.action_type == ACTION_ESCALATE

    def to_dict(self) -> dict:
        """Serialize to a JSON-safe dict, including nested PolicyRule objects."""
        return {
            "action_type":               self.action_type,
            "reason":                    self.reason,
            "grounding_message":         self.grounding_message,
            "termination_message":       self.termination_message,
            "human_review_flagged":      self.human_review_flagged,
            "matched_patterns":          self.matched_patterns,
            "triggered_rules":           [
                r.to_dict() if hasattr(r, "to_dict") else r
                for r in self.triggered_rules
            ],
            "reason_codes":              self.reason_codes,
            "human_readable_explanation": self.human_readable_explanation,
        }


#: Backward-compatible alias — existing code importing ActionResponse continues to work.
ActionResponse = RuntimeAction


# ── Internal helpers — score extraction ────────────────────────────────────────

def _max_turn_drift(tier2: Optional[dict]) -> float:
    """
    Return the highest single-turn drift score from a Tier 2 result dict.

    The circuit_breaker_threshold in TenantConfig is defined as firing on a
    single-turn score crossing the threshold, so we need the per-turn maximum,
    not the cumulative average.

    Returns 0.0 when tier2 is None, has no turn_scores, or scores are absent.
    """
    if not tier2:
        return 0.0
    turns = tier2.get("turn_scores") or []
    if not turns:
        return 0.0
    return max((float(t.get("turn_drift_score", 0.0)) for t in turns), default=0.0)


def _cumulative_drift(tier2: Optional[dict]) -> float:
    """Return cumulative drift from a Tier 2 result dict.  0.0 if absent."""
    if not tier2:
        return 0.0
    return float(tier2.get("cumulative_drift", 0.0))


def _tier2_flagged(tier2: Optional[dict]) -> bool:
    """True if Tier 2 LLM scoring marked the conversation as flagged."""
    if not tier2:
        return False
    return bool(tier2.get("flagged", False))


def _collect_drift_flags(monitor_result: "MonitorResult") -> list[str]:
    """
    Gather flag strings from both tiers for use as grounding context.

    Tier 1 contributes category names for every pattern with a non-zero score.
    Tier 2 contributes flag_reasons strings from the LLM scorer.
    """
    flags: list[str] = []
    for pm in monitor_result.conversation_pressure.matched_patterns:
        if pm.score > 0:
            flags.append(pm.category)
    if monitor_result.assistant_drift:
        flags.extend(monitor_result.assistant_drift.get("flag_reasons") or [])
    return flags


# ── Internal helpers — audit chain builders ─────────────────────────────────────

def _format_matched_patterns(monitor_result: "MonitorResult") -> list[str]:
    """
    Format pattern match results as "category(score)" strings.

    Only includes patterns with score > 0 — these are the ones that contributed
    to the routing decision.
    """
    return [
        f"{pm.category}({pm.score:.3f})"
        for pm in monitor_result.conversation_pressure.matched_patterns
        if pm.score > 0
    ]


def _base_reason_codes(
    monitor_result: "MonitorResult",
    primary_score:  float,
    max_turn:       float,
    cumulative:     float,
    t2_flagged:     bool,
) -> list[str]:
    """
    Build reason codes for the evidence layer.

    Covers: matched patterns, coordinated attack signal, Tier 1 score,
    Tier 2 scores, and the primary score with its source.  These codes are
    the same regardless of which routing path fires — action-specific codes
    are appended by each return path.
    """
    codes: list[str] = []

    # Matched pressure patterns
    for pm in monitor_result.conversation_pressure.matched_patterns:
        if pm.score > 0:
            codes.append(f"PATTERN:{pm.category}:{pm.score:.3f}")

    active = sum(1 for pm in monitor_result.conversation_pressure.matched_patterns if pm.score > 0)
    if active >= 4:
        codes.append(f"PATTERN:coordinated_attack:{active}_categories")

    # Tier 1 composite
    t1 = monitor_result.conversation_pressure
    codes.append(f"T1:risk_score:{t1.risk_score:.4f}:{t1.risk_level}")

    # Tier 2 (when present)
    if max_turn > 0:
        codes.append(f"T2:max_turn_drift:{max_turn:.4f}")
    if cumulative > 0:
        codes.append(f"T2:cumulative_drift:{cumulative:.4f}")
    if t2_flagged:
        codes.append("T2:flagged:true")

    # Primary score and its source
    source = "tier2_max_turn" if max_turn > 0.0 else "tier1_risk_score"
    codes.append(f"PRIMARY:score:{primary_score:.4f}:source={source}")

    return codes


def _build_explanation(
    action_type:       str,
    monitor_result:    "MonitorResult",
    tenant_config:     TenantConfig,
    primary_score:     float,
    max_turn:          float,
    cumulative:        float,
    t2_flagged:        bool,
    triggered_rules:   list,
    escalate_cutoff:   Optional[float] = None,
) -> str:
    """
    Build a full narrative explanation formatted for an MSP analyst.

    Structure: ACTION TAKEN → EVIDENCE → THRESHOLD EVALUATION → TENANT POLICY
               → POLICY RULE CHAIN → DECISION

    An analyst reading this output should understand exactly why the system
    took the action it did, with no additional context required.
    """

    def _thr_line(score: float, thr: float, label: str) -> str:
        sym    = ">=" if score >= thr else "<"
        status = "CROSSED" if score >= thr else "clear"
        return f"  {label:<30} ({thr}):  {score:.4f} {sym} {thr}  →  {status}"

    lines: list[str] = []
    action_label = action_type.upper().replace("_", " ")

    lines.append(f"ACTION: {action_label}")
    lines.append("─" * 64)

    # ── Evidence section ──────────────────────────────────────────────────────
    lines.append("EVIDENCE (matched signals):")

    active_pms = [pm for pm in monitor_result.conversation_pressure.matched_patterns if pm.score > 0]
    if active_pms:
        lines.append("  User-pressure patterns:")
        for pm in active_pms:
            phrases = pm.matched_phrases[:3]
            phrase_str = (
                '  examples: ' + ', '.join(f'"{p}"' for p in phrases)
                if phrases else ''
            )
            lines.append(f'    • {pm.category:<30}  score={pm.score:.3f}{phrase_str}')
        active_count = len(active_pms)
        if active_count >= 4:
            lines.append(
                f'    ⚑ Coordinated attack: {active_count}/6 categories firing '
                f'simultaneously'
            )
    else:
        lines.append("  No user-pressure patterns matched above threshold.")

    t1 = monitor_result.conversation_pressure
    source_label = "tier2 max turn" if max_turn > 0.0 else "tier1 risk score"
    lines.append(f"  Tier 1 risk score:      {t1.risk_score:.4f}  ({t1.risk_level})")
    lines.append(f"  Primary score:          {primary_score:.4f}  (source: {source_label})")
    if max_turn > 0:
        lines.append(f"  Tier 2 max turn drift:  {max_turn:.4f}")
    if cumulative > 0:
        lines.append(f"  Tier 2 cumulative drift:{cumulative:.4f}")
    if t2_flagged:
        lines.append("  Tier 2 flagged:         true  (LLM scorer confirmed drift)")

    # ── Threshold evaluation section ──────────────────────────────────────────
    cb    = tenant_config.circuit_breaker_threshold
    at    = tenant_config.tier2_action_threshold
    t1thr = tenant_config.tier1_threshold

    lines.append("")
    lines.append("THRESHOLD EVALUATION:")
    lines.append(_thr_line(primary_score, cb,    "circuit_breaker_threshold"))
    lines.append(_thr_line(primary_score, at,    "action_threshold         "))
    lines.append(_thr_line(t1.risk_score, t1thr, "tier1_threshold          "))
    if escalate_cutoff is not None:
        lines.append(_thr_line(primary_score, escalate_cutoff, "escalation_zone_cutoff   "))

    # Why action threshold was crossed (if applicable)
    if t2_flagged and primary_score >= at or cumulative >= at or primary_score >= at:
        if t2_flagged:
            lines.append("  Action threshold crossed by: Tier 2 LLM flagged conversation.")
        elif cumulative >= at:
            lines.append(
                f"  Action threshold crossed by: cumulative drift "
                f"{cumulative:.4f} ≥ {at}."
            )
        else:
            lines.append(
                f"  Action threshold crossed by: primary score "
                f"{primary_score:.4f} ≥ {at}."
            )

    # ── Tenant policy section ─────────────────────────────────────────────────
    lines.append("")
    lines.append(f"TENANT POLICY  (tenant: {tenant_config.tenant_id}):")
    lines.append(f"  action_on_drift:           {tenant_config.action_on_drift}")
    lines.append(f"  sensitivity_preset:        {tenant_config.sensitivity_preset}")
    lines.append(f"  tier1_threshold:           {tenant_config.tier1_threshold}")
    lines.append(f"  tier2_action_threshold:    {tenant_config.tier2_action_threshold}")
    lines.append(f"  circuit_breaker_threshold: {tenant_config.circuit_breaker_threshold}")

    # ── Rule chain section ────────────────────────────────────────────────────
    lines.append("")
    lines.append("POLICY RULE CHAIN  (evaluated in descending severity order):")
    for rule in triggered_rules:
        lines.append(f"  [{rule.rule_id}]")
        lines.append(f"    condition:   {rule.condition}")
        lines.append(f"    action:      {rule.action}")
        lines.append(f"    explanation: {rule.explanation}")

    # ── Decision section ──────────────────────────────────────────────────────
    lines.append("")
    lines.append(f"DECISION: {action_label}")
    if triggered_rules:
        final = triggered_rules[-1]
        lines.append(
            f"  Governed by rule {final.rule_id}: {final.explanation}"
        )

    return "\n".join(lines)


# ── Webhook payload builder ────────────────────────────────────────────────────

def _build_webhook_payload(
    monitor_result:      "MonitorResult",
    tenant_config:       TenantConfig,
    action_type:         str,
    human_review_flagged: bool = False,
    agent_id:            Optional[str] = None,
    reason_codes:        Optional[list] = None,
    triggered_rules:     Optional[list] = None,
) -> dict[str, Any]:
    """
    Build a JSON-serialisable alert payload for the tenant's webhook endpoint.

    Now includes the audit chain (reason_codes and triggered_rules) so SIEM
    systems, Monday.com automations, PagerDuty, and similar integrations receive
    the full routing decision alongside the alert.
    """
    tier2 = monitor_result.assistant_drift or {}

    flagged_categories = [
        pm.category
        for pm in monitor_result.conversation_pressure.matched_patterns
        if pm.score > 0
    ]

    tier2_block: Optional[dict[str, Any]] = None
    if monitor_result.assistant_drift:
        tier2_block = {
            "flagged":          tier2.get("flagged", False),
            "cumulative_drift": tier2.get("cumulative_drift"),
            "max_turn_drift":   _max_turn_drift(monitor_result.assistant_drift),
            "flag_reasons":     tier2.get("flag_reasons", []),
        }

    return {
        "event":                "drift_alert",
        "action":               action_type,
        "human_review_flagged": human_review_flagged,
        "tenant_id":            tenant_config.tenant_id,
        "conversation_id":      monitor_result.conversation_id,
        "agent_id":             agent_id,
        "timestamp":            datetime.datetime.utcnow().isoformat() + "Z",
        "tier1": {
            "risk_score":         monitor_result.conversation_pressure.risk_score,
            "risk_level":         monitor_result.conversation_pressure.risk_level,
            "flagged_categories": flagged_categories,
        },
        "tier2": tier2_block,
        "tenant_config": {
            "tier2_action_threshold":    tenant_config.tier2_action_threshold,
            "circuit_breaker_threshold": tenant_config.circuit_breaker_threshold,
            "action_on_drift":           tenant_config.action_on_drift,
            "sensitivity_preset":        tenant_config.sensitivity_preset,
        },
        # Audit chain — included so downstream systems can act on specific signals
        "reason_codes":    reason_codes or [],
        "triggered_rules": [
            r.to_dict() if hasattr(r, "to_dict") else r
            for r in (triggered_rules or [])
        ],
    }


# ── Grounding helper ───────────────────────────────────────────────────────────

def _try_generate_grounding(
    conversation: Optional[list[dict]],
    api_key:      Optional[str],
    flags:        list[str],
) -> str:
    """
    Attempt to generate a grounding message via the LLM.

    Falls back to a static message without raising if conversation or api_key
    is absent, or if the LLM call raises any exception.
    """
    if not conversation or not api_key:
        return _FALLBACK_GROUNDING
    try:
        return generate_grounding_message(conversation, api_key, flags)
    except Exception:
        return _FALLBACK_GROUNDING


# ── Primary router function ────────────────────────────────────────────────────

def route(
    monitor_result: "MonitorResult",
    tenant_config:  TenantConfig,
    conversation:   Optional[list[dict]] = None,
    api_key:        Optional[str] = None,
    agent_id:       Optional[str] = None,
) -> RuntimeAction:
    """
    Decide what to do given a MonitorResult and the tenant's configuration.

    Evaluates actions in descending severity order so the most critical response
    always takes precedence: terminate > escalate > alert > inject_grounding.

    Parameters
    ----------
    monitor_result : MonitorResult
        Output of drift_monitor.monitor_conversation() or the /monitor endpoint.
    tenant_config : TenantConfig
        The tenant's configured thresholds and action preferences.
    conversation : list[dict] | None
        Full conversation as [{"role": ..., "content": ...}, ...].
        Required for LLM-based grounding message generation.
    api_key : str | None
        Anthropic API key for grounding message generation.
    agent_id : str | None
        Agent identifier included in webhook payloads for traceability.

    Returns
    -------
    RuntimeAction
        Contains action_type, reason, and conditionally grounding_message,
        webhook_payload, termination_message, and human_review_flagged.
        Also contains matched_patterns, triggered_rules, reason_codes, and
        human_readable_explanation for MSP analyst audit.

    Decision tree
    -------------
    Primary score: highest Tier 2 single-turn score when available;
                   falls back to tier1.risk_score.

    1. primary_score >= circuit_breaker_threshold
           → terminate  (hard stop; overrides all configured actions)

    2. action threshold crossed AND action_on_drift == "terminate"
           → terminate

    3. action threshold crossed AND action_on_drift == "alert_and_ground"
           → escalate  (webhook + grounding + human review)

    4. action threshold crossed AND action_on_drift == "alert"
       AND primary_score >= escalate_cutoff OR t2_flagged
           → escalate  (human review warranted at this severity)

    5. action threshold crossed AND action_on_drift == "alert"
           → alert  (webhook only)

    6. action threshold crossed AND action_on_drift == "inject_grounding"
           → inject_grounding

    7. tier1.risk_score >= tier1_threshold AND should_inject_grounding
       (below action threshold — Tier 1 soft signal)
           → inject_grounding  (pre-response intervention)

    8. All thresholds clear
           → allow
    """
    tier2       = monitor_result.assistant_drift
    max_turn    = _max_turn_drift(tier2)
    cumulative  = _cumulative_drift(tier2)
    t2_flagged  = _tier2_flagged(tier2)
    flags       = _collect_drift_flags(monitor_result)

    # Primary score: prefer highest Tier 2 single-turn score when available.
    # circuit_breaker_threshold is explicitly a per-turn metric in TenantConfig.
    primary_score = max_turn if max_turn > 0.0 else monitor_result.conversation_pressure.risk_score

    cb = tenant_config.circuit_breaker_threshold
    at = tenant_config.tier2_action_threshold

    # Pre-compute shared audit chain context
    matched_patterns = _format_matched_patterns(monitor_result)
    base_codes       = _base_reason_codes(
        monitor_result, primary_score, max_turn, cumulative, t2_flagged
    )

    # ── Shared explanation context (passed to every _build_explanation call) ──
    _expl_ctx: dict = dict(
        monitor_result=monitor_result,
        tenant_config=tenant_config,
        primary_score=primary_score,
        max_turn=max_turn,
        cumulative=cumulative,
        t2_flagged=t2_flagged,
    )

    # ── SEVERITY 1: Hard terminate — circuit breaker ───────────────────────────
    if primary_score >= cb:
        rule = PolicyRule(
            rule_id="RULE-CB-01",
            condition=(
                f"primary_score({primary_score:.4f}) >= "
                f"circuit_breaker_threshold({cb})"
            ),
            action=ACTION_TERMINATE,
            explanation=(
                f"Circuit breaker threshold ({cb}) exceeded by primary score "
                f"{primary_score:.4f}. Hard session termination regardless of "
                f"configured action_on_drift."
            ),
            score_at_trigger=primary_score,
            threshold_crossed=cb,
        )
        rules      = [rule]
        extra_codes = [
            f"THRESHOLD:circuit_breaker:crossed:score={primary_score:.4f}>=cb={cb}",
            f"POLICY:{tenant_config.tenant_id}:"
            f"action_on_drift={tenant_config.action_on_drift}",
            "ACTION:terminate:rule=RULE-CB-01:hard_stop=true",
        ]
        reason_codes = base_codes + extra_codes
        payload = _build_webhook_payload(
            monitor_result, tenant_config, ACTION_TERMINATE,
            agent_id=agent_id,
            reason_codes=reason_codes,
            triggered_rules=rules,
        )
        return RuntimeAction(
            action_type=ACTION_TERMINATE,
            reason=(
                f"Drift score {primary_score:.2f} exceeds circuit breaker "
                f"threshold {cb} for tenant '{tenant_config.tenant_id}'."
            ),
            webhook_payload=payload,
            termination_message=_TERMINATION_MESSAGE,
            matched_patterns=matched_patterns,
            triggered_rules=rules,
            reason_codes=reason_codes,
            human_readable_explanation=_build_explanation(
                action_type=ACTION_TERMINATE,
                triggered_rules=rules,
                **_expl_ctx,
            ),
        )

    # ── Action threshold evaluation ────────────────────────────────────────────
    action_threshold_crossed = (
        t2_flagged
        or cumulative >= at
        or primary_score >= at
    )

    if action_threshold_crossed:
        configured = tenant_config.action_on_drift

        # ── SEVERITY 2: Tenant policy terminate ───────────────────────────────
        if configured == "terminate":
            rule = PolicyRule(
                rule_id="RULE-POL-TERM",
                condition=(
                    f"action_threshold_crossed=True "
                    f"AND action_on_drift=terminate  "
                    f"(primary_score={primary_score:.4f}, "
                    f"cumulative={cumulative:.4f}, threshold={at})"
                ),
                action=ACTION_TERMINATE,
                explanation=(
                    f"Tenant '{tenant_config.tenant_id}' action_on_drift='terminate'. "
                    f"Action threshold ({at}) crossed — session terminated per policy."
                ),
                score_at_trigger=primary_score,
                threshold_crossed=at,
            )
            rules = [rule]
            extra_codes = [
                f"THRESHOLD:action:crossed:score={primary_score:.4f}>=at={at}",
                f"POLICY:{tenant_config.tenant_id}:action_on_drift=terminate",
                "ACTION:terminate:rule=RULE-POL-TERM",
            ]
            reason_codes = base_codes + extra_codes
            payload = _build_webhook_payload(
                monitor_result, tenant_config, ACTION_TERMINATE,
                reason_codes=reason_codes,
                triggered_rules=rules,
            )
            return RuntimeAction(
                action_type=ACTION_TERMINATE,
                reason=(
                    f"action_on_drift='terminate' and drift crossed action "
                    f"threshold (score={primary_score:.2f}, "
                    f"cumulative={cumulative:.2f}, threshold={at}) "
                    f"for tenant '{tenant_config.tenant_id}'."
                ),
                webhook_payload=payload,
                termination_message=_TERMINATION_MESSAGE,
                matched_patterns=matched_patterns,
                triggered_rules=rules,
                reason_codes=reason_codes,
                human_readable_explanation=_build_explanation(
                    action_type=ACTION_TERMINATE,
                    triggered_rules=rules,
                    **_expl_ctx,
                ),
            )

        # ── SEVERITY 3: alert_and_ground → escalate ────────────────────────────
        if configured == "alert_and_ground":
            grounding = _try_generate_grounding(conversation, api_key, flags)
            rule = PolicyRule(
                rule_id="RULE-POL-AAG",
                condition=(
                    f"action_threshold_crossed=True "
                    f"AND action_on_drift=alert_and_ground  "
                    f"(primary_score={primary_score:.4f}, threshold={at})"
                ),
                action=ACTION_ESCALATE,
                explanation=(
                    f"Tenant '{tenant_config.tenant_id}' action_on_drift="
                    f"'alert_and_ground'. Action threshold ({at}) crossed — "
                    f"webhook alert sent, grounding injected, flagged for human review."
                ),
                score_at_trigger=primary_score,
                threshold_crossed=at,
            )
            rules = [rule]
            extra_codes = [
                f"THRESHOLD:action:crossed:score={primary_score:.4f}>=at={at}",
                f"POLICY:{tenant_config.tenant_id}:action_on_drift=alert_and_ground",
                "ACTION:escalate:rule=RULE-POL-AAG:"
                "grounding=true:webhook=true:human_review=true",
            ]
            reason_codes = base_codes + extra_codes
            payload = _build_webhook_payload(
                monitor_result, tenant_config, ACTION_ESCALATE,
                human_review_flagged=True,
                agent_id=agent_id,
                reason_codes=reason_codes,
                triggered_rules=rules,
            )
            return RuntimeAction(
                action_type=ACTION_ESCALATE,
                reason=(
                    f"action_on_drift='alert_and_ground' and drift crossed action "
                    f"threshold (score={primary_score:.2f}, "
                    f"cumulative={cumulative:.2f}, threshold={at}) "
                    f"for tenant '{tenant_config.tenant_id}'. "
                    f"Webhook alert sent and grounding injected."
                ),
                grounding_message=grounding,
                webhook_payload=payload,
                human_review_flagged=True,
                matched_patterns=matched_patterns,
                triggered_rules=rules,
                reason_codes=reason_codes,
                human_readable_explanation=_build_explanation(
                    action_type=ACTION_ESCALATE,
                    triggered_rules=rules,
                    **_expl_ctx,
                ),
            )

        # ── SEVERITY 4 / 5: alert — escalate or plain ─────────────────────────
        if configured == "alert":
            escalate_cutoff = at + _ESCALATE_ZONE_FRACTION * (cb - at)

            if primary_score >= escalate_cutoff or t2_flagged:
                # ── SEVERITY 4: escalation zone or Tier 2 confirmation ────────
                esc_trigger = (
                    f"primary_score({primary_score:.4f}) >= "
                    f"escalation_cutoff({escalate_cutoff:.4f})"
                    if primary_score >= escalate_cutoff
                    else f"t2_flagged=True (LLM confirmed drift)"
                )
                rule = PolicyRule(
                    rule_id="RULE-ZONE-ESC",
                    condition=(
                        f"action_threshold_crossed=True "
                        f"AND action_on_drift=alert "
                        f"AND ({esc_trigger})"
                    ),
                    action=ACTION_ESCALATE,
                    explanation=(
                        f"Score in escalation zone (cutoff={escalate_cutoff:.3f}) "
                        f"or Tier 2 LLM confirmed drift — severity warrants human "
                        f"review beyond a plain webhook alert."
                    ),
                    score_at_trigger=primary_score,
                    threshold_crossed=escalate_cutoff,
                )
                rules = [rule]
                esc_zone_code = (
                    f"THRESHOLD:escalation_zone:crossed:"
                    f"score={primary_score:.4f}>=cutoff={escalate_cutoff:.4f}"
                    if primary_score >= escalate_cutoff
                    else "T2:flagged:triggered_escalation"
                )
                extra_codes = [
                    f"THRESHOLD:action:crossed:score={primary_score:.4f}>=at={at}",
                    esc_zone_code,
                    f"POLICY:{tenant_config.tenant_id}:action_on_drift=alert",
                    "ACTION:escalate:rule=RULE-ZONE-ESC:human_review=true",
                ]
                reason_codes = base_codes + extra_codes
                payload = _build_webhook_payload(
                    monitor_result, tenant_config, ACTION_ESCALATE,
                    human_review_flagged=True,
                    reason_codes=reason_codes,
                    triggered_rules=rules,
                )
                return RuntimeAction(
                    action_type=ACTION_ESCALATE,
                    reason=(
                        f"Drift score {primary_score:.2f} is in the escalation zone "
                        f"(cutoff={escalate_cutoff:.2f}) or Tier 2 flagged "
                        f"(flagged={t2_flagged}) for tenant "
                        f"'{tenant_config.tenant_id}'. Flagged for human review."
                    ),
                    webhook_payload=payload,
                    human_review_flagged=True,
                    matched_patterns=matched_patterns,
                    triggered_rules=rules,
                    reason_codes=reason_codes,
                    human_readable_explanation=_build_explanation(
                        action_type=ACTION_ESCALATE,
                        triggered_rules=rules,
                        escalate_cutoff=escalate_cutoff,
                        **_expl_ctx,
                    ),
                )

            # ── SEVERITY 5: plain alert ────────────────────────────────────────
            rule = PolicyRule(
                rule_id="RULE-POL-ALERT",
                condition=(
                    f"action_threshold_crossed=True "
                    f"AND action_on_drift=alert "
                    f"AND primary_score({primary_score:.4f}) < "
                    f"escalation_cutoff({escalate_cutoff:.4f}) "
                    f"AND t2_flagged=False"
                ),
                action=ACTION_ALERT,
                explanation=(
                    f"Action threshold ({at}) crossed. Tenant configured alert-only; "
                    f"score {primary_score:.3f} below escalation zone cutoff "
                    f"{escalate_cutoff:.3f}. Webhook alert sent."
                ),
                score_at_trigger=primary_score,
                threshold_crossed=at,
            )
            rules = [rule]
            extra_codes = [
                f"THRESHOLD:action:crossed:score={primary_score:.4f}>=at={at}",
                f"THRESHOLD:escalation_zone:clear:"
                f"score={primary_score:.4f}<cutoff={escalate_cutoff:.4f}",
                f"POLICY:{tenant_config.tenant_id}:action_on_drift=alert",
                "ACTION:alert:rule=RULE-POL-ALERT:webhook=true",
            ]
            reason_codes = base_codes + extra_codes
            payload = _build_webhook_payload(
                monitor_result, tenant_config, ACTION_ALERT,
                agent_id=agent_id,
                reason_codes=reason_codes,
                triggered_rules=rules,
            )
            return RuntimeAction(
                action_type=ACTION_ALERT,
                reason=(
                    f"Drift score {primary_score:.2f} crossed action threshold {at} "
                    f"for tenant '{tenant_config.tenant_id}'; alert configured."
                ),
                webhook_payload=payload,
                matched_patterns=matched_patterns,
                triggered_rules=rules,
                reason_codes=reason_codes,
                human_readable_explanation=_build_explanation(
                    action_type=ACTION_ALERT,
                    triggered_rules=rules,
                    escalate_cutoff=escalate_cutoff,
                    **_expl_ctx,
                ),
            )

        # ── SEVERITY 6: inject_grounding (policy) ─────────────────────────────
        if configured == "inject_grounding":
            grounding = _try_generate_grounding(conversation, api_key, flags)
            rule = PolicyRule(
                rule_id="RULE-POL-GROUND",
                condition=(
                    f"action_threshold_crossed=True "
                    f"AND action_on_drift=inject_grounding  "
                    f"(primary_score={primary_score:.4f}, threshold={at})"
                ),
                action=ACTION_INJECT_GROUNDING,
                explanation=(
                    f"Action threshold ({at}) crossed. Tenant configured "
                    f"inject_grounding; re-anchoring message prepended to "
                    f"system prompt. No webhook sent."
                ),
                score_at_trigger=primary_score,
                threshold_crossed=at,
            )
            rules = [rule]
            extra_codes = [
                f"THRESHOLD:action:crossed:score={primary_score:.4f}>=at={at}",
                f"POLICY:{tenant_config.tenant_id}:action_on_drift=inject_grounding",
                "ACTION:inject_grounding:rule=RULE-POL-GROUND:grounding=true",
            ]
            reason_codes = base_codes + extra_codes
            return RuntimeAction(
                action_type=ACTION_INJECT_GROUNDING,
                reason=(
                    f"Drift score {primary_score:.2f} crossed action threshold {at} "
                    f"for tenant '{tenant_config.tenant_id}'; "
                    f"grounding injection configured."
                ),
                grounding_message=grounding,
                matched_patterns=matched_patterns,
                triggered_rules=rules,
                reason_codes=reason_codes,
                human_readable_explanation=_build_explanation(
                    action_type=ACTION_INJECT_GROUNDING,
                    triggered_rules=rules,
                    **_expl_ctx,
                ),
            )

    # ── SEVERITY 7: Tier 1 soft signal — below action threshold ───────────────
    tier1_score = monitor_result.conversation_pressure.risk_score
    if (
        tier1_score >= tenant_config.tier1_threshold
        and tenant_config.should_inject_grounding
    ):
        grounding = _try_generate_grounding(conversation, api_key, flags)
        rule = PolicyRule(
            rule_id="RULE-T1-SOFT",
            condition=(
                f"tier1_score({tier1_score:.4f}) >= "
                f"tier1_threshold({tenant_config.tier1_threshold}) "
                f"AND should_inject_grounding=True "
                f"AND action_threshold_not_crossed "
                f"(primary_score={primary_score:.4f} < at={at})"
            ),
            action=ACTION_INJECT_GROUNDING,
            explanation=(
                f"Tier 1 soft signal: risk score {tier1_score:.3f} ≥ "
                f"tier1_threshold {tenant_config.tier1_threshold} but below "
                f"action threshold {at}. Pre-emptive grounding applied before "
                f"drift can compound."
            ),
            score_at_trigger=tier1_score,
            threshold_crossed=tenant_config.tier1_threshold,
        )
        rules = [rule]
        extra_codes = [
            f"THRESHOLD:tier1_soft:crossed:"
            f"score={tier1_score:.4f}>=t1_thr={tenant_config.tier1_threshold}",
            f"THRESHOLD:action:clear:primary={primary_score:.4f}<at={at}",
            f"POLICY:{tenant_config.tenant_id}:should_inject_grounding=True",
            "ACTION:inject_grounding:rule=RULE-T1-SOFT:soft_signal=true",
        ]
        reason_codes = base_codes + extra_codes
        return RuntimeAction(
            action_type=ACTION_INJECT_GROUNDING,
            reason=(
                f"Tier 1 risk score {tier1_score:.2f} crossed tier1_threshold "
                f"{tenant_config.tier1_threshold} for tenant "
                f"'{tenant_config.tenant_id}' (below action threshold {at}). "
                f"Soft grounding injection applied."
            ),
            grounding_message=grounding,
            matched_patterns=matched_patterns,
            triggered_rules=rules,
            reason_codes=reason_codes,
            human_readable_explanation=_build_explanation(
                action_type=ACTION_INJECT_GROUNDING,
                triggered_rules=rules,
                **_expl_ctx,
            ),
        )

    # ── No action ──────────────────────────────────────────────────────────────
    rule = PolicyRule(
        rule_id="RULE-ALLOW",
        condition=(
            f"primary_score({primary_score:.4f}) < action_threshold({at}) "
            f"AND tier1_score({tier1_score:.4f}) < tier1_threshold("
            f"{tenant_config.tier1_threshold})"
        ),
        action=ACTION_ALLOW,
        explanation="All thresholds clear. No drift signals meet the bar for action.",
        score_at_trigger=primary_score,
    )
    rules = [rule]
    extra_codes = [
        f"THRESHOLD:all_clear:primary={primary_score:.4f}:tier1={tier1_score:.4f}",
        f"POLICY:{tenant_config.tenant_id}:"
        f"action_on_drift={tenant_config.action_on_drift}",
        "ACTION:allow:rule=RULE-ALLOW",
    ]
    reason_codes = base_codes + extra_codes
    return RuntimeAction(
        action_type=ACTION_ALLOW,
        reason=(
            f"Drift within acceptable thresholds for tenant "
            f"'{tenant_config.tenant_id}' "
            f"(score={primary_score:.2f}, "
            f"tier1={monitor_result.conversation_pressure.risk_score:.2f})."
        ),
        matched_patterns=matched_patterns,
        triggered_rules=rules,
        reason_codes=reason_codes,
        human_readable_explanation=_build_explanation(
            action_type=ACTION_ALLOW,
            triggered_rules=rules,
            **_expl_ctx,
        ),
    )


# ── Convenience wrapper ────────────────────────────────────────────────────────

def route_for_tenant(
    tenant_id:    str,
    monitor_result: "MonitorResult",
    conversation: Optional[list[dict]] = None,
    api_key:      Optional[str] = None,
    agent_id:     Optional[str] = None,
    config_dir:   Optional[str] = None,
) -> RuntimeAction:
    """
    Load tenant config from disk and route in one call.

    Uses get_or_default() internally — safe for hot-path use, never raises
    FileNotFoundError.  If no config file exists for the tenant, standard-preset
    defaults are used.

    Parameters
    ----------
    tenant_id : str
        Tenant identifier.  Looked up via tenant_config.get_or_default().
    monitor_result : MonitorResult
        Output from drift_monitor.monitor_conversation() or /monitor endpoint.
    conversation : list[dict] | None
        Full conversation for grounding message generation.
    api_key : str | None
        Anthropic API key for grounding generation.
    agent_id : str | None
        Agent identifier included in webhook payloads.
    config_dir : str | None
        Override for the config directory.

    Returns
    -------
    RuntimeAction
        Same as route(); config is loaded transparently.
    """
    tenant_config = get_or_default(tenant_id, config_dir)
    return route(monitor_result, tenant_config, conversation, api_key, agent_id)
