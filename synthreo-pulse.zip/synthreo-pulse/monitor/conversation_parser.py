# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
# ──────────────────────────────────────────────────────────────────────────────
"""
conversation_parser.py
Synthreo.ai — Conversation Export Parser

Parses exported conversation history into a normalized list of {role, content}
dicts for drift scoring.

Supported formats:
  · ChatGPT export — conversations.json from data export ZIP or raw JSON
      Structure: list of conversations, each with a "mapping" dict where
      nodes have "message.author.role" and "message.content.parts[]".
  · Claude export — conversations.json from claude.ai data export
      Structure: {"conversations": [...]} where each conversation has
      "chat_messages" with "sender" = "human" / "assistant".
  · Gemini export — Google Takeout ZIP containing individual conversation
      JSON files under Takeout/Gemini/ (or similar paths). Each file has
      {"messages": [...]} with "role" = "user"/"model" and "parts" array.
  · Copilot/Bing Chat export — JSON with "messages" array where each
      message has "author" = "user"/"bot" and "text" field; also handles
      the older nested format with "conversations[].messages[].sender".

Auto-detects format from the JSON structure.  Returns:
  parse_file(path)  -> list[ParsedConversation]
  parse_bytes(data) -> list[ParsedConversation]
      Each ParsedConversation has:
          id    : str    — conversation id or index-based fallback
          name  : str    — title / topic
          messages: list[dict]   — [{role, content}]
          source_format: str     — "chatgpt"|"claude"|"gemini"|"copilot"

Usage:
  from conversation_parser import parse_bytes, auto_detect_format
"""

import io
import json
import logging
import zipfile
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ParsedConversation:
    id: str
    name: str
    messages: list = field(default_factory=list)   # [{role, content}]
    source_format: str = ""                         # chatgpt|claude|gemini|copilot


# ── Format detection ──────────────────────────────────────────────────────────

def auto_detect_format(data: list | dict) -> str:
    """
    Infer format from parsed JSON structure.
    Returns one of: 'chatgpt' | 'chatgpt_single' | 'claude' | 'gemini' |
                    'copilot' | 'copilot_nested' | 'messages_list' | 'unknown'
    """
    if isinstance(data, list):
        if not data or not isinstance(data[0], dict):
            return "unknown"
        first = data[0]
        if "mapping" in first:
            return "chatgpt"
        if "chat_messages" in first:
            return "claude_list"
        if first.get("role") in ("user", "assistant", "human"):
            return "messages_list"
        # Gemini Takeout sometimes wraps multiple convs in a list
        if "messages" in first and _looks_gemini(first):
            return "gemini_list"

    if isinstance(data, dict):
        # Claude: {"conversations": [{..., "chat_messages": [...]}]}
        if "conversations" in data:
            convs = data["conversations"]
            if convs and isinstance(convs[0], dict):
                if "chat_messages" in convs[0]:
                    return "claude"
                # Copilot nested: conversations[].messages[].sender
                msgs = convs[0].get("messages") or []
                if msgs and isinstance(msgs[0], dict) and "sender" in msgs[0]:
                    return "copilot_nested"
        # ChatGPT single: {"mapping": {...}}
        if "mapping" in data:
            return "chatgpt_single"
        # Gemini single: {"messages": [...]} with role="model"
        if "messages" in data and _looks_gemini(data):
            return "gemini"
        # Copilot flat: {"messages": [...]} with author="bot"/"user"
        if "messages" in data and _looks_copilot(data):
            return "copilot"

    return "unknown"


def _looks_gemini(data: dict) -> bool:
    """True when the messages array contains Gemini-style role/parts entries."""
    msgs = data.get("messages") or []
    for m in msgs[:5]:
        if not isinstance(m, dict):
            continue
        if m.get("role") == "model":
            return True
        if "parts" in m and isinstance(m.get("parts"), list):
            return True
    return False


def _looks_copilot(data: dict) -> bool:
    """True when the messages array contains Copilot-style author/text entries."""
    msgs = data.get("messages") or []
    for m in msgs[:5]:
        if not isinstance(m, dict):
            continue
        if m.get("author") in ("user", "bot"):
            return True
        if m.get("sender") in ("user", "bot"):
            return True
    return False


# ── ChatGPT parser ────────────────────────────────────────────────────────────

def _chatgpt_node_to_text(node: dict) -> str:
    """Extract text from a ChatGPT mapping node's content."""
    msg     = node.get("message") or {}
    content = msg.get("content") or {}
    parts   = content.get("parts") or []
    texts   = []
    for p in parts:
        if isinstance(p, str) and p.strip():
            texts.append(p)
        # tether / image / tool-result blocks — skip
    return "\n".join(texts)


def _parse_chatgpt_single(conv: dict, idx: int) -> ParsedConversation:
    """Parse one ChatGPT conversation object with a 'mapping' key."""
    title   = conv.get("title") or f"Conversation {idx + 1}"
    conv_id = conv.get("id") or str(idx)
    mapping = conv.get("mapping") or {}

    all_ids = set(mapping.keys())
    children_of: dict[str, list] = {}
    for node_id, node in mapping.items():
        parent = node.get("parent")
        if parent and parent in all_ids:
            children_of.setdefault(parent, []).append(node_id)

    roots = [
        nid for nid, node in mapping.items()
        if not node.get("parent") or node.get("parent") not in all_ids
    ]

    messages: list[dict] = []
    visited: set[str]    = set()

    def walk(node_id: str):
        if node_id in visited:
            return
        visited.add(node_id)
        node   = mapping.get(node_id, {})
        msg    = node.get("message") or {}
        author = (msg.get("author") or {}).get("role", "")
        if author in ("user", "assistant"):
            text = _chatgpt_node_to_text(node)
            if text.strip():
                messages.append({"role": author, "content": text})
        for child_id in children_of.get(node_id, []):
            walk(child_id)

    for root in roots:
        walk(root)

    return ParsedConversation(id=conv_id, name=title, messages=messages,
                              source_format="chatgpt")


def _parse_chatgpt(data: list) -> list[ParsedConversation]:
    return [_parse_chatgpt_single(conv, i) for i, conv in enumerate(data)]


def _parse_chatgpt_single_obj(data: dict) -> list[ParsedConversation]:
    return [_parse_chatgpt_single(data, 0)]


# ── Claude parser ─────────────────────────────────────────────────────────────

def _parse_claude(data: dict | list) -> list[ParsedConversation]:
    """Parse Claude AI export format."""
    if isinstance(data, list):
        conversations = data
    else:
        conversations = data.get("conversations") or []

    result = []
    for i, conv in enumerate(conversations):
        title    = conv.get("name") or conv.get("title") or f"Conversation {i + 1}"
        conv_id  = conv.get("uuid") or conv.get("id") or str(i)
        messages = []
        for msg in (conv.get("chat_messages") or []):
            sender = msg.get("sender") or msg.get("role") or ""
            if sender == "human":
                role = "user"
            elif sender == "assistant":
                role = "assistant"
            else:
                continue
            raw = msg.get("text") or msg.get("content") or ""
            if isinstance(raw, list):
                parts = []
                for block in raw:
                    if isinstance(block, str):
                        parts.append(block)
                    elif isinstance(block, dict):
                        parts.append(block.get("text") or block.get("content") or "")
                text = "\n".join(p for p in parts if p)
            else:
                text = str(raw)
            if text.strip():
                messages.append({"role": role, "content": text})
        result.append(ParsedConversation(id=conv_id, name=title, messages=messages,
                                         source_format="claude"))
    return result


# ── Gemini parser ─────────────────────────────────────────────────────────────

def _gemini_parts_to_text(parts: list) -> str:
    """Flatten Gemini parts array to a plain string."""
    texts = []
    for p in parts:
        if isinstance(p, str):
            if p.strip():
                texts.append(p)
        elif isinstance(p, dict):
            t = p.get("text") or p.get("content") or ""
            if isinstance(t, str) and t.strip():
                texts.append(t)
    return "\n".join(texts)


def _parse_gemini_single(data: dict, idx: int,
                          name: str = "") -> ParsedConversation:
    """Parse one Gemini conversation JSON object."""
    title   = (data.get("title") or data.get("name") or
               name or f"Conversation {idx + 1}")
    conv_id = data.get("id") or data.get("conversation_id") or str(idx)
    messages: list[dict] = []

    for msg in (data.get("messages") or []):
        if not isinstance(msg, dict):
            continue
        role_raw = msg.get("role") or msg.get("author") or ""
        if role_raw == "user":
            role = "user"
        elif role_raw in ("model", "assistant"):
            role = "assistant"
        else:
            continue

        # Content may be in "parts", "content", or "text"
        raw_parts = msg.get("parts")
        if raw_parts is not None:
            text = _gemini_parts_to_text(raw_parts if isinstance(raw_parts, list)
                                         else [raw_parts])
        else:
            text = str(msg.get("content") or msg.get("text") or "")

        if text.strip():
            messages.append({"role": role, "content": text})

    return ParsedConversation(id=conv_id, name=title, messages=messages,
                              source_format="gemini")


def _parse_gemini(data: dict | list) -> list[ParsedConversation]:
    """Parse Gemini export — single conversation dict or list of them."""
    if isinstance(data, list):
        return [_parse_gemini_single(c, i) for i, c in enumerate(data)
                if isinstance(c, dict)]
    return [_parse_gemini_single(data, 0)]


def _parse_gemini_takeout_zip(zf: zipfile.ZipFile) -> list[ParsedConversation]:
    """
    Extract all Gemini conversations from a Google Takeout ZIP.

    Takeout structure (typical):
        Takeout/Gemini/conversations/<title>.json
        Takeout/Gemini Apps Activity/...

    We collect every .json file whose path contains 'Gemini' (case-insensitive)
    and that parses successfully as a Gemini conversation.
    """
    names = zf.namelist()

    # Prefer paths containing 'gemini' in a directory component
    gemini_files = [
        n for n in names
        if n.lower().endswith(".json")
        and any(part.lower().startswith("gemini") for part in n.split("/"))
    ]

    # Fallback: any JSON file if none found under a Gemini folder
    if not gemini_files:
        gemini_files = [n for n in names if n.lower().endswith(".json")]

    result = []
    for name in gemini_files:
        try:
            raw = zf.read(name)
            obj = json.loads(raw)
        except (KeyError, json.JSONDecodeError) as e:
            logging.debug("Skipping Gemini file %s: %s", name, e)
            continue

        if not isinstance(obj, dict) or "messages" not in obj:
            continue
        if not _looks_gemini(obj):
            continue

        stem = Path(name).stem  # filename without extension as fallback title
        conv = _parse_gemini_single(obj, len(result), name=stem)
        if conv.messages:
            result.append(conv)

    return result


# ── Copilot / Bing Chat parser ─────────────────────────────────────────────────

def _parse_copilot_flat(data: dict, idx: int = 0) -> ParsedConversation:
    """
    Parse Copilot/Bing Chat flat format:
      {"messages": [{"author": "user"|"bot", "text": "..."}, ...]}
    """
    title   = data.get("title") or data.get("name") or f"Conversation {idx + 1}"
    conv_id = data.get("id") or data.get("conversationId") or str(idx)
    messages: list[dict] = []

    for msg in (data.get("messages") or []):
        if not isinstance(msg, dict):
            continue
        author = msg.get("author") or msg.get("role") or msg.get("sender") or ""
        if author == "user":
            role = "user"
        elif author in ("bot", "assistant", "copilot"):
            role = "assistant"
        else:
            continue
        text = str(msg.get("text") or msg.get("content") or "")
        if text.strip():
            messages.append({"role": role, "content": text})

    return ParsedConversation(id=conv_id, name=title, messages=messages,
                              source_format="copilot")


def _parse_copilot_nested(data: dict) -> list[ParsedConversation]:
    """
    Parse older Bing Chat nested format:
      {"conversations": [{"messages": [{"sender": "user"|"bot", "text": "..."}]}]}
    """
    result = []
    for i, conv in enumerate(data.get("conversations") or []):
        title   = conv.get("title") or conv.get("name") or f"Conversation {i + 1}"
        conv_id = conv.get("id") or conv.get("conversationId") or str(i)
        messages: list[dict] = []

        for msg in (conv.get("messages") or []):
            if not isinstance(msg, dict):
                continue
            sender = msg.get("sender") or msg.get("author") or msg.get("role") or ""
            if sender == "user":
                role = "user"
            elif sender in ("bot", "assistant", "copilot"):
                role = "assistant"
            else:
                continue
            text = str(msg.get("text") or msg.get("content") or "")
            if text.strip():
                messages.append({"role": role, "content": text})

        result.append(ParsedConversation(id=conv_id, name=title, messages=messages,
                                          source_format="copilot"))
    return result


def _parse_copilot(data: dict | list) -> list[ParsedConversation]:
    """Dispatch to flat or nested Copilot parser."""
    if isinstance(data, list):
        return [_parse_copilot_flat(c, i) for i, c in enumerate(data)
                if isinstance(c, dict)]
    if "conversations" in data:
        convs = data["conversations"]
        if convs and isinstance(convs[0], dict) and "messages" in convs[0]:
            msgs = convs[0]["messages"]
            if msgs and isinstance(msgs[0], dict) and "sender" in msgs[0]:
                return _parse_copilot_nested(data)
    return [_parse_copilot_flat(data)]


# ── Generic fallback ──────────────────────────────────────────────────────────

def _parse_messages_list(data: list) -> list[ParsedConversation]:
    """Parse a bare list of {role, content} dicts."""
    messages = []
    for m in data:
        role = m.get("role") or m.get("sender") or ""
        if role == "human":
            role = "user"
        content = m.get("content") or m.get("text") or ""
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": str(content)})
    return [ParsedConversation(id="conv_0", name="Conversation",
                               messages=messages, source_format="unknown")]


# ── ZIP extraction ────────────────────────────────────────────────────────────

_GEMINI_TAKEOUT_MARKER = "gemini"   # path component to identify Takeout ZIPs


def _is_gemini_takeout(zf: zipfile.ZipFile) -> bool:
    """True when the ZIP looks like a Google Takeout archive with Gemini data."""
    names = zf.namelist()
    return any(
        part.lower().startswith(_GEMINI_TAKEOUT_MARKER)
        for n in names
        for part in n.split("/")
    )


def _extract_zip(data: bytes, hint: str) -> tuple[list[ParsedConversation] | None, bytes | None]:
    """
    Open a ZIP and return either:
      - (conversations_list, None) for multi-file formats (Gemini Takeout)
      - (None, json_bytes)         for single-file formats (ChatGPT / Claude)

    Raises ValueError on unrecognised ZIP structure.
    """
    try:
        zf_io = io.BytesIO(data)
        with zipfile.ZipFile(zf_io) as zf:
            names = zf.namelist()

            # Gemini Takeout ZIP — extract all conversations from Gemini folder
            if hint == "gemini" or (hint == "auto" and _is_gemini_takeout(zf)):
                convs = _parse_gemini_takeout_zip(zf)
                if convs:
                    return convs, None
                # Fall through: maybe there's a conversations.json anyway

            # Standard single-file export (ChatGPT, Claude)
            target = next(
                (n for n in names if n.endswith("conversations.json")), None
            )
            if target:
                return None, zf.read(target)

            # No conversations.json — try any lone JSON file
            json_files = [n for n in names if n.lower().endswith(".json")]
            if len(json_files) == 1:
                return None, zf.read(json_files[0])

            # Multiple JSON files with no conversations.json — try as Gemini
            if json_files:
                with zipfile.ZipFile(zf_io) as zf2:
                    convs = _parse_gemini_takeout_zip(zf2)
                if convs:
                    return convs, None

            raise ValueError(
                "No recognisable conversation files found in ZIP. "
                f"Files present: {names[:10]}"
            )
    except zipfile.BadZipFile as e:
        raise ValueError(f"Could not open ZIP file: {e}") from e


# ── Public API ────────────────────────────────────────────────────────────────

def parse_bytes(data: bytes, hint: str = "auto") -> list[ParsedConversation]:
    """
    Parse conversation export bytes.  Handles JSON and ZIP.

    Args:
        data:  Raw file bytes.
        hint:  'chatgpt' | 'claude' | 'gemini' | 'copilot' | 'auto'

    Returns:
        List of ParsedConversation objects.  May be length 1 or many.

    Raises:
        ValueError if the format cannot be determined or is unsupported.
    """
    # ── ZIP handling ───────────────────────────────────────────────────────────
    if data[:2] == b"PK":
        convs, json_bytes = _extract_zip(data, hint)
        if convs is not None:
            return convs
        data = json_bytes  # continue with extracted JSON bytes

    # ── JSON parsing ───────────────────────────────────────────────────────────
    try:
        parsed_json = json.loads(data)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}") from e

    fmt = hint if hint != "auto" else auto_detect_format(parsed_json)

    # ── Dispatch by format ─────────────────────────────────────────────────────
    if fmt == "chatgpt":
        return _parse_chatgpt(parsed_json)
    if fmt == "chatgpt_single":
        return _parse_chatgpt_single_obj(parsed_json)
    if fmt == "claude":
        return _parse_claude(parsed_json)
    if fmt == "claude_list":
        return _parse_claude(parsed_json)
    if fmt in ("gemini", "gemini_list"):
        return _parse_gemini(parsed_json)
    if fmt in ("copilot", "copilot_nested"):
        return _parse_copilot(parsed_json)
    if fmt == "messages_list":
        return _parse_messages_list(parsed_json)

    # ── Last-resort structural probing ─────────────────────────────────────────
    if isinstance(parsed_json, list) and parsed_json:
        first = parsed_json[0]
        if isinstance(first, dict):
            if "mapping" in first:
                return _parse_chatgpt(parsed_json)
            if "chat_messages" in first:
                return _parse_claude(parsed_json)
            if _looks_gemini(first):
                return _parse_gemini(parsed_json)
            if _looks_copilot(first):
                return _parse_copilot(parsed_json)
            if first.get("role") in ("user", "assistant", "human"):
                return _parse_messages_list(parsed_json)

    if isinstance(parsed_json, dict):
        if "mapping" in parsed_json:
            return _parse_chatgpt_single_obj(parsed_json)
        if "conversations" in parsed_json:
            convs = parsed_json["conversations"]
            if convs and isinstance(convs[0], dict):
                if "chat_messages" in convs[0]:
                    return _parse_claude(parsed_json)
                msgs = convs[0].get("messages") or []
                if msgs and isinstance(msgs[0], dict) and "sender" in msgs[0]:
                    return _parse_copilot_nested(parsed_json)
        if "messages" in parsed_json:
            if _looks_gemini(parsed_json):
                return _parse_gemini(parsed_json)
            if _looks_copilot(parsed_json):
                return _parse_copilot(parsed_json)

    raise ValueError(
        "Could not detect conversation format. Supported: ChatGPT, Claude, "
        "Gemini (Google Takeout), Copilot/Bing Chat. "
        "Try selecting the format manually in the dropdown."
    )


def parse_file(path: str | Path) -> list[ParsedConversation]:
    """Convenience wrapper that reads a file and calls parse_bytes."""
    return parse_bytes(Path(path).read_bytes())
