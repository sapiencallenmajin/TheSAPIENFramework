# -*- mode: python ; coding: utf-8 -*-
# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# PyInstaller spec for the desktop app (Windows single-file exe)
#
# Usage (from project root):
#     pyinstaller app/drift_app.spec
#
# Or via the helper script:
#     python app/build.py
# ──────────────────────────────────────────────────────────────────────────────

from pathlib import Path
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

# SPECPATH is the directory containing this spec file (i.e. app/)
SPEC_DIR = Path(SPECPATH)
ROOT     = SPEC_DIR.parent     # project root
APP_DIR  = SPEC_DIR            # app/

# ── Hidden imports ─────────────────────────────────────────────────────────────
# collect_submodules guarantees every sub-package is included even when
# PyInstaller's static analysis misses a dynamic import.
_hidden = (
    collect_submodules("reportlab")   +
    collect_submodules("flask")       +
    collect_submodules("jinja2")      +
    collect_submodules("werkzeug")    +
    collect_submodules("cryptography") +
    # Collect all submodules in the reorganized local packages
    collect_submodules("core")        +
    collect_submodules("monitor")     +
    [
        # Pillow — used by report_generator for logo images
        "PIL", "PIL.Image", "PIL.ImageDraw", "PIL.ImageOps",
        # pkg_resources shim sometimes needed by cryptography / reportlab
        "pkg_resources.py2_compat",

        # ── Local project modules (new package structure) ──────────────────
        # core/ package
        "core.config",
        "core.test_engine",
        "core.drift_detector",
        "core.deterministic_scorer",
        "core.deterministic_signals",
        "core.scenarios",
        "core.report_generator",
        "core.api_helpers",
        "core.health_score",
        "core.judge_prompt",
        # monitor/ package
        "monitor.conversation_parser",
        "monitor.tenant_config",
        "monitor.drift_intervention",
        "monitor.compliance_model",
        "monitor.custom_policies",
        "monitor.hard_stops",
        "monitor.pressure_detection",
        "monitor.action_router",
        "monitor.drift_monitor",
        # app/ flat modules (APP_DIR is in pathex, so bare names still work)
        "license",
        "crypto",
        "key_manager",
        "telemetry",
        "telemetry_config",
    ]
)

# ── Extra data files ───────────────────────────────────────────────────────────
# reportlab bundles fonts and other resources that must travel with the exe
_extra_datas = collect_data_files("reportlab", include_py_files=False)

# ── Optional files (include only if present) ──────────────────────────────────
_opt_datas = []
_rubrics = ROOT / "scoring_rubrics.txt"
if _rubrics.exists():
    _opt_datas.append((str(_rubrics), "."))

_enc = APP_DIR / "scenarios.enc"
if _enc.exists():
    _opt_datas.append((str(_enc), "app"))

_icon_candidates = [
    APP_DIR / "icon.ico",
    ROOT  / "brands" / "synthreo_icon.ico",
]
_icon = next((str(p) for p in _icon_candidates if p.exists()), None)

# ── Analysis ───────────────────────────────────────────────────────────────────
a = Analysis(
    [str(APP_DIR / "drift_app.py")],

    # pathex lets PyInstaller find modules that live in ROOT (test_engine, etc.)
    # and APP_DIR (crypto, etc.) without package prefixes.
    pathex=[str(ROOT), str(APP_DIR)],

    binaries=[],

    datas=[
        # Flask / Jinja2 templates — bundled at app/templates/ in _MEIPASS
        (str(APP_DIR / "templates"),    "app/templates"),
        # Pre-built demo results — bundled at app/demo_results/ in _MEIPASS
        (str(APP_DIR / "demo_results"), "app/demo_results"),
        # Brand JSON configs
        (str(ROOT / "brands"),          "brands"),
        # License
        (str(ROOT / "LICENSE.md"),      "."),
        # ReportLab font / resource files
        *_extra_datas,
        # Optional extras
        *_opt_datas,
    ],

    hiddenimports=_hidden,

    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],

    # Exclude heavy packages that are never imported by the app
    excludes=[
        "tkinter", "matplotlib", "numpy", "pandas", "scipy",
        "notebook", "IPython", "pytest", "black", "mypy",
    ],

    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="SynthreoPulse",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    # console=True  — set True while debugging to see Flask startup errors
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    **( {"icon": _icon} if _icon else {} ),
)
