# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
# ──────────────────────────────────────────────────────────────────────────────
"""
app/telemetry_config.py
TelemetryConfig — environment-level gate for the telemetry flow.

Reads the SYNTHREO_TELEMETRY environment variable to determine telemetry mode:

  SYNTHREO_TELEMETRY=off  → is_disabled   (skip all telemetry, hide opt-in prompt)
  SYNTHREO_TELEMETRY=on   → is_forced_on  (skip opt-in prompt, always send)
  (not set / other value) → should_prompt (normal user consent flow)

is_dev is True when the app is running from source rather than a frozen
PyInstaller executable.  tag_payload() stamps this onto every outbound
payload so dev-environment noise can be filtered in the Supabase dashboard.

NOTE — Supabase schema requirement
  The drift_scans table needs an `is_dev` boolean column (default false).
  Add it manually:
      ALTER TABLE drift_scans ADD COLUMN IF NOT EXISTS is_dev boolean DEFAULT false;
  Do not add this column from application code.
"""

import os
import sys


class TelemetryConfig:
    """Gates the telemetry flow based on environment signals.

    Usage::

        telemetry_config = TelemetryConfig()

        # Gating send sites:
        if not telemetry_config.is_disabled:
            if telemetry_config.is_forced_on or cfg.get("telemetry_opted_in"):
                payload = build_payload(result, tier)
                telemetry_config.tag_payload(payload)
                send_telemetry(payload)

        # Gating opt-in prompt (passed to template / status endpoint):
        if telemetry_config.is_disabled or telemetry_config.is_forced_on:
            prompted, opted_in = True, telemetry_config.is_forced_on
        else:
            prompted = cfg["telemetry_prompted"]
            opted_in = cfg["telemetry_opted_in"]
    """

    def __init__(self) -> None:
        raw = os.environ.get("SYNTHREO_TELEMETRY", "").strip().lower()
        self._disabled  = raw == "off"
        self._forced_on = raw == "on"
        # is_dev: True when NOT running as a frozen PyInstaller executable
        self._is_dev = not getattr(sys, "frozen", False)

    # ── Mode properties ────────────────────────────────────────────────────────

    @property
    def is_disabled(self) -> bool:
        """No telemetry at all — don't show prompt, don't send anything."""
        return self._disabled

    @property
    def is_forced_on(self) -> bool:
        """Send telemetry unconditionally — skip the user opt-in prompt."""
        return self._forced_on and not self._disabled

    @property
    def should_prompt(self) -> bool:
        """Normal flow — show the opt-in dialog and respect the user's choice."""
        return not self._disabled and not self._forced_on

    @property
    def is_dev(self) -> bool:
        """True when running from source (not a PyInstaller bundle)."""
        return self._is_dev

    # ── Payload tagging ────────────────────────────────────────────────────────

    def tag_payload(self, payload: dict) -> dict:
        """Stamp *payload* with the is_dev flag in-place. Returns the same dict."""
        payload["is_dev"] = self._is_dev
        return payload
