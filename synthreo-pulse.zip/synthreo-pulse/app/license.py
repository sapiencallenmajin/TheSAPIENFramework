# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
# TODO v2: Replace local file backend with Synthreo Auth Server call — same interface,
# server returns tier + keys based on Synthreo account credentials.
"""
license.py
Synthreo Drift — License and tier management.

LicenseManager is the single abstraction for all tier and credential checks.
Consuming code calls get_tier(), is_feature_allowed(), get_api_keys() only —
never reads the license file directly — so the backend can be swapped (local
file → Synthreo Auth Server) without touching any call sites.
"""

import json
import logging
import os
import sys
from pathlib import Path

_LICENSE_FILE = Path.home() / ".synthreo" / "license.json"


def _license_file_path() -> Path:
    """Return the expected pulse.lic sentinel file path.

    When running as a PyInstaller exe, looks in the same directory as the
    executable so distributors can unlock Pro by dropping a blank pulse.lic file
    next to SynthreoPulse.exe.

    In dev mode, looks in the project root (same directory as license.py).
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent / "pulse.lic"
    # Dev mode: look next to drift_app.py (app/pulse.lic)
    return Path(__file__).resolve().parent / "app" / "pulse.lic"

_PRO_ONLY_FEATURES = {
    "dynamic",
    "pentest",
    "multi_model_comparison",
    "custom_thresholds",
    "live_monitoring",
    "tenant_config",
    "action_routing",
    "custom_policies",
    "dashboard_feed",
    "compliance_model",
    "regional_storage",
    "siem_integration",
}


class LicenseManager:
    """
    Synthreo tier and credential abstraction.

    v1 backend: local ~/.synthreo/license.json
        {"tier": "free"|"pro", "license_key": "...", "api_keys": {...}}

    v2 backend (TODO): POST to Synthreo Auth Server with stored credentials;
        server validates and returns {"tier": ..., "api_keys": {...}}.
        Swap _load() only — callers are unchanged.
    """

    def __init__(self):
        self._data = self._load()

    # ── Backend ──────────────────────────────────────────────────────────────

    def _load(self) -> dict:
        """Load license data from local file. Returns safe defaults on any failure."""
        if _LICENSE_FILE.exists():
            try:
                with open(_LICENSE_FILE) as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    return data
            except (OSError, json.JSONDecodeError) as e:
                logging.warning("Failed to load license file %s: %s", _LICENSE_FILE, e)
        return {"tier": "free", "api_keys": {}}

    # ── Public interface ──────────────────────────────────────────────────────

    def get_tier(self) -> str:
        """Returns 'free' or 'pro'. Defaults to 'free' for any unrecognised value.

        Priority order:
          1. SYNTHREO_TIER env var  (dev / CI override)
          2. pulse.lic sentinel file next to the executable  (distributor unlock)
          3. ~/.synthreo/license.json  (set via --set-license CLI)
          4. 'free' default
        """
        return self.get_tier_source()[0]

    def get_tier_source(self) -> tuple:
        """Return ``(tier, source)`` describing how the tier was resolved.

        *source* is a short human-readable string used in the startup log, e.g.:
          'SYNTHREO_TIER env', 'pulse.lic file', 'license.json', 'default'
        """
        # 1. Environment variable override (dev / CI)
        env_tier = os.environ.get("SYNTHREO_TIER", "").lower()
        if env_tier in ("free", "pro"):
            return env_tier, "SYNTHREO_TIER env"

        # 2. pulse.lic sentinel file next to the executable
        # TODO: Replace pulse.lic file check with Synthreo auth server license validation
        if _license_file_path().exists():
            return "pro", "pulse.lic file"

        # 3. Persisted license.json (written by --set-license CLI)
        tier = str(self._data.get("tier", "free")).lower()
        if tier not in ("free", "pro"):
            tier = "free"
        if _LICENSE_FILE.exists():
            return tier, "license.json"

        # 4. Default
        return "free", "default"

    def get_api_keys(self) -> dict:
        """Returns dict of provider API keys stored in the license record."""
        return dict(self._data.get("api_keys", {}))

    def is_feature_allowed(self, feature_name: str) -> bool:
        """
        Returns True if feature_name is available at the current tier.
        Free tier: vuln_scan, demo mode, PDF reports, standard scenarios.
        Pro tier: everything.
        """
        if self.get_tier() == "pro":
            return True
        return feature_name not in _PRO_ONLY_FEATURES

    # ── Admin helper (CLI / setup) ────────────────────────────────────────────

    @staticmethod
    def set_license(tier: str, key: str) -> None:
        """
        Persist tier and license key to the local config file.
        key is stored for future validation against the Synthreo Auth Server (v2).
        For v1 any non-empty key activates the requested tier.
        """
        tier = tier.lower()
        if tier not in ("free", "pro"):
            raise ValueError(f"Unknown tier: {tier!r}. Must be 'free' or 'pro'.")

        _LICENSE_FILE.parent.mkdir(parents=True, exist_ok=True)

        existing: dict = {}
        if _LICENSE_FILE.exists():
            try:
                with open(_LICENSE_FILE) as f:
                    existing = json.load(f)
            except (OSError, json.JSONDecodeError) as e:
                logging.warning("Failed to read existing license file %s: %s", _LICENSE_FILE, e)

        existing["tier"] = tier
        existing["license_key"] = key

        with open(_LICENSE_FILE, "w") as f:
            json.dump(existing, f, indent=2)

        print(f"Synthreo Pulse license set to: {tier.upper()}")
