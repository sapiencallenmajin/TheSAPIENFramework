# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
app/drift_app.py
Synthreo Drift Desktop App — Flask server.

Serves the dashboard UI and routes for scanning, reporting, and key management.
Entry point for PyInstaller .exe build.

Usage (dev):
    python app/drift_app.py

Usage (built exe):
    Double-click SynthreoD drift.exe  — opens browser automatically.
"""

import argparse
import csv
import io
import json
import logging
import os
import queue
import re
import subprocess
import sys
import tempfile
import traceback
import concurrent.futures
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

# ── Path setup ─────────────────────────────────────────────────────────────────
# When frozen by PyInstaller, __file__ resolves to the .exe itself and
# sys._MEIPASS is the temp dir where bundled files are extracted.
# Data files are bundled at their spec dest paths (e.g. "app/templates"),
# so _APP_DIR must point into sys._MEIPASS/app/ when frozen — not the exe dir.
if getattr(sys, "frozen", False):
    _BASE    = Path(sys._MEIPASS)
    _APP_DIR = _BASE / "app"
else:
    _APP_DIR    = Path(__file__).resolve().parent   # .../app/
    _PROJECT_DIR = _APP_DIR.parent
    _BASE        = _PROJECT_DIR

sys.path.insert(0, str(_BASE))

# Import TestEngine at module level while sys.path is explicitly set to _BASE,
# guaranteeing we always load from the project root and never from a worktree or cache.
from core.test_engine import TestEngine
from core.scenarios import SCENARIOS
from app.license import LicenseManager
import core.report_generator as rg
from monitor.conversation_parser import parse_bytes as _parse_bytes
from core.config import (
    DEFAULT_TARGET_MODEL,
    is_openai_model, is_gemini_model, is_mistral_model, is_xai_model, is_together_model,
)
from core.api_helpers import get_default_judge, MODEL_REGISTRY

from flask import (
    Flask, Response, jsonify, render_template, request,
    send_file, send_from_directory, stream_with_context,
)

# Crypto utilities (same package)
sys.path.insert(0, str(_APP_DIR))
from crypto import (
    store_api_key, retrieve_api_key, delete_api_key,
    list_stored_providers, mask_key,
)
from key_manager import KeyManager
from core.health_score import calculate_health_score as _calculate_health_score

# ── Config paths ───────────────────────────────────────────────────────────────

_CONFIG_DIR  = Path.home() / ".synthreo"
_CONFIG_DIR.mkdir(exist_ok=True)
_BRAND_FILE  = _CONFIG_DIR / "brand.json"
_CONFIG_FILE = _CONFIG_DIR / "config.json"
_RESULTS_DIR = _CONFIG_DIR / "results"
_RESULTS_DIR.mkdir(exist_ok=True)

_DEMO_DIR    = _APP_DIR / "demo_results"
_BRANDS_DIR  = _BASE / "brands"
_BRANDS_DIR.mkdir(parents=True, exist_ok=True)
_REPORTS_DIR = Path.home() / "Documents" / "DriftReports"
_REPORTS_DIR.mkdir(parents=True, exist_ok=True)

# ── License ────────────────────────────────────────────────────────────────────
_LICENSE = LicenseManager()

# ── App constants ──────────────────────────────────────────────────────────────
_PORT  = int(os.environ.get("DRIFT_PORT", "") or 8765)
_DEBUG = os.environ.get("DRIFT_DEBUG", "").lower() in ("1", "true", "yes")

logging.basicConfig(
    level=logging.DEBUG if _DEBUG else logging.INFO,
    format="%(levelname)s %(name)s: %(message)s",
)

# ── Flask app ──────────────────────────────────────────────────────────────────

app = Flask(__name__, template_folder=str(_APP_DIR / "templates"))
app.config["TEMPLATES_AUTO_RELOAD"] = _DEBUG
app.jinja_env.auto_reload = _DEBUG


def _load_or_create_secret_key() -> bytes:
    """Load a persistent Flask secret key from ~/.synthreo/flask_secret.key.
    Generates and saves a new random key on first run.
    """
    key_file = _CONFIG_DIR / "flask_secret.key"
    if key_file.exists():
        try:
            key = key_file.read_bytes()
            if len(key) >= 32:
                return key
        except Exception:
            pass
    key = os.urandom(32)
    key_file.write_bytes(key)
    try:
        key_file.chmod(0o600)   # owner read/write only (no-op on Windows)
    except Exception:
        pass
    return key


app.secret_key = _load_or_create_secret_key()

key_manager = KeyManager()

# ── DNS-rebinding / Host validation ───────────────────────────────────────────
_ALLOWED_HOSTS = {f"localhost:{_PORT}", f"127.0.0.1:{_PORT}"}


@app.before_request
def _check_host():
    """Reject requests whose Host header doesn't match the expected local origin.
    Protects against DNS-rebinding attacks where a remote page tricks the browser
    into issuing requests to the local server.
    """
    host = request.headers.get("Host", "")
    if not host or host not in _ALLOWED_HOSTS:
        return jsonify({"error": "Forbidden"}), 403

# ── Brand config ───────────────────────────────────────────────────────────────

_DEFAULT_BRAND = {
    "company_name":    "Synthreo",
    "company_tagline": "AI Behavioral Intelligence Platform",
    "company_website": "synthreo.ai",
    "company_phone":   "",
    "company_email":   "support@synthreo.ai",
    "primary_color":   "#0000d4",
    "secondary_color": "#a363ff",
    "accent_color":    "#00ff9e",
    "logo_path":       "brands/Synthreo_Icon_White.png",
    "logo_path_light": "brands/Synthreo_Icon_Night.png",
    "logo_url":        "",
    "footer_text":     "Generated by Synthreo Pulse · AI Behavioral Intelligence Platform",
}


def load_brand() -> dict:
    if _BRAND_FILE.exists():
        try:
            with open(_BRAND_FILE) as f:
                b = json.load(f)
            if not isinstance(b, dict):
                raise ValueError("brand.json root must be a JSON object")
            # Only keep known string-valued keys to prevent any pollution of app state
            allowed = set(_DEFAULT_BRAND.keys())
            sanitised = {k: str(v) for k, v in b.items() if k in allowed and v is not None}
            return {**_DEFAULT_BRAND, **sanitised}
        except Exception:
            pass
    return dict(_DEFAULT_BRAND)


def save_brand(data: dict) -> None:
    try:
        with open(_BRAND_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        logging.error("save_brand failed: %s", e)


def _brand_for_report() -> dict:
    """Brand dict with logo_path and logo_path_light resolved to absolute paths for report generator."""
    brand = load_brand()
    brand = dict(brand)
    for key in ("logo_path", "logo_path_light"):
        path_str = (brand.get(key) or "").strip()
        if path_str:
            p = Path(path_str)
            if not p.is_absolute():
                p = _BASE / path_str
            if p.exists():
                brand[key] = str(p)
    return brand


# ── App config (opt-ins, preferences) ─────────────────────────────────────────

_DEFAULT_CONFIG: dict = {
    "telemetry_opted_in":   False,
    "telemetry_prompted":   False,  # True once the consent dialog has been shown
    "judge_model":          None,   # None = auto-resolve from available keys at scan time
    "target_model":         None,   # None = use DEFAULT_TARGET_MODEL at scan time
    "scan_mode":            "vuln", # default assessment mode
}


def load_config() -> dict:
    if _CONFIG_FILE.exists():
        try:
            with open(_CONFIG_FILE) as f:
                c = json.load(f)
            if isinstance(c, dict):
                allowed = set(_DEFAULT_CONFIG.keys())
                return {**_DEFAULT_CONFIG, **{k: v for k, v in c.items() if k in allowed}}
        except Exception:
            pass
    return dict(_DEFAULT_CONFIG)


def save_config(data: dict) -> None:
    allowed = set(_DEFAULT_CONFIG.keys())
    try:
        with open(_CONFIG_FILE, "w") as f:
            json.dump({k: v for k, v in data.items() if k in allowed}, f, indent=2)
    except Exception as e:
        logging.error("save_config failed: %s", e)


# ── Telemetry ──────────────────────────────────────────────────────────────────

sys.path.insert(0, str(_APP_DIR))
from telemetry import build_payload as _build_payload, send_telemetry as _send_telemetry
from telemetry_config import TelemetryConfig

telemetry_config = TelemetryConfig()


def _fire_telemetry(result_dict: dict, tier: str) -> None:
    """Build payload, stamp with is_dev via TelemetryConfig, then send in a daemon thread."""
    import threading

    def _run() -> None:
        try:
            payload = _build_payload(result_dict, tier)
            telemetry_config.tag_payload(payload)
            _send_telemetry(payload)
        except Exception as exc:
            logging.debug("[telemetry] error: %s", exc)

    threading.Thread(target=_run, daemon=True).start()


# ── Health score injection ─────────────────────────────────────────────────────

def _inject_health_score(result_dict: dict) -> None:
    """Compute AI Behavioral Health Score from turn averages and inject into result_dict.

    Averages the four drift dimensions across all assistant turns that were
    actually scored (drift_score > 0 or flags present).  Falls back to
    averaging across *all* assistant turns if none were scored.
    Mutates result_dict in-place by adding a "health_score" key.
    """
    turns = [t for t in result_dict.get("turns", []) if t.get("role") == "assistant"]
    if not turns:
        result_dict["health_score"] = _calculate_health_score({})
        return

    dims = ("specificity_gradient", "risk_disclosure_absent",
            "epistemic_retreat", "emotional_substitution")
    avg: dict[str, float] = {}
    for d in dims:
        vals = [float(t.get(d) or 0.0) for t in turns]
        avg[d] = sum(vals) / len(vals) if vals else 0.0

    result_dict["health_score"] = _calculate_health_score(avg)


# ── Path helpers ───────────────────────────────────────────────────────────────

def _safe_file_in_dir(directory: Path, filename: str):
    """Resolve *filename* within *directory*, rejecting any path traversal.

    Uses werkzeug.utils.secure_filename to strip directory separators and
    null bytes, then verifies the resolved absolute path is still a descendant
    of *directory*.  Returns the resolved Path on success, or None if the
    filename is unsafe or the path would escape the directory.
    """
    from werkzeug.utils import secure_filename
    safe = secure_filename(filename)
    if not safe:
        return None
    resolved = (directory / safe).resolve()
    try:
        resolved.relative_to(directory.resolve())
    except ValueError:
        return None
    return resolved


# ── Routes ─────────────────────────────────────────────────────────────────────

# Old default primary colors we treat as "no custom brand" so UI uses Synthreo blue
_LEGACY_PRIMARY = ("", "#0D1F3C", "#B91C1C")


def _is_legacy_primary(color: str) -> bool:
    raw = (color or "").strip()
    return not raw or raw.upper() in ("#0D1F3C", "#B91C1C")


@app.route("/")
def index():
    brand = load_brand()
    # When no custom MSP brand is set, default --primary to Synthreo blue
    if _is_legacy_primary(brand.get("primary_color") or ""):
        brand = dict(brand)
        brand["primary_color"] = "#0000d4"
    logging.debug("Rendering index with tier: %s", _LICENSE.get_tier())
    cfg = load_config()
    # Resolve effective telemetry state for the template.
    # is_disabled  → pretend already prompted, not opted in (hides dialog, sends nothing)
    # is_forced_on → pretend already prompted, opted in    (hides dialog, always sends)
    # should_prompt → use stored config values              (shows dialog on first launch)
    if telemetry_config.is_disabled or telemetry_config.is_forced_on:
        telem_prompted = True
        telem_opted_in = telemetry_config.is_forced_on
    else:
        telem_prompted = cfg["telemetry_prompted"]
        telem_opted_in = cfg["telemetry_opted_in"]
    return render_template("index.html", brand=brand, tier=_LICENSE.get_tier(),
                           first_launch=not _BRAND_FILE.exists(),
                           telemetry_opted_in=telem_opted_in,
                           telemetry_prompted=telem_prompted)


@app.route("/api/brand", methods=["GET"])
def get_brand():
    return jsonify(load_brand())


@app.route("/api/brand", methods=["POST"])
def set_brand():
    data = request.json or {}
    allowed = set(_DEFAULT_BRAND.keys())
    incoming = {k: str(v) for k, v in data.items() if k in allowed and v is not None}
    # Merge into existing saved brand so partial POSTs don't erase other saved keys
    existing = load_brand()
    existing.update(incoming)
    save_brand({k: v for k, v in existing.items() if k in allowed})
    return jsonify({"ok": True})


@app.route("/api/brand/reset", methods=["POST"])
def reset_brand():
    """Clear saved brand and restore Synthreo defaults. Next load_brand() will return defaults."""
    save_brand(dict(_DEFAULT_BRAND))
    return jsonify({"ok": True})


_ALLOWED_LOGO_EXT = (".png", ".jpg", ".jpeg")


@app.route("/api/brand/logo", methods=["POST"])
def upload_brand_logo():
    """Accept a logo file (png or jpg), save to brands/ folder, update brand with logo_path and clear logo_url."""
    if "file" not in request.files and "logo" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    f = request.files.get("file") or request.files.get("logo")
    if not f or not f.filename:
        return jsonify({"error": "No file selected"}), 400
    ext = Path(f.filename).suffix.lower()
    if ext == ".svg":
        return jsonify({"error": "SVG files are not supported — PDF reports require a raster image. Please upload a PNG or JPG instead."}), 400
    if ext not in _ALLOWED_LOGO_EXT:
        return jsonify({"error": "Only PNG and JPG files are allowed"}), 400
    safe_name = f"logo_{os.urandom(4).hex()}{ext}"
    out_path = _BRANDS_DIR / safe_name
    try:
        f.save(str(out_path))
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    # Store path relative to app dir for portability
    rel_path = f"brands/{safe_name}"
    brand = load_brand()
    brand["logo_path"] = rel_path
    brand["logo_url"] = ""
    save_brand(brand)
    return jsonify({"ok": True, "logo_path": rel_path})


@app.route("/brand_logo")
def serve_brand_logo():
    """Serve the current brand logo image (from logo_path)."""
    brand = load_brand()
    path_str = brand.get("logo_path") or ""
    if not path_str:
        return "", 404
    path = Path(path_str)
    if not path.is_absolute():
        path = _BASE / path_str
    if not path.exists():
        return "", 404
    ext = path.suffix.lower()
    mimetype = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml"}.get(ext, "application/octet-stream")
    return send_file(str(path), mimetype=mimetype)


@app.route("/brands/<path:filename>")
def serve_brand_asset(filename):
    """Serve static brand assets (logos, icons) from the brands/ directory."""
    return send_from_directory(str(_BASE / "brands"), filename)


@app.route("/brand_logo/synthreo")
def serve_synthreo_logo():
    """Alias — always serve the Synthreo white logo."""
    return send_from_directory(str(_BASE / "brands"), "Synthreo_Icon_White.png")


# ── Scenario list ──────────────────────────────────────────────────────────────

@app.route("/api/scenarios")
def list_scenarios():
    result = [
        {"id": k, "name": v.name, "domain": v.domain, "description": v.description, "audience": v.audience, "escalation_count": len(v.escalations)}
        for k, v in SCENARIOS.items()
    ]
    return jsonify(result)


# ── Available models ───────────────────────────────────────────────────────────

# Hardcoded fallback used when all live API calls fail or no keys are configured
_MODELS_FALLBACK: dict[str, list[str]] = {
    "anthropic": [
        "claude-opus-4-6", "claude-sonnet-4-6", "claude-haiku-4-5-20251001",
    ],
    "openai": [
        "gpt-5.4", "gpt-5.4-pro", "gpt-5.3", "gpt-5.2", "gpt-5",
        "gpt-5-mini", "gpt-5-nano", "gpt-4o", "gpt-4o-mini",
        "gpt-4.1", "gpt-4.1-mini", "o3", "o4-mini",
    ],
    "google": [
        "gemini-3.1-pro-preview", "gemini-3-flash-preview",
        "gemini-3.1-flash-lite", "gemini-2.5-pro", "gemini-2.5-flash",
        "gemini-2.0-flash",
    ],
}

# 1-hour in-memory cache — pre-warmed with fallback so the first HTTP call
# returns immediately; a background thread overwrites with live data.
_models_cache: dict        = {**{p: list(v) for p, v in _MODELS_FALLBACK.items()},
                               "errors": {}, "source": "startup-fallback"}
_models_cache_time: float  = time.time()
_MODELS_CACHE_TTL: float   = 3600.0

# OpenAI: keep only chat/completion model IDs
_OAI_KEEP_RE    = re.compile(r"^(gpt-|o[0-9]|chatgpt-)", re.IGNORECASE)
_OAI_EXCLUDE_RE = re.compile(
    r"instruct|realtime|audio|tts|whisper|embedding|dall-e|"
    r"davinci|babbage|curie|ada-|moderation",
    re.IGNORECASE,
)


def _fetch_anthropic_models(api_key: str) -> list[str]:
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/models",
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
    )
    with urllib.request.urlopen(req, timeout=8) as resp:
        data = json.loads(resp.read())
    return sorted(
        {m["id"] for m in (data.get("data") or [])
         if isinstance(m, dict) and m.get("id", "").startswith("claude-")},
        reverse=True,
    )


def _fetch_openai_models(api_key: str) -> list[str]:
    req = urllib.request.Request(
        "https://api.openai.com/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
    )
    with urllib.request.urlopen(req, timeout=8) as resp:
        data = json.loads(resp.read())
    return sorted(
        {m["id"] for m in (data.get("data") or [])
         if isinstance(m, dict)
         and _OAI_KEEP_RE.match(m.get("id", ""))
         and not _OAI_EXCLUDE_RE.search(m.get("id", ""))},
        reverse=True,
    )


def _fetch_google_models(api_key: str) -> list[str]:
    url = (
        "https://generativelanguage.googleapis.com/v1beta/models"
        f"?key={urllib.request.quote(api_key, safe='')}"
    )
    with urllib.request.urlopen(url, timeout=8) as resp:
        data = json.loads(resp.read())
    models = []
    for m in (data.get("models") or []):
        if not isinstance(m, dict):
            continue
        name    = m.get("name", "")
        methods = m.get("supportedGenerationMethods") or []
        if "generateContent" in methods and "gemini" in name.lower():
            models.append(name.split("/")[-1])   # strip "models/" prefix
    return sorted(set(models), reverse=True)


def _resolve_key(env_var: str, stored_provider: str) -> str:
    """Return API key via KeyManager (env var takes priority over stored key)."""
    return key_manager.get_key(stored_provider)


def _fetch_models_live() -> tuple[dict[str, list[str]], dict[str, str]]:
    """Query each provider whose key is configured in parallel. Returns (models, errors)."""
    specs = [
        ("anthropic", _resolve_key("ANTHROPIC_API_KEY", "anthropic"), _fetch_anthropic_models),
        ("openai",    _resolve_key("OPENAI_API_KEY",    "openai"),    _fetch_openai_models),
        ("google",    _resolve_key("GOOGLE_API_KEY",    "google"),    _fetch_google_models),
    ]
    models: dict[str, list[str]] = {}
    errors: dict[str, str]       = {}

    def _fetch_one(provider, key, fetch_fn):
        if not key:
            return provider, [], None
        try:
            return provider, fetch_fn(key), None
        except Exception as exc:
            return provider, [], str(exc)

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for provider, model_list, error in pool.map(
            lambda s: _fetch_one(*s), specs
        ):
            models[provider] = model_list
            if error:
                errors[provider] = error

    return models, errors


@app.route("/api/models")
def list_models():
    global _models_cache, _models_cache_time

    now = time.time()
    if _models_cache is not None and (now - _models_cache_time) < _MODELS_CACHE_TTL:
        return jsonify(_models_cache)

    models, errors = _fetch_models_live()

    # Fill any provider that returned nothing (no key or API error) with fallback
    for provider, fallback in _MODELS_FALLBACK.items():
        if not models.get(provider):
            models[provider] = fallback

    source = "fallback" if errors or all(
        models[p] == _MODELS_FALLBACK[p] for p in _MODELS_FALLBACK
    ) else "live"

    result: dict = {**models, "errors": errors, "source": source}
    _models_cache      = result
    _models_cache_time = now
    return jsonify(result)


@app.route("/api/models/refresh", methods=["POST"])
def refresh_models():
    """Bust the model cache and return fresh results immediately."""
    global _models_cache, _models_cache_time
    _models_cache      = None
    _models_cache_time = 0.0
    # Reuse the normal endpoint logic
    return list_models()


# ── License tier ────────────────────────────────────────────────────────────────

@app.route("/api/tier")
def get_tier():
    return jsonify({"tier": _LICENSE.get_tier()})


# ── Telemetry consent ──────────────────────────────────────────────────────────

@app.route("/api/telemetry/status", methods=["GET"])
def telemetry_status():
    cfg = load_config()
    if telemetry_config.is_disabled or telemetry_config.is_forced_on:
        return jsonify({
            "opted_in": telemetry_config.is_forced_on,
            "prompted": True,
        })
    return jsonify({
        "opted_in": cfg["telemetry_opted_in"],
        "prompted": cfg["telemetry_prompted"],
    })


@app.route("/api/telemetry/consent", methods=["POST"])
def telemetry_consent():
    """Save user's telemetry opt-in preference and mark dialog as shown."""
    if telemetry_config.is_disabled or telemetry_config.is_forced_on:
        # Consent is irrelevant when telemetry is env-controlled — no-op.
        return jsonify({"ok": True, "opted_in": telemetry_config.is_forced_on})
    data    = request.json or {}
    opt_in  = bool(data.get("opted_in", False))
    cfg     = load_config()
    cfg["telemetry_opted_in"] = opt_in
    cfg["telemetry_prompted"] = True
    save_config(cfg)
    return jsonify({"ok": True, "opted_in": opt_in})


# ── Config API ─────────────────────────────────────────────────────────────────

@app.route("/api/config", methods=["GET"])
def get_config():
    """Return current persisted config (excluding telemetry fields)."""
    cfg = load_config()
    return jsonify({k: cfg[k] for k in ("judge_model", "target_model", "scan_mode")})


@app.route("/api/config", methods=["POST"])
def update_config():
    """Persist a partial config update. Only whitelisted keys are written."""
    data = request.json or {}
    cfg  = load_config()
    for k in ("judge_model", "target_model", "scan_mode"):
        if k in data:
            cfg[k] = data[k]
    save_config(cfg)
    return jsonify({"ok": True})


# ── API key management ─────────────────────────────────────────────────────────

@app.route("/api/keys")
def get_keys():
    return jsonify({
        "keys":        key_manager.masked_keys(),
        "sources":     key_manager.key_sources(),
        "needs_setup": key_manager.needs_first_run_setup(),
    })


@app.route("/api/keys", methods=["POST"])
def save_key():
    data     = request.get_json() or {}
    provider = data.get("provider", "").lower()
    key      = data.get("key", "").strip()
    if not provider or not key:
        return jsonify({"error": "Provider and key are required"}), 400
    valid, msg = key_manager.validate_key(provider, key)
    if not valid:
        return jsonify({"error": msg, "valid": False}), 400
    key_manager.set_key(provider, key)
    return jsonify({"valid": True, "message": msg, "masked": key_manager.masked_keys()[provider]})


@app.route("/api/keys/<provider>", methods=["DELETE"])
def delete_key(provider):
    key_manager.delete_key(provider)
    return jsonify({"deleted": True})


# ── Scan (SSE) ─────────────────────────────────────────────────────────────────

# Queue per scan_id for SSE events
_scan_queues: dict[str, queue.Queue] = {}
_scan_results: dict[str, dict] = {}

# ── Audit state ────────────────────────────────────────────────────────────────
_audit_queues:        dict[str, queue.Queue]       = {}
_audit_cancel_events: dict[str, threading.Event]  = {}
# upload_id -> list of ParsedConversation objects
_upload_cache: dict[str, list] = {}


def _auto_generate_report(result_dict: dict, emit, tier: str = "free") -> None:
    """Build a PDF from result_dict and save it to _REPORTS_DIR, then emit report_saved."""
    try:
        name_raw  = result_dict.get("scenario_name") or result_dict.get("topic") or "scan"
        model_raw = result_dict.get("model") or "unknown"
        name_slug  = re.sub(r"[^a-z0-9]+", "_", name_raw.lower()).strip("_")[:40]
        model_slug = re.sub(r"[^a-z0-9]+", "-", model_raw.lower()).strip("-")[:30]
        date_str   = datetime.now().strftime("%Y-%m-%d")
        pdf_filename = f"drift_report_{name_slug}_{model_slug}_{date_str}.pdf"

        # Avoid overwriting an earlier run from the same day
        pdf_path = _REPORTS_DIR / pdf_filename
        if pdf_path.exists():
            ts = datetime.now().strftime("%H%M%S")
            pdf_filename = f"drift_report_{name_slug}_{model_slug}_{date_str}_{ts}.pdf"
            pdf_path = _REPORTS_DIR / pdf_filename

        with tempfile.TemporaryDirectory() as _td:
            tmp_dir  = Path(_td)
            tmp_json = tmp_dir / "result.json"
            with open(tmp_json, "w") as f:
                json.dump(result_dict, f, default=str)

            brand_tmp = tmp_dir / "brand.json"
            with open(brand_tmp, "w") as f:
                json.dump(_brand_for_report(), f)

            brand_obj = rg.load_brand_config(str(brand_tmp))
            rg._setup_brand(brand_obj)
            rg._setup_tier(tier)
            loaded = rg.load_results([str(tmp_json)])

            customer = "Customer"
            msp      = load_brand().get("company_name", "Synthreo.ai")
            doc      = rg.DriftReport(str(pdf_path), customer=customer)
            story    = []
            story   += rg.build_cover(customer, msp, loaded)
            story   += rg.build_education_page()
            story   += rg.build_exec_brief(loaded, customer)
            story   += rg.build_scorecard(loaded)
            story   += rg.build_domain_breakdown(loaded)
            story   += rg.build_methodology()
            story   += rg.build_recommendations_section(loaded, customer)
            story   += rg.build_appendix(loaded)
            doc.build(story)

        emit("report_saved", {"path": str(pdf_path), "filename": pdf_filename})

    except Exception as e:
        logging.error("[report_error] %s\n%s", e, traceback.format_exc())
        emit("report_error", {"message": str(e)})


def _run_scan(scan_id: str, mode: str, scenario_id: str, model: str,
              topic: str, domain: str, persona: str,
              api_key: str, openai_key: str, google_key: str,
              mistral_key: str = "", xai_key: str = "", together_key: str = "",
              judge_model: str = ""):
    """Run the test engine in a background thread, emitting SSE events."""
    q = _scan_queues[scan_id]

    def emit(event: str, data: dict):
        q.put({"event": event, "data": data})

    try:
        # Gate Pro-only modes before creating the engine or making any API calls
        if mode in ("dynamic", "pentest") and not _LICENSE.is_feature_allowed(mode):
            emit("error", {"message": (
                "Dynamic and Pentest modes available with Synthreo Pro — "
                "contact your Synthreo representative."
            )})
            return

        def on_turn(turn):
            # TestEngine calls on_turn(turn) with one arg; scores and metadata are attrs
            emit("turn", {
                "index":                  turn.index,
                "phase":                  getattr(turn, "phase", ""),
                "mode":                   getattr(turn, "mode", ""),
                "role":                   getattr(turn, "role", ""),
                "pressure_type":          getattr(turn, "pressure_type", ""),
                "pressure_severity":      getattr(turn, "pressure_severity", 0) or 0,
                # Conversation content
                "prompt":                 getattr(turn, "prompt", ""),
                "content":                getattr(turn, "content", ""),
                # Scoring
                "drift_score":            getattr(turn, "drift_score", 0) or 0,
                "epistemic_retreat":      getattr(turn, "epistemic_retreat", 0) or 0,
                "risk_disclosure_absent": getattr(turn, "risk_disclosure_absent", 0) or 0,
                "specificity_gradient":   getattr(turn, "specificity_gradient", 0) or 0,
                "emotional_substitution": getattr(turn, "emotional_substitution", 0) or 0,
                "tier":                   getattr(turn, "tier", 1) or 1,
                "flags":                  getattr(turn, "flags", []),
                "refusal_detected":       getattr(turn, "refusal_detected", False),
            })

        emit("status", {"message": f"Initializing {mode.upper()} scan..."})

        # Resolve judge model: explicit request > saved config > auto-default from keys
        _api_keys = {"anthropic": api_key or "", "openai": openai_key or "", "google": google_key or ""}
        resolved_judge = judge_model or load_config().get("judge_model") or get_default_judge(_api_keys)

        engine = TestEngine(
            api_key=api_key,
            target_model=model,
            on_turn=on_turn,
            verbose=False,
            openai_api_key=openai_key,
            google_api_key=google_key,
            mistral_api_key=mistral_key,
            xai_api_key=xai_key,
            together_api_key=together_key,
            judge_model=resolved_judge or None,
        )

        if mode in ("vuln", "dynamic"):
            scenario = SCENARIOS.get(scenario_id)
            if not scenario:
                emit("error", {"message": f"Scenario '{scenario_id}' not found"})
                return
            # Human-friendly mode label for status text (internal codes remain vuln/dynamic)
            mode_label = {
                "vuln": "Safety Assessment",
                "dynamic": "Adaptive Pressure Probe",
            }.get(mode, mode.upper())
            emit("status", {"message": f"Running {mode_label}: {scenario.name}..."})
            if mode == "vuln":
                result = engine.vuln_scan(scenario)
            else:
                result = engine.dynamic(scenario)
        elif mode == "pentest":
            emit("status", {"message": "Running Safety Exercise..."})
            result = engine.pentest(topic=topic, domain=domain, persona=persona or None)
        else:
            emit("error", {"message": f"Unknown mode: {mode}"})
            return

        result_dict = asdict(result)
        _inject_health_score(result_dict)

        # Inject judge model metadata (not part of TestResult dataclass)
        if engine.judge_model:
            entry = MODEL_REGISTRY.get(engine.judge_model, {})
            result_dict["judge_model"]    = engine.judge_model
            result_dict["judge_provider"] = entry.get("provider", "")

        # Save to results dir
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_path = _RESULTS_DIR / f"{mode}_{ts}_{scan_id[:6]}.json"
        with open(out_path, "w") as f:
            json.dump(result_dict, f, indent=2, default=str)

        _scan_results[scan_id] = result_dict
        emit("complete", {"result": result_dict, "saved_path": str(out_path)})

        # Fire telemetry in background if user opted in (never blocks the UI)
        _cfg = load_config()
        logging.debug("[telemetry] scan complete — opted_in=%s, prompted=%s, forced=%s, disabled=%s",
                      _cfg.get('telemetry_opted_in'), _cfg.get('telemetry_prompted'),
                      telemetry_config.is_forced_on, telemetry_config.is_disabled)
        if not telemetry_config.is_disabled:
            if telemetry_config.is_forced_on or _cfg.get("telemetry_opted_in"):
                _fire_telemetry(result_dict, _LICENSE.get_tier())

        # Auto-generate PDF — emits report_saved or report_error before the sentinel
        _auto_generate_report(result_dict, emit, _LICENSE.get_tier())

    except Exception as e:
        logging.error("[scan_error] %s\n%s", e, traceback.format_exc())
        emit("error", {"message": str(e)})
    finally:
        q.put(None)  # sentinel
        _scan_queues.pop(scan_id, None)


def _run_batch(
    batch_scan_id: str,
    mode: str,
    scenario_id: str,
    models: list[dict],
    topic: str,
    domain: str,
    persona: str,
    api_key: str,
    openai_key: str,
    google_key: str,
    mistral_key: str = "",
    xai_key: str = "",
    together_key: str = "",
    judge_model: str = "",
) -> None:
    """Run the same scenario against each model sequentially, forward events to batch queue, then generate comparison report."""
    batch_q = _scan_queues.get(batch_scan_id)
    if not batch_q:
        return

    def emit(event: str, data: dict):
        batch_q.put({"event": event, "data": data})

    saved_paths: list[str] = []
    result_summaries: list[dict] = []
    # Normalize to list and ensure we process every model
    model_list = [m for m in models if isinstance(m, dict) and (m.get("model") or m.get("target_model"))]
    total = len(model_list)

    try:
        for idx in range(total):
            model_obj = model_list[idx]
            model = model_obj.get("model") or model_obj.get("target_model") or ""
            if not model:
                continue
            logging.debug("BATCH: Starting model %d of %d: %s", idx + 1, total, model)
            emit("batch_progress", {
                "current_model_index": idx + 1,
                "total_models": total,
                "model_name": model,
                "status": "running",
            })

            sub_scan_id = f"{batch_scan_id}_{idx}"
            sub_q = queue.Queue()
            _scan_queues[sub_scan_id] = sub_q

            t = threading.Thread(
                target=_run_scan,
                args=(sub_scan_id, mode, scenario_id, model, topic, domain, persona,
                      api_key, openai_key, google_key, mistral_key, xai_key, together_key,
                      judge_model),
                daemon=True,
            )
            t.start()

            child_error = False
            while True:
                item = sub_q.get()
                if item is None:
                    break
                if item["event"] == "error":
                    child_error = True
                if item["event"] == "complete":
                    d = item["data"]
                    saved_paths.append(d.get("saved_path", ""))
                    r = d.get("result") or {}
                    result_summaries.append({
                        "scenario_name": r.get("scenario_name") or r.get("topic", "—"),
                        "model": r.get("model", "—"),
                        "verdict": r.get("verdict", "—"),
                        "peak_drift": r.get("peak_drift"),
                        "filename": Path(d.get("saved_path", "")).name,
                    })
                # Forward as "model_error" so the client doesn't close EventSource on child failure
                out = item if item["event"] != "error" else {"event": "model_error", "data": item["data"]}
                batch_q.put(out)

            del _scan_queues[sub_scan_id]
            if child_error:
                emit("batch_complete", {
                    "comparison_report_path": None,
                    "comparison_report_filename": None,
                    "result_summaries": result_summaries,
                    "error": "A model run failed; batch stopped.",
                })
                batch_q.put(None)
                return

        if len(saved_paths) < 2:
            emit("batch_complete", {
                "comparison_report_path": None,
                "comparison_report_filename": None,
                "result_summaries": result_summaries,
                "error": "Need at least 2 successful runs to generate comparison report.",
            })
            batch_q.put(None)
            return

        result_ids = [Path(p).name for p in saved_paths if p]
        results = []
        for name in result_ids:
            path = _RESULTS_DIR / Path(name).name
            if path.exists():
                try:
                    with open(path) as f:
                        results.append(json.load(f))
                except Exception:
                    pass

        if len(results) < 2:
            emit("batch_complete", {
                "comparison_report_path": None,
                "comparison_report_filename": None,
                "result_summaries": result_summaries,
                "error": "Could not load enough results for comparison.",
            })
            batch_q.put(None)
            return

        _REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_path = _REPORTS_DIR / f"comparison_{ts}.pdf"
        customer = "Customer"
        msp = load_brand().get("company_name", "Synthreo.ai")

        with tempfile.TemporaryDirectory() as _td:
            tmp_dir = Path(_td)
            brand_tmp = tmp_dir / "brand.json"
            with open(brand_tmp, "w") as f:
                json.dump(_brand_for_report(), f)

            brand_obj = rg.load_brand_config(str(brand_tmp))
            rg._setup_brand(brand_obj)
            rg._setup_tier(_LICENSE.get_tier())
            rg.generate_comparison_report(str(out_path), results, customer, msp)

        emit("batch_complete", {
            "comparison_report_path": str(out_path),
            "comparison_report_filename": out_path.name,
            "result_summaries": result_summaries,
        })
    except Exception as e:
        logging.error("[batch_error] %s\n%s", e, traceback.format_exc())
        emit("error", {"message": str(e)})
    finally:
        batch_q.put(None)


@app.route("/api/scan/batch", methods=["POST"])
def start_batch_scan():
    if _LICENSE.get_tier() != "pro":
        return jsonify({"error": "Batch scan available with Synthreo Pro"}), 403

    data = request.json or {}
    mode = data.get("mode", "vuln")
    scenario_id = data.get("scenario_id", "")
    raw_models = data.get("models", [])
    models = list(raw_models) if isinstance(raw_models, list) else []
    topic = data.get("topic", "")
    domain = data.get("domain", "general")
    persona = data.get("persona", "")

    if len(models) < 2:
        return jsonify({"error": "At least two models required"}), 400
    if mode not in ("pentest",) and not scenario_id:
        return jsonify({"error": "scenario_id required for this mode"}), 400

    api_key     = data.get("anthropic_key") or key_manager.get_key("anthropic")
    openai_key  = data.get("openai_key")    or key_manager.get_key("openai")
    google_key  = data.get("google_key")    or key_manager.get_key("google")
    mistral_key = key_manager.get_key("mistral") or ""
    xai_key     = key_manager.get_key("xai")     or ""
    together_key = key_manager.get_key("together") or ""
    judge_model = data.get("judge_model") or ""

    batch_scan_id = "batch_" + os.urandom(4).hex()
    _scan_queues[batch_scan_id] = queue.Queue()

    t = threading.Thread(
        target=_run_batch,
        args=(batch_scan_id, mode, scenario_id, models, topic, domain, persona,
              api_key, openai_key, google_key, mistral_key, xai_key, together_key,
              judge_model),
        daemon=True,
    )
    t.start()
    return jsonify({"scan_id": batch_scan_id})


@app.route("/api/scan/start", methods=["POST"])
def start_scan():
    data       = request.json or {}
    mode       = data.get("mode", "vuln")
    scenario_id = data.get("scenario_id", "")
    model      = data.get("model") or DEFAULT_TARGET_MODEL
    topic      = data.get("topic", "")
    domain     = data.get("domain", "general")
    persona    = data.get("persona", "")

    # Resolve API keys: request body takes priority, then stored keys
    api_key     = data.get("anthropic_key") or key_manager.get_key("anthropic")
    openai_key  = data.get("openai_key")    or key_manager.get_key("openai")
    google_key  = data.get("google_key")    or key_manager.get_key("google")
    mistral_key = key_manager.get_key("mistral") or ""
    xai_key     = key_manager.get_key("xai")     or ""
    together_key = key_manager.get_key("together") or ""
    judge_model = data.get("judge_model") or ""

    # Guard: reject immediately if the selected model's provider has no key
    if is_openai_model(model):
        if not openai_key:
            return jsonify({"error": "No API key configured for OpenAI. Add your key in Settings."}), 400
    elif is_gemini_model(model):
        if not google_key:
            return jsonify({"error": "No API key configured for Google. Add your key in Settings."}), 400
    elif is_mistral_model(model):
        if not mistral_key:
            return jsonify({"error": "No API key configured for Mistral. Add your key in Settings."}), 400
    elif is_xai_model(model):
        if not xai_key:
            return jsonify({"error": "No API key configured for xAI. Add your key in Settings."}), 400
    elif is_together_model(model):
        if not together_key:
            return jsonify({"error": "No API key configured for Together AI. Add your key in Settings."}), 400
    else:
        # Default: Anthropic
        if not api_key:
            return jsonify({"error": "No API key configured for Anthropic. Add your key in Settings."}), 400

    scan_id = os.urandom(4).hex()
    _scan_queues[scan_id] = queue.Queue()

    t = threading.Thread(
        target=_run_scan,
        args=(scan_id, mode, scenario_id, model, topic, domain, persona,
              api_key, openai_key, google_key, mistral_key, xai_key, together_key,
              judge_model),
        daemon=True,
    )
    t.start()
    return jsonify({"scan_id": scan_id})


@app.route("/api/scan/stream/<scan_id>")
def scan_stream(scan_id):
    """SSE endpoint — client connects here to receive live turn events."""
    q = _scan_queues.get(scan_id)
    if not q:
        return jsonify({"error": "Unknown scan_id"}), 404

    def generate():
        while True:
            item = q.get()
            if item is None:
                yield "event: done\ndata: {}\n\n"
                break
            event = item["event"]
            data  = json.dumps(item["data"])
            yield f"event: {event}\ndata: {data}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control":  "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ── Demo results ───────────────────────────────────────────────────────────────

@app.route("/api/demo/list")
def demo_list():
    files = sorted(_DEMO_DIR.glob("*.json")) if _DEMO_DIR.exists() else []
    results = []
    for f in files:
        try:
            with open(f) as fp:
                d = json.load(fp)
            results.append({
                "filename": f.name,
                "scenario_name": d.get("scenario_name") or d.get("topic") or f.stem,
                "domain":   d.get("domain", "—"),
                "model":    d.get("model", "—"),
                "verdict":  d.get("verdict", "—"),
                "peak_drift": d.get("peak_drift", 0),
            })
        except Exception:
            pass
    return jsonify(results)


@app.route("/api/demo/load/<filename>")
def demo_load(filename):
    path = _safe_file_in_dir(_DEMO_DIR, filename)
    if path is None or not path.exists() or path.suffix != ".json":
        return jsonify({"error": "Not found"}), 404
    with open(path) as f:
        return jsonify(json.load(f))


@app.route("/api/demo/save", methods=["POST"])
def demo_save():
    """Promote a saved result to a demo by copying it into demo_results/."""
    data = request.json or {}
    filename = (data.get("filename") or "").strip()
    if not filename:
        return jsonify({"error": "filename required"}), 400

    src = _safe_file_in_dir(_RESULTS_DIR, filename)
    if src is None or not src.exists():
        return jsonify({"error": "result not found"}), 404

    with open(src, encoding="utf-8") as f:
        result = json.load(f)

    # Keep only conversation + scoring fields — no internal scan metadata
    _DEMO_KEEP = {
        "run_id", "mode", "model", "domain", "started_at", "completed_at",
        "scenario_name", "topic", "pivot_topic", "persona",
        "verdict", "summary", "defend_mode", "grounding_injected", "grounding_message",
        "turns", "conversation", "drift_scores", "peak_drift", "cumulative_drift",
        "first_drift_turn", "break_turn", "recovery_turn", "pivot_turn", "health_score",
    }
    demo_data = {k: v for k, v in result.items() if k in _DEMO_KEEP}

    # Build a descriptive filename: demo_{scenario}_{verdict}.json
    scenario = re.sub(r"[^\w]", "_", (result.get("scenario_name") or "unknown").lower())
    verdict  = (result.get("verdict") or "unknown").lower()
    base     = f"demo_{scenario}_{verdict}"
    dest     = _DEMO_DIR / f"{base}.json"

    # Disambiguate if a file with that name already exists (different model)
    if dest.exists():
        model_slug = re.sub(r"[^\w]", "_", (result.get("model") or "model").lower())
        dest = _DEMO_DIR / f"{base}_{model_slug}.json"

    _DEMO_DIR.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(demo_data, indent=2, ensure_ascii=False), encoding="utf-8")

    return jsonify({"filename": dest.name, "message": f"Saved as demo: {dest.name}"})


@app.route("/api/audit/save", methods=["POST"])
def audit_save():
    """Explicitly save a completed audit result to the results directory."""
    data   = request.json or {}
    result = data.get("result")
    if not result or not isinstance(result, dict):
        return jsonify({"error": "result required"}), 400

    result["source"] = "audit"   # ensure field is present

    src_fmt = re.sub(r"[^\w]", "_", (result.get("source_format") or "conversation").lower())
    ts      = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"audit_{src_fmt}_{ts}.json"

    _RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    dest = _RESULTS_DIR / filename
    dest.write_text(json.dumps(result, indent=2, default=str, ensure_ascii=False),
                    encoding="utf-8")
    return jsonify({"filename": filename, "message": "Saved"})


# ── Saved results list ─────────────────────────────────────────────────────────

@app.route("/api/results")
def list_results():
    files = sorted(_RESULTS_DIR.glob("*.json"), reverse=True)
    results = []
    for f in files:
        try:
            with open(f) as fp:
                d = json.load(fp)
            results.append({
                "filename":     f.name,
                "scenario_name": d.get("scenario_name") or d.get("topic") or f.stem,
                "domain":        d.get("domain", "—"),
                "model":         d.get("model", "—"),
                "verdict":       d.get("verdict", "—"),
                "peak_drift":    d.get("peak_drift", 0),
                "started_at":    d.get("started_at", ""),
                "source":        d.get("source", "scan"),
                "health_score":  d.get("health_score"),
            })
        except Exception:
            pass
    return jsonify(results)


@app.route("/api/results/<filename>")
def get_result(filename):
    path = _safe_file_in_dir(_RESULTS_DIR, filename)
    if path is None or not path.exists():
        return jsonify({"error": "Not found"}), 404
    with open(path) as f:
        return jsonify(json.load(f))


@app.route("/api/results/<filename>", methods=["DELETE"])
def delete_result(filename):
    path = _safe_file_in_dir(_RESULTS_DIR, filename)
    if path is None or not path.exists():
        return jsonify({"error": "Not found"}), 404
    path.unlink()
    return jsonify({"deleted": filename})


@app.route("/api/demo/<filename>", methods=["DELETE"])
def delete_demo(filename):
    path = _safe_file_in_dir(_DEMO_DIR, filename)
    if path is None or not path.exists():
        return jsonify({"error": "Not found"}), 404
    path.unlink()
    return jsonify({"deleted": filename})


# ── Export ─────────────────────────────────────────────────────────────────────

@app.route("/api/export/json", methods=["POST"])
def export_json():
    data    = request.json or {}
    results = data.get("results", [])
    if not results:
        return jsonify({"error": "No results provided"}), 400
    payload  = json.dumps(results, indent=2, default=str)
    buf      = io.BytesIO(payload.encode())
    filename = f"drift_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    return send_file(buf, mimetype="application/json",
                     as_attachment=True, download_name=filename)


@app.route("/api/export/csv", methods=["POST"])
def export_csv():
    data    = request.json or {}
    results = data.get("results", [])
    if not results:
        return jsonify({"error": "No results provided"}), 400

    buf    = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["run_id", "mode", "model", "domain", "scenario_name",
                     "verdict", "peak_drift", "cumulative_drift",
                     "first_drift_turn", "started_at"])
    for r in results:
        writer.writerow([
            r.get("run_id", ""), r.get("mode", ""), r.get("model", ""),
            r.get("domain", ""), r.get("scenario_name") or r.get("topic", ""),
            r.get("verdict", ""), r.get("peak_drift", ""),
            r.get("cumulative_drift", ""), r.get("first_drift_turn", ""),
            r.get("started_at", ""),
        ])

    out      = io.BytesIO(buf.getvalue().encode())
    filename = f"drift_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    return send_file(out, mimetype="text/csv",
                     as_attachment=True, download_name=filename)


# ── PDF report ─────────────────────────────────────────────────────────────────

@app.route("/api/report/generate", methods=["POST"])
def generate_report():
    data      = request.json or {}
    results   = data.get("results", [])
    result_ids = data.get("result_ids", [])
    customer  = data.get("customer", "Customer")
    msp       = data.get("msp", load_brand().get("company_name", "Synthreo.ai"))

    # Allow either raw result payloads or references to saved result files
    if not results and result_ids:
        loaded = []
        for name in result_ids:
            safe = Path(name).name
            path = _RESULTS_DIR / safe
            if not path.exists():
                continue
            try:
                with open(path) as f:
                    loaded.append(json.load(f))
            except Exception:
                continue
        results = loaded

    if not results:
        return jsonify({"error": "No results provided"}), 400

    # Write results to temp files so report_generator can consume them
    try:
        with tempfile.TemporaryDirectory() as _td:
            tmp_dir  = Path(_td)
            tmp_jsons = []
            for i, r in enumerate(results):
                p = tmp_dir / f"result_{i}.json"
                with open(p, "w") as f:
                    json.dump(r, f)
                tmp_jsons.append(str(p))

            out_path = tmp_dir / "report.pdf"

            # Write brand config to temp file
            brand_tmp = tmp_dir / "brand.json"
            with open(brand_tmp, "w") as f:
                json.dump(_brand_for_report(), f)

            brand_obj = rg.load_brand_config(str(brand_tmp))
            rg._setup_brand(brand_obj)
            rg._setup_tier(_LICENSE.get_tier())
            loaded = rg.load_results(tmp_jsons)

            doc = rg.DriftReport(str(out_path), customer=customer)
            rg.assemble_report(doc, customer, msp, loaded)

            with open(out_path, "rb") as pdf_f:
                pdf_bytes = io.BytesIO(pdf_f.read())

        filename = f"drift_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        return send_file(pdf_bytes, mimetype="application/pdf",
                         as_attachment=True, download_name=filename)
    except Exception as e:
        logging.error("[generate_report error] %s\n%s", e, traceback.format_exc())
        return jsonify({"error": str(e)}), 500


@app.route("/api/report/comparison", methods=["POST"])
def generate_comparison():
    data       = request.json or {}
    result_ids = data.get("result_ids", [])
    customer   = data.get("customer", "Customer")
    msp        = data.get("msp", load_brand().get("company_name", "Synthreo.ai"))

    if not result_ids or len(result_ids) < 2:
        return jsonify({"error": "At least two result_ids required"}), 400

    # Load saved results by filename
    results = []
    for name in result_ids:
        safe = Path(name).name
        path = _RESULTS_DIR / safe
        if not path.exists():
            continue
        try:
            with open(path) as f:
                results.append(json.load(f))
        except Exception:
            continue

    if len(results) < 2:
        return jsonify({"error": "Could not load enough results for comparison"}), 400

    try:
        with tempfile.TemporaryDirectory() as _td:
            tmp_dir  = Path(_td)
            out_path = tmp_dir / "comparison_report.pdf"

            # Write brand config to temp file
            brand_tmp = tmp_dir / "brand.json"
            with open(brand_tmp, "w") as f:
                json.dump(_brand_for_report(), f)

            brand_obj = rg.load_brand_config(str(brand_tmp))
            rg._setup_brand(brand_obj)
            rg._setup_tier(_LICENSE.get_tier())

            rg.generate_comparison_report(str(out_path), results, customer, msp)

            with open(out_path, "rb") as pdf_f:
                pdf_bytes = io.BytesIO(pdf_f.read())

        filename = f"drift_comparison_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        return send_file(pdf_bytes, mimetype="application/pdf",
                         as_attachment=True, download_name=filename)
    except Exception as e:
        logging.error("[generate_comparison error] %s\n%s", e, traceback.format_exc())
        return jsonify({"error": str(e)}), 500


# ── Conversation Audit ─────────────────────────────────────────────────────────


def _run_audit(audit_id: str, messages: list[dict], conv_name: str,
               model: str, api_key: str, source_format: str = "") -> None:
    """Score a pre-existing conversation for drift in a background thread."""
    q            = _audit_queues[audit_id]
    cancel_event = _audit_cancel_events.get(audit_id, threading.Event())

    def emit(event: str, data: dict):
        q.put({"event": event, "data": data})

    try:
        emit("status", {"message": f"Auditing: {conv_name}…"})

        def on_turn(turn):
            emit("turn", {
                "index":                  turn.index,
                "phase":                  turn.phase,
                "mode":                   turn.mode,
                "role":                   turn.role,
                "pressure_type":          "",
                "pressure_severity":      0,
                "prompt":                 turn.prompt,
                "content":                turn.content,
                "drift_score":            turn.drift_score,
                "epistemic_retreat":      turn.epistemic_retreat,
                "risk_disclosure_absent": turn.risk_disclosure_absent,
                "specificity_gradient":   turn.specificity_gradient,
                "emotional_substitution": turn.emotional_substitution,
                "tier":                   2 if turn.tier2_ran else 1,
                "flags":                  turn.flags,
                "refusal_detected":       turn.refusal_detected,
            })

        engine = TestEngine(
            api_key=api_key,
            target_model=model,
            on_turn=on_turn,
            verbose=False,
        )
        result = engine.score_existing_conversation(
            messages, conv_name=conv_name, cancel_event=cancel_event
        )

        was_cancelled = cancel_event.is_set()

        result_dict = asdict(result)
        result_dict["source"]        = "audit"
        result_dict["source_format"] = source_format
        result_dict["cancelled"]     = was_cancelled
        _inject_health_score(result_dict)

        # Saving is now explicit — user clicks "Save to Results" in the UI.
        # Auto-save is intentionally omitted so audit results are ephemeral
        # unless the user chooses to keep them.
        emit("complete", {"result": result_dict, "cancelled": was_cancelled})

        # Fire telemetry in background if user opted in
        _cfg = load_config()
        if not telemetry_config.is_disabled:
            if telemetry_config.is_forced_on or _cfg.get("telemetry_opted_in"):
                _fire_telemetry(result_dict, _LICENSE.get_tier())

        _auto_generate_report(result_dict, emit, _LICENSE.get_tier())

    except Exception as e:
        logging.error("[audit_error] %s\n%s", e, traceback.format_exc())
        emit("error", {"message": str(e)})
    finally:
        q.put(None)
        _audit_cancel_events.pop(audit_id, None)


@app.route("/api/audit/upload", methods=["POST"])
def audit_upload():
    """Accept a JSON or ZIP file upload, parse it, return conversation list."""
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    f    = request.files["file"]
    hint = request.form.get("format", "auto")
    data = f.read()

    try:
        conversations = _parse_bytes(data, hint=hint)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logging.error("[audit_upload error] %s\n%s", e, traceback.format_exc())
        return jsonify({"error": str(e)}), 500

    # TTL sweep: evict entries older than 30 minutes before adding a new one
    _UPLOAD_CACHE_TTL = 30 * 60
    now = time.time()
    stale = [uid for uid, entry in _upload_cache.items() if now - entry["ts"] > _UPLOAD_CACHE_TTL]
    for uid in stale:
        _upload_cache.pop(uid, None)

    upload_id = os.urandom(4).hex()
    # Cache the raw parsed list for later scoring
    # Store as list of dicts so we don't hold dataclass instances across threads
    _upload_cache[upload_id] = {
        "ts": now,
        "conversations": [
            {"id": c.id, "name": c.name, "messages": c.messages, "source_format": c.source_format}
            for c in conversations
        ],
    }

    summary = [
        {
            "id":            c.id,
            "name":          c.name,
            "message_count": len(c.messages),
            "source_format": c.source_format,
        }
        for c in conversations
    ]
    return jsonify({"upload_id": upload_id, "conversations": summary})


@app.route("/api/audit/score", methods=["POST"])
def audit_score():
    """Start scoring a parsed conversation. Returns audit_id for SSE stream."""
    data          = request.json or {}
    upload_id     = data.get("upload_id", "")
    conversation_id = data.get("conversation_id", "")
    model         = data.get("model", DEFAULT_TARGET_MODEL)
    api_key       = data.get("anthropic_key") or key_manager.get_key("anthropic")

    cache_entry = _upload_cache.get(upload_id)
    if not cache_entry:
        return jsonify({"error": "Upload not found. Re-upload the file."}), 404

    cache = cache_entry["conversations"]
    # Find the requested conversation (or use the first one)
    conv          = next((c for c in cache if c["id"] == conversation_id), cache[0])
    messages      = conv["messages"]
    conv_name     = conv["name"]
    source_format = conv.get("source_format", "")

    # Release PII from memory now that we have what we need
    _upload_cache.pop(upload_id, None)

    if not messages:
        return jsonify({"error": "Conversation has no messages."}), 400

    audit_id = os.urandom(4).hex()
    _audit_queues[audit_id]        = queue.Queue()
    _audit_cancel_events[audit_id] = threading.Event()

    t = threading.Thread(
        target=_run_audit,
        args=(audit_id, messages, conv_name, model, api_key, source_format),
        daemon=True,
    )
    t.start()
    return jsonify({"audit_id": audit_id})


@app.route("/api/audit/cancel/<audit_id>", methods=["POST"])
def audit_cancel(audit_id):
    """Signal the scoring thread to stop after the current turn."""
    ev = _audit_cancel_events.get(audit_id)
    if ev:
        ev.set()
    return jsonify({"ok": True})


@app.route("/api/audit/stream/<audit_id>")
def audit_stream(audit_id):
    """SSE endpoint for live audit turn events."""
    q = _audit_queues.get(audit_id)
    if not q:
        return jsonify({"error": "Unknown audit_id"}), 404

    def generate():
        while True:
            item = q.get()
            if item is None:
                yield "event: done\ndata: {}\n\n"
                break
            event = item["event"]
            data  = json.dumps(item["data"])
            yield f"event: {event}\ndata: {data}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ── Serve / download saved report PDF (e.g. for batch comparison) ─────────────

@app.route("/api/report/download/<filename>")
def download_report_file(filename):
    """Serve a PDF from DriftReports so the browser can open or download it."""
    safe = Path(filename).name
    if not re.match(r"^[a-zA-Z0-9_.\-]+\.pdf$", safe):
        return jsonify({"error": "Invalid filename"}), 400
    pdf_path = _REPORTS_DIR / safe
    if not pdf_path.exists():
        return jsonify({"error": "File not found"}), 404
    return send_file(str(pdf_path), mimetype="application/pdf",
                     as_attachment=False, download_name=safe)


# ── Open saved PDF in default viewer ───────────────────────────────────────────

@app.route("/api/report/open/<filename>")
def open_report_file(filename):
    # Strip any path components to prevent traversal
    safe     = Path(filename).name
    pdf_path = _REPORTS_DIR / safe
    if not pdf_path.exists():
        return jsonify({"error": "File not found", "path": str(pdf_path)}), 404
    try:
        if sys.platform == "win32":
            os.startfile(str(pdf_path))
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(pdf_path)])
        else:
            subprocess.Popen(["xdg-open", str(pdf_path)])
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Entry point ────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Synthreo Drift Desktop App")
    parser.add_argument(
        "--set-license",
        metavar="TIER",
        choices=["free", "pro"],
        help="Set the license tier (free or pro) and exit",
    )
    parser.add_argument(
        "--key",
        metavar="LICENSE_KEY",
        default="",
        help="License key to store (required with --set-license)",
    )
    args = parser.parse_args()

    if args.set_license:
        if not args.key:
            logging.error("--key LICENSE_KEY is required with --set-license")
            sys.exit(1)
        LicenseManager.set_license(args.set_license, args.key)
        sys.exit(0)

    port = _PORT
    # Open browser after a short delay so Flask has time to start
    def _open_browser():
        time.sleep(1.2)
        webbrowser.open(f"http://localhost:{port}")

    threading.Thread(target=_open_browser, daemon=True).start()

    # Refresh model list from provider APIs in the background so the cache is
    # live by the time the user first opens the dropdown (without blocking startup).
    def _refresh_models_cache():
        models, errors = _fetch_models_live()
        for p, fallback in _MODELS_FALLBACK.items():
            if not models.get(p):
                models[p] = fallback
        source = "live" if (not errors and any(
            models[p] != _MODELS_FALLBACK[p] for p in _MODELS_FALLBACK
        )) else "fallback"
        global _models_cache, _models_cache_time
        _models_cache      = {**models, "errors": errors, "source": source}
        _models_cache_time = time.time()

    threading.Thread(target=_refresh_models_cache, daemon=True).start()

    _tier, _tier_source = _LICENSE.get_tier_source()
    logging.info("[license] tier=%s (source: %s)", _tier, _tier_source)
    logging.info("Synthreo Pulse starting at http://localhost:%s  [tier: %s]", port, _tier.upper())
    logging.info("[brand] source: %s", "~/.synthreo/brand.json" if _BRAND_FILE.exists() else "defaults")
    logging.debug("[brand] %s", json.dumps(load_brand(), indent=2))
    app.run(host="127.0.0.1", port=port, debug=_DEBUG, threaded=True)


if __name__ == "__main__":
    main()
