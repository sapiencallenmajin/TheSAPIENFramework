# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
app/key_manager.py
KeyManager — unified API key access with env-var priority and encrypted storage.

Storage backend: Fernet-encrypted ~/.synthreo/keystore.json (via crypto.py).
Env vars (ANTHROPIC_API_KEY, OPENAI_API_KEY, GOOGLE_API_KEY) always take priority.
"""

import os
import sys
from pathlib import Path

# Ensure crypto.py (same package) is importable regardless of cwd
_APP_DIR = Path(__file__).resolve().parent
if str(_APP_DIR) not in sys.path:
    sys.path.insert(0, str(_APP_DIR))

from crypto import store_api_key, retrieve_api_key, delete_api_key, mask_key


_PROVIDERS = ("anthropic", "openai", "google")

_ENV_VARS: dict[str, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai":    "OPENAI_API_KEY",
    "google":    "GOOGLE_API_KEY",
}

# Acceptable key prefixes per provider (empty tuple = no prefix check)
_KEY_PREFIXES: dict[str, tuple] = {
    "anthropic": ("sk-ant-",),
    "openai":    ("sk-",),
    "google":    ("AIza",),
}


class KeyManager:
    """Manages API keys for Anthropic, OpenAI, and Google providers.

    Priority: environment variable > encrypted keystore > ""
    """

    # ── Read ───────────────────────────────────────────────────────────────────

    def get_key(self, provider: str) -> str:
        """Return the API key for *provider*. Env var takes priority over stored key."""
        provider = provider.lower()
        env_var = _ENV_VARS.get(provider, "")
        if env_var:
            val = os.environ.get(env_var, "")
            if val:
                return val
        return retrieve_api_key(provider) or ""

    def masked_keys(self) -> dict[str, str]:
        """Return {provider: masked_key_string} for all known providers."""
        return {p: (mask_key(k) if (k := self.get_key(p)) else "") for p in _PROVIDERS}

    def key_sources(self) -> dict[str, str]:
        """Return {provider: 'env'|'stored'|'none'} for all known providers."""
        result: dict[str, str] = {}
        for p in _PROVIDERS:
            env_var = _ENV_VARS.get(p, "")
            if env_var and os.environ.get(env_var, ""):
                result[p] = "env"
            elif retrieve_api_key(p):
                result[p] = "stored"
            else:
                result[p] = "none"
        return result

    def needs_first_run_setup(self) -> bool:
        """Return True if no keys are configured for any provider."""
        return not any(self.get_key(p) for p in _PROVIDERS)

    # ── Validate ───────────────────────────────────────────────────────────────

    def validate_key(self, provider: str, key: str) -> tuple[bool, str]:
        """Basic format validation. Returns (valid: bool, message: str)."""
        provider = provider.lower()
        if provider not in _PROVIDERS:
            return False, f"Unknown provider: {provider}"
        if len(key) < 20:
            return False, "Key appears too short"
        prefixes = _KEY_PREFIXES.get(provider, ())
        if prefixes and not any(key.startswith(p) for p in prefixes):
            hints = {
                "anthropic": "Anthropic keys start with 'sk-ant-'",
                "openai":    "OpenAI keys start with 'sk-'",
                "google":    "Google keys start with 'AIza'",
            }
            return False, hints.get(provider, f"Key should start with one of: {prefixes}")
        return True, f"{provider.capitalize()} key accepted"

    # ── Write ──────────────────────────────────────────────────────────────────

    def set_key(self, provider: str, key: str) -> None:
        """Encrypt and persist *key* for *provider*."""
        store_api_key(provider.lower(), key)

    def delete_key(self, provider: str) -> None:
        """Remove the stored key for *provider* (env vars are unaffected)."""
        delete_api_key(provider.lower())
