# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
app/crypto.py
Encryption utilities for Synthreo Drift Desktop App.

- Machine-derived Fernet key for local API key storage (uuid.getnode + salt)
- App-signature-derived key for scenario bundle encryption
- encrypt/decrypt API keys and scenario bundles
"""

import base64
import hashlib
import json
import os
import uuid
from pathlib import Path

try:
    from cryptography.fernet import Fernet
except ImportError:
    raise ImportError("pip install cryptography")


# ── Key derivation ─────────────────────────────────────────────────────────────

_MACHINE_SALT = b"synthreo_drift_v1_msp_keystore"
_APP_SALT      = b"synthreo_drift_v1_scenario_bundle"


def _machine_key() -> Fernet:
    """Derive a Fernet key from this machine's MAC address + salt.
    Stable across runs on the same machine; different per machine.
    """
    node = uuid.getnode().to_bytes(6, "big")
    raw  = hashlib.pbkdf2_hmac("sha256", node, _MACHINE_SALT, iterations=200_000)
    return Fernet(base64.urlsafe_b64encode(raw))


def _app_key() -> Fernet:
    """Derive a Fernet key for scenario bundle encryption.
    Uses the app install path as additional entropy so the bundle is
    tied to this installation.
    """
    app_dir = str(Path(__file__).resolve().parent).encode()
    raw = hashlib.pbkdf2_hmac("sha256", app_dir, _APP_SALT, iterations=200_000)
    return Fernet(base64.urlsafe_b64encode(raw))


# ── API key storage ────────────────────────────────────────────────────────────

def encrypt_api_key(plaintext: str) -> str:
    """Encrypt an API key string. Returns base64 ciphertext string."""
    return _machine_key().encrypt(plaintext.encode()).decode()


def decrypt_api_key(ciphertext: str) -> str:
    """Decrypt an API key string. Returns plaintext. Raises on bad key/data."""
    return _machine_key().decrypt(ciphertext.encode()).decode()


def mask_key(key: str) -> str:
    """Return a display-safe masked version: sk-ant-...XXXX (last 4 chars)."""
    if len(key) <= 8:
        return "***"
    prefix = key[:10] if len(key) > 10 else key[:4]
    return f"{prefix}...{key[-4:]}"


# ── Keystore file ──────────────────────────────────────────────────────────────

def _keystore_path() -> Path:
    """~/.synthreo/keystore.json"""
    p = Path.home() / ".synthreo"
    p.mkdir(exist_ok=True)
    return p / "keystore.json"


def load_keystore() -> dict:
    """Load encrypted keystore dict from disk. Returns {} if missing."""
    p = _keystore_path()
    if not p.exists():
        return {}
    try:
        with open(p) as f:
            return json.load(f)
    except Exception:
        return {}


def save_keystore(store: dict) -> None:
    """Write keystore dict to disk."""
    with open(_keystore_path(), "w") as f:
        json.dump(store, f, indent=2)


def store_api_key(provider: str, plaintext: str) -> None:
    """Encrypt and save an API key for a given provider (anthropic/openai/google)."""
    store = load_keystore()
    store[provider] = encrypt_api_key(plaintext)
    save_keystore(store)


def retrieve_api_key(provider: str) -> str:
    """Retrieve and decrypt an API key. Returns "" if not stored."""
    store = load_keystore()
    ct = store.get(provider, "")
    if not ct:
        return ""
    try:
        return decrypt_api_key(ct)
    except Exception:
        return ""


def delete_api_key(provider: str) -> None:
    """Remove a stored API key."""
    store = load_keystore()
    store.pop(provider, None)
    save_keystore(store)


def list_stored_providers() -> list:
    """Return list of providers that have stored keys."""
    return list(load_keystore().keys())


# ── Scenario bundle encryption ─────────────────────────────────────────────────

def encrypt_scenarios(source_paths: list, output_path: str) -> None:
    """Encrypt one or more Python source files into a single bundle.

    Args:
        source_paths: list of file paths to encrypt (e.g. ['scenarios.py', 'scoring_rubrics.txt'])
        output_path:  destination .enc bundle file
    """
    bundle = {}
    for sp in source_paths:
        p = Path(sp)
        if p.exists():
            bundle[p.name] = p.read_text(encoding="utf-8")
    payload = json.dumps(bundle).encode()
    encrypted = _app_key().encrypt(payload)
    with open(output_path, "wb") as f:
        f.write(encrypted)


def decrypt_scenarios(bundle_path: str) -> dict:
    """Decrypt a scenario bundle. Returns {filename: source_code} dict."""
    with open(bundle_path, "rb") as f:
        ciphertext = f.read()
    payload = _app_key().decrypt(ciphertext)
    return json.loads(payload.decode())
