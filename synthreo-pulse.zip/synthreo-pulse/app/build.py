# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
# ──────────────────────────────────────────────────────────────────────────────
"""
app/build.py
PyInstaller build helper for Synthreo Drift Desktop App.

Usage (from project root or from app/):
    python app/build.py [--debug] [--clean]

Flags:
    --debug   Build with console=True so Flask startup errors are visible.
              Patches the spec at build time; does not modify drift_app.spec.
    --clean   Pass --clean to PyInstaller (removes previous build cache).

Output:
    dist/SynthreoPulse.exe   (Windows single-file exe, ~80-120 MB)

The resulting exe:
  · Launches the Flask server on localhost:8765
  · Opens a browser window automatically
  · Bundles all scoring modules, templates, brand assets, and demo results
  · Stores API keys encrypted in ~/.synthreo/keystore.json
  · Requires no Python installation on the target machine
"""

import argparse
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT    = Path(__file__).resolve().parent.parent   # project root
APP_DIR = ROOT / "app"
SPEC    = APP_DIR / "drift_app.spec"
DIST    = ROOT / "dist"
BUILD   = ROOT / "build_tmp"


def _pre_encrypt():
    """Optional: encrypt scenarios.py into app/scenarios.enc before bundling."""
    sys.path.insert(0, str(APP_DIR))
    try:
        from crypto import encrypt_scenarios
    except ImportError:
        print("  [skip] crypto.encrypt_scenarios not available")
        return

    sources = [
        str(ROOT / "core" / "scenarios.py"),
        str(ROOT / "scenarios" / "scenario_rewrites.py"),
        str(ROOT / "scoring_rubrics.txt"),  # optional — may not exist
    ]
    existing = [s for s in sources if Path(s).exists()]
    if not existing:
        print("  [skip] no scenario source files found")
        return

    out = str(APP_DIR / "scenarios.enc")
    try:
        encrypt_scenarios(existing, out)
        print(f"  Encrypted {len(existing)} file(s) -> {out}")
    except Exception as e:
        print(f"  Warning: encryption failed ({e}) -- continuing without")


def _run_pyinstaller(debug: bool, clean: bool) -> int:
    """Run PyInstaller with the spec file, optionally patching for debug mode."""
    spec_path = SPEC

    if debug:
        # Write a temp spec with console=True for this build only
        spec_text = SPEC.read_text(encoding="utf-8")
        spec_text = spec_text.replace("console=False", "console=True")
        tmp = tempfile.NamedTemporaryFile(
            suffix=".spec", delete=False, mode="w", encoding="utf-8"
        )
        tmp.write(spec_text)
        tmp.flush()
        tmp.close()
        spec_path = Path(tmp.name)
        print("  [debug] Patched spec: console=True")

    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm",
        f"--distpath={DIST}",
        f"--workpath={BUILD}",
        str(spec_path),
    ]
    if clean:
        cmd.append("--clean")

    print("  " + " ".join(str(c) for c in cmd))
    result = subprocess.run(cmd, cwd=str(ROOT))

    if debug and spec_path != SPEC:
        Path(spec_path).unlink(missing_ok=True)

    return result.returncode


def main():
    parser = argparse.ArgumentParser(
        description="Build SynthreoPulse.exe"
    )
    parser.add_argument("--debug", action="store_true",
                        help="Build with console window (shows Flask errors)")
    parser.add_argument("--clean", action="store_true",
                        help="Remove PyInstaller build cache before building")
    args = parser.parse_args()

    sep = "=" * 60
    print(sep)
    print("Synthreo Drift -- PyInstaller build")
    print(sep)

    print("\n[1/3] Encrypting scenario bundle...")
    _pre_encrypt()

    print("\n[2/3] Running PyInstaller...")
    rc = _run_pyinstaller(debug=args.debug, clean=args.clean)

    print("\n" + sep)
    if rc == 0:
        exe = DIST / "SynthreoPulse.exe"
        pro = DIST / "pulse.lic"
        pro.touch()
        size_mb = f"{exe.stat().st_size // (1024*1024)} MB" if exe.exists() else "unknown"
        print("\n[3/3] Writing Pro license sentinel...")
        print(f"  Created: {pro}")
        print("\nBUILD SUCCESSFUL")
        print(f"Output : {exe}")
        print(f"Size   : {size_mb}")
        print(sep)
        print("\nTo distribute:")
        print("  1. Copy 'SynthreoPulse.exe' AND 'pulse.lic' to the MSP's machine (same folder)")
        print("  2. Double-click -- browser opens automatically at localhost:8765")
        print("  3. First launch prompts for MSP branding and Anthropic API key")
        print("  4. Keys stored encrypted in ~/.synthreo/keystore.json")
    else:
        print("BUILD FAILED -- see output above for errors.")
        print(sep)
        sys.exit(rc)


if __name__ == "__main__":
    main()
