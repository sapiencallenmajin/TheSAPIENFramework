# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
synthreo_drift
==============
Sycophantic drift detection suite for MSP-deployed AI.

Quick start
-----------
From Python:

    from synthreo_drift import run_scenario, SCENARIOS, score_conversation

    result = run_scenario(SCENARIOS["medical_meds"], api_key="sk-ant-...")
    print(result.verdict)

From the CLI (after pip install -e .):

    drift-test --scenario medical_meds --api-key sk-ant-...
    drift-log  --scenario security_mfa --api-key sk-ant-...

Components
----------
config              — all constants (thresholds, URLs, model defaults)
api_helpers         — unified API routing (Anthropic / OpenAI Responses / OpenAI Chat)
scenarios           — Scenario + Escalation dataclasses, SCENARIOS dict, load_scenario_file()
drift_detector      — 4-dimension LLM scoring engine
deterministic_signals — keyword-based scoring (no LLM calls)
red_team_harness    — adaptive pressure test driver
handoff_planner     — live execution + redirect loop
drift_intervention  — real-time intervention middleware
drift_logger        — structured log writer
baseline_runner     — statistical baseline runner
scorer_validator    — dual-scorer validation with agreement coefficient
cross_run_report    — cross-run model scorecard
breaking_sequence_analyzer — forensic analysis
session_replay      — turn-by-turn session viewer
"""

from .core.config import SUITE_VERSION as __version__

from .core.scenarios import (
    Escalation,
    Scenario,
    SCENARIOS,
    load_scenario_file,
)

from .core.drift_detector import (
    score_conversation,
    TurnScore,
    ConversationResult,
    SCORING_SYSTEM_PROMPT,
    SINGLE_TURN_FLAG_THRESHOLD,
    CUMULATIVE_FLAG_THRESHOLD,
)

from .scenarios.red_team_harness import (
    run_scenario,
    run_all_scenarios,
    HarnessResult,
    TurnResult,
)

from .core.api_helpers import (
    ProviderResponse,
    call_model,
    call_model_detailed,
    call_anthropic,
    call_openai_responses,
    call_openai_chat,
)

from .core.deterministic_signals import (
    score_turn_deterministic,
    score_deterministic,
    TurnSignals,
    SignalScore,
)

from .monitor.drift_monitor import (
    monitor_conversation,
    monitor_agent_action,
    AgentAction,
    AgentActionResult,
    MonitorResult,
    ConversationPressure,
    run_tier1,
)

from .monitor.custom_policies import (
    PolicyManager,
    CustomPolicy,
    PolicyMatch,
    POLICY_TYPES,
    SEVERITY_LEVELS,
)

__all__ = [
    "__version__",
    # Scenarios
    "Escalation", "Scenario", "SCENARIOS", "load_scenario_file",
    # Detection
    "score_conversation", "TurnScore", "ConversationResult",
    "SCORING_SYSTEM_PROMPT", "SINGLE_TURN_FLAG_THRESHOLD", "CUMULATIVE_FLAG_THRESHOLD",
    # Harness
    "run_scenario", "run_all_scenarios", "HarnessResult", "TurnResult",
    # API helpers
    "ProviderResponse", "call_model", "call_model_detailed",
    "call_anthropic", "call_openai_responses", "call_openai_chat",
    # Deterministic signals
    "score_turn_deterministic", "score_deterministic", "TurnSignals", "SignalScore",
    # Monitoring
    "monitor_conversation", "monitor_agent_action",
    "AgentAction", "AgentActionResult",
    "MonitorResult", "ConversationPressure", "run_tier1",
    # Custom policies
    "PolicyManager", "CustomPolicy", "PolicyMatch",
    "POLICY_TYPES", "SEVERITY_LEVELS",
]
