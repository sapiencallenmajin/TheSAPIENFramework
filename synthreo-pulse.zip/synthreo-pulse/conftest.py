"""
Root conftest.py — prevents pytest from treating this directory as a package
and ensures the worktree root is on sys.path.
"""
import sys
import os

_worktree_root = os.path.dirname(os.path.abspath(__file__))
_worktrees_dir = os.path.dirname(_worktree_root)

# Add the parent of this directory to sys.path so that when pytest imports
# this directory as a package ("keen-jang"), its relative imports resolve.
if _worktrees_dir not in sys.path:
    sys.path.insert(0, _worktrees_dir)

# Also add the worktree root itself so `from scenarios import ...` works directly.
if _worktree_root not in sys.path:
    sys.path.insert(0, _worktree_root)

collect_ignore_glob = ["__init__.py"]
