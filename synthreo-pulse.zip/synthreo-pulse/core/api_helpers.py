# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
api_helpers.py

Shared HTTP helpers for calling Anthropic and OpenAI APIs.
All modules should import from here — never re-implement urllib calls.

Provider contract
-----------------
Every public call_* function returns a ProviderResponse dataclass.
  .text      — model output text (always populated on success)
  .provider  — "anthropic" | "openai_responses" | "openai_chat"
  .model     — model string that was actually sent
  .latency_ms — wall-clock milliseconds for the HTTP round-trip
  .error     — None on success; exception string on failure

call_model() is the unified router. It raises on error so existing callers
that just want the text string continue to work unchanged.
"""

import json
import time
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Optional

try:
    from .config import (
        ANTHROPIC_API_URL, ANTHROPIC_VERSION, DEFAULT_MAX_TOKENS,
        OPENAI_CHAT_URL, OPENAI_RESPONSES_URL,
        MISTRAL_CHAT_URL, XAI_CHAT_URL, TOGETHER_CHAT_URL, GEMINI_BASE_URL,
        is_openai_model, use_responses_api,
        is_mistral_model, is_xai_model, is_together_model, is_gemini_model,
        HTTP_TIMEOUT_SECONDS, OPENAI_HTTP_TIMEOUT_SECONDS,
        MAX_RETRIES, RETRY_BASE_DELAY, RETRY_MAX_DELAY,
        CLAUDE_OPUS_4_6, CLAUDE_SONNET_4_6, CLAUDE_HAIKU_4_5,
        GPT_5_4, GPT_4O, O3, GEMINI_2_5_FLASH, GEMINI_3_1_PRO_PREVIEW,
        XAI_GROK_3,
    )
except ImportError:
    from core.config import (
        ANTHROPIC_API_URL, ANTHROPIC_VERSION, DEFAULT_MAX_TOKENS,
        OPENAI_CHAT_URL, OPENAI_RESPONSES_URL,
        MISTRAL_CHAT_URL, XAI_CHAT_URL, TOGETHER_CHAT_URL, GEMINI_BASE_URL,
        is_openai_model, use_responses_api,
        is_mistral_model, is_xai_model, is_together_model, is_gemini_model,
        HTTP_TIMEOUT_SECONDS, OPENAI_HTTP_TIMEOUT_SECONDS,
        MAX_RETRIES, RETRY_BASE_DELAY, RETRY_MAX_DELAY,
        CLAUDE_OPUS_4_6, CLAUDE_SONNET_4_6, CLAUDE_HAIKU_4_5,
        GPT_5_4, GPT_4O, O3, GEMINI_2_5_FLASH, GEMINI_3_1_PRO_PREVIEW,
        XAI_GROK_3,
    )


# ── Typed response ─────────────────────────────────────────────────────────────

@dataclass
class ProviderResponse:
    """
    Uniform response object returned by every provider call.

    On success: .text is populated, .error is None.
    On failure: .text is "", .error is the exception message.
    Callers that only want the text string should use call_model() which
    unwraps this and raises on error.
    """
    text: str = ""
    provider: str = ""          # anthropic | openai_responses | openai_chat
    model: str = ""
    latency_ms: float = 0.0
    error: Optional[str] = None

    @property
    def ok(self) -> bool:
        return self.error is None

    def raise_for_error(self):
        if self.error:
            raise RuntimeError(f"[{self.provider}/{self.model}] {self.error}")


# ── Internal HTTP helper ───────────────────────────────────────────────────────

def _is_retryable(exc: Exception) -> bool:
    """Return True if the error is worth retrying (429, 5xx, timeout)."""
    if isinstance(exc, urllib.error.HTTPError):
        return exc.code == 429 or exc.code >= 500
    if isinstance(exc, (urllib.error.URLError, TimeoutError, OSError)):
        return True
    return False


def _post(url: str, payload: dict, headers: dict,
          timeout: int = HTTP_TIMEOUT_SECONDS,
          max_retries: int = MAX_RETRIES) -> tuple[dict, float]:
    """
    POST JSON with retry and timeout.
    Returns (parsed_response_dict, latency_ms).
    """
    body = json.dumps(payload).encode("utf-8")
    last_exc = None

    for attempt in range(max_retries + 1):
        if attempt > 0:
            delay = min(RETRY_BASE_DELAY * (2 ** (attempt - 1)), RETRY_MAX_DELAY)
            time.sleep(delay)

        try:
            req = urllib.request.Request(url, data=body, headers=headers, method="POST")
            t0 = time.monotonic()
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                result = json.loads(resp.read().decode("utf-8"))
            latency_ms = (time.monotonic() - t0) * 1000
            return result, latency_ms
        except Exception as exc:
            last_exc = exc
            if not _is_retryable(exc) or attempt == max_retries:
                raise

    raise last_exc


# ── Provider calls (return ProviderResponse) ──────────────────────────────────

def call_anthropic(
    system: str,
    messages: list[dict],
    api_key: str,
    model: str,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    temperature: Optional[float] = None,
) -> ProviderResponse:
    """
    Call Anthropic /v1/messages.

    messages:    [{"role": "user"|"assistant", "content": "..."}]
    temperature: 0.0 = deterministic, omit to use API default. Pass
                 SCORER_TEMPERATURE (0) for all scoring calls.
    """
    try:
        payload = {
            "model":      model,
            "max_tokens": max_tokens,
            "system":     system,
            "messages":   messages,
        }
        if temperature is not None:
            payload["temperature"] = temperature

        result, ms = _post(
            ANTHROPIC_API_URL,
            payload,
            {
                "Content-Type":    "application/json",
                "x-api-key":       api_key,
                "anthropic-version": ANTHROPIC_VERSION,
            },
        )
        return ProviderResponse(
            text=result["content"][0]["text"],
            provider="anthropic",
            model=model,
            latency_ms=round(ms, 1),
        )
    except urllib.error.HTTPError as exc:
        # Include the response body in the error so the caller sees Anthropic's reason
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        error_msg = f"HTTP Error {exc.code}: {exc.reason}" + (f" — {body}" if body else "")
        return ProviderResponse(provider="anthropic", model=model, error=error_msg)
    except Exception as exc:
        return ProviderResponse(provider="anthropic", model=model, error=str(exc))


def call_openai_responses(
    instructions: str,
    messages: list[dict],
    api_key: str,
    model: str,
    temperature: Optional[float] = None,
) -> ProviderResponse:
    """
    Call OpenAI /v1/responses (GPT-5.x Responses API).

    instructions: system-level guidance (maps to Anthropic's 'system')
    messages:     [{"role": "user"|"assistant", "content": "..."}]
    temperature:  0.0 = deterministic. Note: not supported by o-series
                  reasoning models; omit for those.
    """
    try:
        payload = {
            "model":        model,
            "instructions": instructions,
            "input":        messages,
            "store":        False,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        result, ms = _post(
            OPENAI_RESPONSES_URL,
            payload,
            {
                "Content-Type":  "application/json",
                "Authorization": f"Bearer {api_key}",
            },
            timeout=OPENAI_HTTP_TIMEOUT_SECONDS,
        )
        # Navigate the Responses API output array
        for item in result.get("output", []):
            if item.get("type") == "message":
                for block in item.get("content", []):
                    if block.get("type") == "output_text":
                        return ProviderResponse(
                            text=block["text"], provider="openai_responses",
                            model=model, latency_ms=round(ms, 1),
                        )
        # SDK-normalised shortcut
        if "output_text" in result:
            return ProviderResponse(
                text=result["output_text"], provider="openai_responses",
                model=model, latency_ms=round(ms, 1),
            )
        raise ValueError(
            f"Cannot extract text from Responses API response. Keys: {list(result.keys())}"
        )
    except Exception as exc:
        return ProviderResponse(provider="openai_responses", model=model, error=str(exc))


def call_openai_chat(
    system: str,
    messages: list[dict],
    api_key: str,
    model: str,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    temperature: Optional[float] = None,
) -> ProviderResponse:
    """
    Call OpenAI /v1/chat/completions (GPT-4.x, o-series).

    system:      system prompt prepended as {"role": "system", ...}
    messages:    [{"role": "user"|"assistant", "content": "..."}]
    temperature: 0.0 = deterministic. Note: not supported by o-series
                 reasoning models; omit for those.
    """
    try:
        payload = {
            "model":      model,
            "max_tokens": max_tokens,
            "messages":   [{"role": "system", "content": system}] + messages,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        result, ms = _post(
            OPENAI_CHAT_URL,
            payload,
            {
                "Content-Type":  "application/json",
                "Authorization": f"Bearer {api_key}",
            },
            timeout=OPENAI_HTTP_TIMEOUT_SECONDS,
        )
        return ProviderResponse(
            text=result["choices"][0]["message"]["content"],
            provider="openai_chat",
            model=model,
            latency_ms=round(ms, 1),
        )
    except Exception as exc:
        return ProviderResponse(provider="openai_chat", model=model, error=str(exc))


# ── OpenAI chat completions-compatible providers ───────────────────────────────

def _call_chat_completions(
    url: str,
    api_key: str,
    system: str,
    messages: list[dict],
    model: str,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    temperature: Optional[float] = None,
    provider: str = "unknown",
) -> ProviderResponse:
    """
    Generic caller for any OpenAI chat completions-compatible endpoint.

    Shared by Mistral, xAI Grok, and Together AI — all use the same
    request/response format as /v1/chat/completions with Bearer auth.
    """
    try:
        payload: dict = {
            "model":      model,
            "max_tokens": max_tokens,
            "messages":   [{"role": "system", "content": system}] + messages,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        result, ms = _post(
            url,
            payload,
            {
                "Content-Type":  "application/json",
                "Authorization": f"Bearer {api_key}",
            },
        )
        return ProviderResponse(
            text=result["choices"][0]["message"]["content"],
            provider=provider,
            model=model,
            latency_ms=round(ms, 1),
        )
    except Exception as exc:
        return ProviderResponse(provider=provider, model=model, error=str(exc))


def call_mistral(
    system: str,
    messages: list[dict],
    api_key: str,
    model: str,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    temperature: Optional[float] = None,
) -> ProviderResponse:
    """Call Mistral AI /v1/chat/completions."""
    return _call_chat_completions(
        MISTRAL_CHAT_URL, api_key, system, messages, model, max_tokens, temperature, "mistral"
    )


def call_xai(
    system: str,
    messages: list[dict],
    api_key: str,
    model: str,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    temperature: Optional[float] = None,
) -> ProviderResponse:
    """Call xAI Grok /v1/chat/completions."""
    return _call_chat_completions(
        XAI_CHAT_URL, api_key, system, messages, model, max_tokens, temperature, "xai"
    )


def call_together(
    system: str,
    messages: list[dict],
    api_key: str,
    model: str,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    temperature: Optional[float] = None,
) -> ProviderResponse:
    """Call Together AI /v1/chat/completions (Meta Llama and others)."""
    return _call_chat_completions(
        TOGETHER_CHAT_URL, api_key, system, messages, model, max_tokens, temperature, "together"
    )


# ── Google Gemini ──────────────────────────────────────────────────────────────

def call_gemini(
    system: str,
    messages: list[dict],
    api_key: str,
    model: str,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    temperature: Optional[float] = None,
) -> ProviderResponse:
    """
    Call Google Gemini generateContent endpoint.

    Converts from the standard {role, content} message format to Gemini's
    {role, parts:[{text}]} format.  "assistant" role becomes "model" per the
    Gemini API spec.  The system prompt maps to systemInstruction.

    Auth is via x-goog-api-key header (never in the URL — M1 fix).
    URL: https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent
    """
    try:
        # Convert messages to Gemini format
        gemini_contents = []
        for msg in messages:
            role = "model" if msg["role"] == "assistant" else msg["role"]
            gemini_contents.append({"role": role, "parts": [{"text": msg["content"]}]})

        payload: dict = {
            "contents": gemini_contents,
            "generationConfig": {"maxOutputTokens": max_tokens},
        }
        if system:
            payload["systemInstruction"] = {"parts": [{"text": system}]}
        if temperature is not None:
            payload["generationConfig"]["temperature"] = temperature

        url = f"{GEMINI_BASE_URL}/{model}:generateContent"
        result, ms = _post(url, payload, {
            "Content-Type": "application/json",
            "x-goog-api-key": api_key,
        })

        text = result["candidates"][0]["content"]["parts"][0]["text"]
        return ProviderResponse(
            text=text, provider="gemini", model=model, latency_ms=round(ms, 1)
        )
    except Exception as exc:
        return ProviderResponse(provider="gemini", model=model, error=str(exc))


# ── Unified router ─────────────────────────────────────────────────────────────

def call_model(
    system: str,
    messages: list[dict],
    api_key: str,
    model: str,
    openai_api_key: Optional[str] = None,
    mistral_api_key: Optional[str] = None,
    xai_api_key: Optional[str] = None,
    together_api_key: Optional[str] = None,
    gemini_api_key: Optional[str] = None,
    max_tokens: int = DEFAULT_MAX_TOKENS,
) -> str:
    """
    Route to the correct provider and return the response text.
    Raises RuntimeError on API failure.

    api_key         — Anthropic key (always required for Claude; used as scorer key)
    openai_api_key  — OpenAI key (required for GPT / o-series models)
    mistral_api_key — Mistral AI key (required for mistral-* / codestral-* models)
    xai_api_key     — xAI key (required for grok-* models)
    together_api_key— Together AI key (required for namespace/model-format models)
    gemini_api_key  — Google AI key (required for gemini-* models)

    Routing:
      Claude             → Anthropic /v1/messages
      GPT-5.x            → OpenAI /v1/responses
      GPT-4.x / o-*      → OpenAI /v1/chat/completions
      mistral-* / codestral → Mistral /v1/chat/completions
      grok-*             → xAI /v1/chat/completions
      namespace/model    → Together AI /v1/chat/completions
      gemini-*           → Google /v1beta/models/{model}:generateContent
    """
    resp = call_model_detailed(
        system, messages, api_key, model,
        openai_api_key, mistral_api_key, xai_api_key, together_api_key,
        gemini_api_key, max_tokens,
    )
    resp.raise_for_error()
    return resp.text


def call_model_detailed(
    system: str,
    messages: list[dict],
    api_key: str,
    model: str,
    openai_api_key: Optional[str] = None,
    mistral_api_key: Optional[str] = None,
    xai_api_key: Optional[str] = None,
    together_api_key: Optional[str] = None,
    gemini_api_key: Optional[str] = None,
    max_tokens: int = DEFAULT_MAX_TOKENS,
) -> ProviderResponse:
    """
    Like call_model() but returns the full ProviderResponse (includes
    latency, provider name, and error without raising).
    Useful for research tooling and logging.
    """
    if is_gemini_model(model):
        return call_gemini(system, messages, gemini_api_key or api_key, model, max_tokens)

    if is_mistral_model(model):
        return call_mistral(system, messages, mistral_api_key or api_key, model, max_tokens)

    if is_xai_model(model):
        return call_xai(system, messages, xai_api_key or api_key, model, max_tokens)

    if is_together_model(model):
        return call_together(system, messages, together_api_key or api_key, model, max_tokens)

    if not is_openai_model(model):
        return call_anthropic(system, messages, api_key, model, max_tokens)

    oai_key = openai_api_key or api_key
    if use_responses_api(model):
        return call_openai_responses(system, messages, oai_key, model)
    return call_openai_chat(system, messages, oai_key, model, max_tokens)


# ── Judge model registry ───────────────────────────────────────────────────────

# Model-to-provider routing table for the configurable judge.
# Add new models here — no changes to call_judge_model needed.
MODEL_REGISTRY: dict = {
    # Anthropic
    CLAUDE_OPUS_4_6:        {"provider": "anthropic",        "display": "Claude Opus 4.6"},
    CLAUDE_SONNET_4_6:      {"provider": "anthropic",        "display": "Claude Sonnet 4.6"},
    CLAUDE_HAIKU_4_5:       {"provider": "anthropic",        "display": "Claude Haiku 4.5"},
    # OpenAI
    GPT_5_4:                {"provider": "openai_responses", "display": "GPT-5.4"},
    GPT_4O:                 {"provider": "openai_chat",      "display": "GPT-4o"},
    O3:                     {"provider": "openai_chat",      "display": "o3"},
    # Google
    GEMINI_2_5_FLASH:       {"provider": "google",           "display": "Gemini 2.5 Flash"},
    GEMINI_3_1_PRO_PREVIEW: {"provider": "google",           "display": "Gemini 3.1 Pro Preview"},
    # xAI
    XAI_GROK_3:             {"provider": "xai",              "display": "Grok 3"},
}

# Cheapest reliable judge per provider.
# SAPIEN Section 4.3: calibration note — weights were validated on Claude-class judges.
JUDGE_DEFAULTS: dict = {
    "anthropic": CLAUDE_HAIKU_4_5,   # ~$0.001/turn, fast, good at structured output
    "openai":    GPT_4O,             # cheapest reliable OpenAI for JSON scoring
    "google":    GEMINI_2_5_FLASH,   # fast, cheap, good at rubric-following
}

# Priority order for auto-resolving default judge from available keys.
PROVIDER_PRIORITY: list = ["anthropic", "openai", "google"]

# Maps provider registry key → api_keys dict key
_JUDGE_KEY_MAP: dict = {
    "anthropic":        "anthropic",
    "openai_chat":      "openai",
    "openai_responses": "openai",
    "google":           "google",
    "xai":              "xai",
}


def get_default_judge(api_keys: dict) -> Optional[str]:
    """Pick the cheapest judge from available provider keys.

    Prefers Anthropic because SAPIEN scoring weights were calibrated on
    Claude-class judges (Section 4.3).  Returns None when no keys exist.

    api_keys: {"anthropic": "sk-...", "openai": "sk-...", "google": "..."}
    """
    for provider in PROVIDER_PRIORITY:
        if api_keys.get(provider):
            return JUDGE_DEFAULTS[provider]
    return None


def call_judge_model(
    system: str,
    messages: list[dict],
    api_keys: dict,
    model_id: str,
    temperature: float = 0,
    max_tokens: int = DEFAULT_MAX_TOKENS,
) -> ProviderResponse:
    """Route a SAPIEN judge scoring call through MODEL_REGISTRY.

    api_keys: {"anthropic": "sk-...", "openai": "sk-...", "google": "..."}
    temperature: MUST be 0 for SAPIEN conformance (Section 4.3). Non-negotiable.

    Does NOT modify call_model or call_model_detailed.
    """
    entry = MODEL_REGISTRY.get(model_id)
    if not entry:
        return ProviderResponse(model=model_id, error=f"Unknown judge model: {model_id!r}")

    provider_key = entry["provider"]
    api_key = api_keys.get(_JUDGE_KEY_MAP.get(provider_key, ""))
    if not api_key:
        return ProviderResponse(
            provider=provider_key, model=model_id,
            error=f"No API key configured for provider: {provider_key!r}",
        )

    if provider_key == "anthropic":
        return call_anthropic(system, messages, api_key, model_id, max_tokens, temperature)
    if provider_key == "openai_responses":
        return call_openai_responses(system, messages, api_key, model_id, temperature)
    if provider_key == "openai_chat":
        return call_openai_chat(system, messages, api_key, model_id, max_tokens, temperature)
    if provider_key == "google":
        return call_gemini(system, messages, api_key, model_id, max_tokens, temperature)
    if provider_key == "xai":
        return call_xai(system, messages, api_key, model_id, max_tokens, temperature)

    return ProviderResponse(
        provider=provider_key, model=model_id,
        error=f"No caller registered for provider: {provider_key!r}",
    )
