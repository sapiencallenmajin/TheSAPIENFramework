# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
dashboard_feed.py
Synthreo.ai — MSP Dashboard Event Emitter

Emits structured monitoring events for the MSP dashboard after every drift
detection and routing decision.  Supports two delivery modes:

  · webhook   — POST the event JSON to the tenant's configured webhook_url
  · event_log — append one JSON line to a per-tenant daily log file:
                    logs/<tenant_id>/dashboard_<YYYYMMDD>.jsonl

Each event contains: timestamp, tenant_id, conversation_id, agent_id,
summary, and three named sub-sections:
  · conversation_pressure — user-side signals (risk_score, risk_level, matched_patterns, trajectory)
  · assistant_drift       — model-side LLM scores (flagged, cumulative_drift, max_turn_drift); null if Tier 2 did not run
  · runtime_action        — system decision (action_taken, human_review_flagged)
Written for an MSP technician reading a live dashboard, not a researcher.

Example summary lines
---------------------
    "No drift detected in conversation conv_001; session allowed."
    "Medium drift detected in conversation abc123 — authority claims and
     urgency language triggered grounding intervention."
    "High drift detected in conversation xyz789 — emotional manipulation,
     normalization attempts, and repeated requests escalated for human review."
    "Critical drift detected in conversation def456 — session terminated."

Import contract
---------------
dashboard_feed imports from:
  · tenant_config   — TenantConfig (runtime import; no cycle risk)
  · drift_monitor   — MonitorResult (TYPE_CHECKING only)
  · action_router   — RuntimeAction (TYPE_CHECKING only)

Neither drift_monitor nor action_router import from dashboard_feed, so
there are no circular dependencies.  dashboard_feed is safe to import
independently of the full monitoring stack.

Delivery guarantees
-------------------
emit() never raises.  All errors are captured in the returned EmitResult.
Webhook failures do not prevent log writes, and vice-versa.

Log path resolution
-------------------
    1. log_dir parameter passed to DashboardEmitter() or emit_event()
    2. DRIFT_LOG_DIR environment variable
    3. Default: ./logs

Usage
-----
    from dashboard_feed import DashboardEmitter
    from tenant_config import get_or_default

    cfg = get_or_default("acme")
    emitter = DashboardEmitter(cfg, mode="both")

    result = emitter.emit(monitor_result, action_response, agent_id="bot-v1")
    if not result.success:
        print(result.webhook_error or result.log_error)
    else:
        print(f"Event logged to {result.log_path}")

    # One-shot convenience function
    from dashboard_feed import emit_event
    emit_event(monitor_result, action_response, cfg, agent_id="bot-v1")
"""

from __future__ import annotations

import datetime
import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

# Runtime import — TenantConfig is lightweight and has no project dependencies;
# importing it at runtime does not create any cycle risk.
try:
    from .tenant_config import TenantConfig
except ImportError:
    from monitor.tenant_config import TenantConfig

# TYPE_CHECKING-only imports: MonitorResult and ActionResponse are never
# constructed here — they arrive as arguments.  Guarding the imports keeps
# dashboard_feed independently importable without pulling in drift_monitor,
# drift_intervention, or action_router and their transitive dependencies.
if TYPE_CHECKING:
    try:
        from .drift_monitor import MonitorResult
        from .action_router import RuntimeAction
    except ImportError:
        from monitor.drift_monitor import MonitorResult
        from monitor.action_router import RuntimeAction


# ── Constants ──────────────────────────────────────────────────────────────────

#: Root directory for event logs when no override is provided.
DEFAULT_LOG_ROOT = "./logs"

#: Environment variable that overrides the default log root.
LOG_DIR_ENV_VAR = "DRIFT_LOG_DIR"

#: Date format for daily log file names — matches drift_logger.py convention.
DATE_FORMAT = "%Y%m%d"

#: Per-request timeout for webhook POSTs.  Dashboard delivery is best-effort.
WEBHOOK_TIMEOUT_SECONDS = 5

#: Schema version embedded in every event for forward-compatibility.
EVENT_SCHEMA_VERSION = "1.0"

#: Valid delivery modes accepted by DashboardEmitter.
VALID_MODES: frozenset[str] = frozenset({"webhook", "event_log", "both"})

# Human-readable labels for Tier 1 pattern category keys.
# Unknown categories fall back to the key with underscores replaced by spaces.
_PATTERN_LABELS: dict[str, str] = {
    "urgency_language":       "urgency language",
    "authority_claims":       "authority claims",
    "emotional_manipulation": "emotional manipulation",
    "normalization_attempts": "normalization attempts",
    "repeated_requests":      "repeated requests",
    "topic_escalation":       "topic escalation",
}

# Short action phrases used in "...triggered X." sentence tails.
# "allow" is handled separately and does not use this dict in a "triggered" context.
_ACTION_DESCRIPTIONS: dict[str, str] = {
    "allow":            "no action taken",
    "inject_grounding": "grounding intervention",
    "alert":            "webhook alert",
    "escalate":         "escalation for human review",
    "terminate":        "session termination",
}


# ── EmitResult ─────────────────────────────────────────────────────────────────

@dataclass
class EmitResult:
    """
    Delivery status returned by DashboardEmitter.emit().

    emit() never raises — all errors are captured here so callers can log
    or report failures without wrapping emit() in try/except.

    Fields
    ------
    webhook_sent : bool
        True when a webhook POST completed with a 2xx response.
    webhook_status : int | None
        HTTP response status code, or None if no request was attempted.
    webhook_error : str | None
        Error message if the webhook POST failed; None on success or skip.
    log_path : Path | None
        Path to the JSONL file that was written; None if no write was attempted.
    log_error : str | None
        Error message if the log write failed; None on success or skip.
    """

    webhook_sent:   bool = False
    webhook_status: Optional[int] = None
    webhook_error:  Optional[str] = None
    log_path:       Optional[Path] = None
    log_error:      Optional[str] = None

    @property
    def success(self) -> bool:
        """True when no errors occurred in any attempted delivery mode."""
        return self.webhook_error is None and self.log_error is None

    @property
    def any_delivered(self) -> bool:
        """True when at least one delivery succeeded."""
        return self.webhook_sent or self.log_path is not None


# ── DashboardEmitter ───────────────────────────────────────────────────────────

class DashboardEmitter:
    """
    Emits monitoring events to the MSP dashboard.

    Holds no mutable state between calls — safe to reuse across requests or
    to instantiate fresh per request.  Call emit() after every monitoring
    decision made by action_router.route().

    Parameters
    ----------
    tenant_config : TenantConfig
        Provides tenant_id and webhook_url.  No extra fields are required.
    mode : str
        Delivery mode: "webhook", "event_log", or "both" (default).
        · webhook   — POST to tenant_config.webhook_url.
                      Silently skipped (not an error) when webhook_url is empty.
        · event_log — append a JSON line to the per-tenant daily JSONL file.
        · both      — attempt both; a failure in one does not prevent the other.
    log_dir : str | None
        Root directory for event log files.  Resolution order:
            1. This parameter
            2. DRIFT_LOG_DIR environment variable
            3. ./logs (default)
        Per-tenant files land at: <log_dir>/<tenant_id>/dashboard_<YYYYMMDD>.jsonl
    """

    def __init__(
        self,
        tenant_config: TenantConfig,
        mode: str = "both",
        log_dir: Optional[str] = None,
    ) -> None:
        if mode not in VALID_MODES:
            raise ValueError(
                f"mode must be one of {sorted(VALID_MODES)} (got {mode!r})"
            )
        self._config  = tenant_config
        self._mode    = mode
        self._log_dir = log_dir

    # ── Public API ─────────────────────────────────────────────────────────────

    def emit(
        self,
        monitor_result: "MonitorResult",
        action_response: "RuntimeAction",
        agent_id: Optional[str] = None,
    ) -> EmitResult:
        """
        Emit a dashboard event for this monitoring decision.

        Builds the structured event dict, then delivers it via the configured
        mode(s).  Never raises — all errors are captured in EmitResult.

        Parameters
        ----------
        monitor_result : MonitorResult
            Output of drift_monitor.monitor_conversation() or /monitor endpoint.
        action_response : ActionResponse
            Output of action_router.route() — the routing decision taken.
        agent_id : str | None
            Agent identifier for traceability in the event.
            MonitorResult does not carry this field; pass it from context.

        Returns
        -------
        EmitResult
            Delivery status for each mode that was attempted.
        """
        event  = _build_event(monitor_result, action_response, self._config, agent_id)
        result = EmitResult()

        if self._mode in ("webhook", "both"):
            _emit_webhook(event, self._config.webhook_url, result)

        if self._mode in ("event_log", "both"):
            _emit_log(event, self._config.tenant_id, self._log_dir, result)

        return result

    # ── Properties ─────────────────────────────────────────────────────────────

    @property
    def tenant_id(self) -> str:
        """Tenant ID from the configured TenantConfig."""
        return self._config.tenant_id

    @property
    def mode(self) -> str:
        """Configured delivery mode."""
        return self._mode


# ── Event construction ─────────────────────────────────────────────────────────

def _build_event(
    monitor_result: "MonitorResult",
    action_response: "RuntimeAction",
    tenant_config: TenantConfig,
    agent_id: Optional[str] = None,
) -> dict[str, Any]:
    """
    Build the canonical dashboard event dict.

    The event uses a three-part structure separating the three monitoring concepts:
      · conversation_pressure — user-side manipulation signals (ConversationPressure)
      · assistant_drift       — model-side safety position changes (Tier 2 LLM scores)
      · runtime_action        — what the system decided to do (RuntimeAction)

    This is the same shape whether delivered via webhook or appended to the
    event log file — the Tenant Manager consumes both identically.
    """
    cp  = monitor_result.conversation_pressure
    ad  = monitor_result.assistant_drift

    # Pattern categories that actually matched (score > 0).
    matched_categories = [pm.category for pm in cp.matched_patterns if pm.score > 0]

    summary = _build_summary(
        conversation_id=monitor_result.conversation_id,
        risk_level=cp.risk_level,
        matched_patterns=matched_categories,
        action_type=action_response.action_type,
        human_review_flagged=action_response.human_review_flagged,
    )

    # AssistantDrift block — only present when Tier 2 ran.
    assistant_drift_block: Optional[dict[str, Any]] = None
    if ad:
        assistant_drift_block = {
            "flagged":          bool(ad.get("flagged", False)),
            "cumulative_drift": ad.get("cumulative_drift"),
            "max_turn_drift":   _max_turn_drift(ad),
            "flag_reasons":     list(ad.get("flag_reasons") or []),
        }

    # Custom policy matches — separate section for MSP analysts.
    # Each entry tells analysts which tenant-specific rule triggered and why.
    custom_policy_block: list[dict] = []
    raw_policy_matches = getattr(cp, "custom_policy_matches", [])
    for pm in raw_policy_matches:
        if hasattr(pm, "to_dict"):
            custom_policy_block.append(pm.to_dict())
        elif isinstance(pm, dict):
            custom_policy_block.append(pm)

    return {
        "schema_version":  EVENT_SCHEMA_VERSION,
        "timestamp":       datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "tenant_id":       tenant_config.tenant_id,
        "conversation_id": monitor_result.conversation_id,
        "agent_id":        agent_id,
        "summary":         summary,
        "conversation_pressure": {
            "risk_score":       round(cp.risk_score, 4),
            "risk_level":       cp.risk_level,
            "matched_patterns": matched_categories,
            "trajectory": {
                "topic_shifts":        cp.trajectory.topic_shifts,
                "escalation_velocity": cp.trajectory.escalation_velocity,
            },
        },
        "assistant_drift": assistant_drift_block,
        "runtime_action": {
            "action_taken":         action_response.action_type,
            "human_review_flagged": action_response.human_review_flagged,
        },
        # Custom policy matches are always present; empty list = no policies fired.
        # MSP analysts use this section to see which tenant-specific rules triggered.
        "custom_policy_matches": custom_policy_block,
    }


def _build_summary(
    conversation_id: str,
    risk_level: str,
    matched_patterns: list[str],
    action_type: str,
    human_review_flagged: bool,
) -> str:
    """
    Generate a one-sentence dashboard summary for an MSP technician.

    Prioritises clarity and actionability over completeness.  The sentence
    always ends with a period and is at most one line long.

    Examples
    --------
    "No drift detected in conversation conv_001; session allowed."
    "Medium drift detected in conversation abc123 — authority claims and
     urgency language triggered grounding intervention."
    "High drift detected in conversation xyz789 — emotional manipulation,
     normalization attempts, and repeated requests escalated for human review."
    "Critical drift detected in conversation def456 — session terminated."
    """
    conv_ref    = f"conversation {conversation_id}"
    action_desc = _ACTION_DESCRIPTIONS.get(action_type, action_type.replace("_", " "))

    # Terminate always gets the shortest, most urgent phrasing.
    if action_type == "terminate":
        return f"Critical drift detected in {conv_ref} — session terminated."

    # Clean allow with nothing flagged — most common case for healthy conversations.
    if action_type == "allow" and not matched_patterns:
        return f"No drift detected in {conv_ref}; session allowed."

    # Format matched pattern list in natural English.
    if matched_patterns:
        labels = [_PATTERN_LABELS.get(p, p.replace("_", " ")) for p in matched_patterns]
        if len(labels) == 1:
            pattern_str = labels[0]
        elif len(labels) == 2:
            pattern_str = f"{labels[0]} and {labels[1]}"
        else:
            # Oxford comma for 3+
            pattern_str = ", ".join(labels[:-1]) + f", and {labels[-1]}"

        # "allow" with patterns detected: flag what was seen but clarify no action fired.
        if action_type == "allow":
            return (
                f"{risk_level.capitalize()} drift detected in {conv_ref} — "
                f"{pattern_str}; no action taken."
            )

        return (
            f"{risk_level.capitalize()} drift detected in {conv_ref} — "
            f"{pattern_str} triggered {action_desc}."
        )

    # Risk level known but no specific patterns to name (e.g. Tier 2 flagged only).
    if action_type == "allow":
        return f"{risk_level.capitalize()} drift detected in {conv_ref}; no action taken."

    return (
        f"{risk_level.capitalize()} drift detected in {conv_ref} — {action_desc}."
    )


def _max_turn_drift(tier2: dict) -> Optional[float]:
    """Return the highest single-turn drift score from a Tier 2 result dict."""
    turns = tier2.get("turn_scores") or []
    if not turns:
        return None
    scores = [float(t.get("turn_drift_score", 0.0)) for t in turns]
    return round(max(scores), 4) if scores else None


# ── Delivery modes ─────────────────────────────────────────────────────────────

def _emit_webhook(
    event: dict[str, Any],
    webhook_url: str,
    result: EmitResult,
) -> None:
    """
    POST the event JSON to webhook_url.

    Uses urllib.request (stdlib) — no additional dependencies required.
    Sets result.webhook_error and returns without raising on any failure.
    Silently returns (not an error) when webhook_url is empty.
    """
    if not webhook_url:
        return

    payload = json.dumps(event, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        webhook_url,
        data=payload,
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "User-Agent":   "synthreo-drift-dashboard/1.0",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=WEBHOOK_TIMEOUT_SECONDS) as resp:
            result.webhook_sent   = True
            result.webhook_status = resp.status
    except urllib.error.HTTPError as exc:
        result.webhook_error  = f"HTTP {exc.code}: {exc.reason}"
        result.webhook_status = exc.code
    except urllib.error.URLError as exc:
        result.webhook_error = f"URL error: {exc.reason}"
    except Exception as exc:
        result.webhook_error = f"{type(exc).__name__}: {exc}"


def _emit_log(
    event: dict[str, Any],
    tenant_id: str,
    log_dir_override: Optional[str],
    result: EmitResult,
) -> None:
    """
    Append the event as a JSON line to the per-tenant daily log file.

    Path: <log_root>/<tenant_id>/dashboard_<YYYYMMDD>.jsonl
    log_root: log_dir_override → DRIFT_LOG_DIR env var → ./logs

    Creates the tenant subdirectory on first write.  Appends without
    truncating — safe for concurrent writers on the same day's file.
    Sets result.log_error and returns without raising on any failure.
    """
    try:
        log_root = Path(
            log_dir_override
            or os.environ.get(LOG_DIR_ENV_VAR, DEFAULT_LOG_ROOT)
        )
        date_str = datetime.date.today().strftime(DATE_FORMAT)
        log_path = log_root / tenant_id / f"dashboard_{date_str}.jsonl"

        log_path.parent.mkdir(parents=True, exist_ok=True)

        with open(log_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(event, ensure_ascii=False) + "\n")

        result.log_path = log_path

    except Exception as exc:
        result.log_error = f"{type(exc).__name__}: {exc}"


# ── Convenience function ───────────────────────────────────────────────────────

def emit_event(
    monitor_result: "MonitorResult",
    action_response: "RuntimeAction",
    tenant_config: TenantConfig,
    mode: str = "both",
    agent_id: Optional[str] = None,
    log_dir: Optional[str] = None,
) -> EmitResult:
    """
    One-shot convenience wrapper: build an emitter and emit in a single call.

    Avoids creating a persistent DashboardEmitter object in request handlers
    where per-request instantiation is simpler.

    Parameters
    ----------
    monitor_result : MonitorResult
    action_response : ActionResponse
    tenant_config : TenantConfig
    mode : str
        "webhook", "event_log", or "both" (default).
    agent_id : str | None
    log_dir : str | None
        Override for the log root directory.

    Returns
    -------
    EmitResult
    """
    emitter = DashboardEmitter(tenant_config, mode=mode, log_dir=log_dir)
    return emitter.emit(monitor_result, action_response, agent_id=agent_id)
