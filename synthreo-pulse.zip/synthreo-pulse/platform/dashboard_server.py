# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
dashboard_server.py
Synthreo.ai — MSP Dashboard Web Server

Extends drift_api.py with a dashboard UI, event ingestion, and storage:

  GET  /                — dashboard.html frontend (MSP dashboard UI)
  POST /webhook/events  — receive DashboardEmitter payloads in real time
  GET  /api/events      — query buffered events with optional filters
  GET  /api/tenants     — list tenant IDs seen in the event buffer
  GET  /api/aggregate   — risk scores aggregated by tenant with action breakdown

Drift monitoring endpoints are available at /drift/* (mounted from drift_api.py):
  GET  /drift/health
  POST /drift/monitor
  POST /drift/score

Event ingestion sources
-----------------------
  1. POST /webhook/events — real-time push from DashboardEmitter (webhook mode)
  2. JSONL polling        — startup scan + background rescan every DASHBOARD_POLL_SECS
     Path pattern: <DRIFT_LOG_DIR>/<tenant_id>/dashboard_<YYYYMMDD>.jsonl

Events from both sources are merged into the same in-memory buffer without
duplicates.  The deduplication key is (timestamp, tenant_id, conversation_id,
action_taken) — identical enough to catch re-polled JSONL lines and duplicate
webhook posts.

Import contract
---------------
dashboard_server imports from:
  · drift_api  — app instance (mounted at /drift; no circular risk)
  · config     — SUITE_VERSION (lightweight constant)

Nothing in drift_api, drift_monitor, or any other module imports from
dashboard_server.  No circular dependencies.

Run
---
  uvicorn dashboard_server:app --reload --port 8001

Environment variables
---------------------
  DRIFT_LOG_DIR           log root for JSONL polling (default: ./logs)
  DASHBOARD_MAX_EVENTS    max events held in memory (default: 500)
  DASHBOARD_POLL_SECS     JSONL rescan interval in seconds (default: 60)
  DRIFT_API_CORS_ORIGINS  comma-separated CORS origins (default: *)
  DASHBOARD_HOST          bind host (default: 0.0.0.0)
  DASHBOARD_PORT          bind port (default: 8001)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse

# ── Local imports ──────────────────────────────────────────────────────────────
# drift_api is imported only for mounting its app instance — no circular risk
# because drift_api does not import dashboard_server.
try:
    from .drift_api import app as _drift_app
    from .config import SUITE_VERSION
except ImportError:
    from drift_api import app as _drift_app
    from core.config import SUITE_VERSION


# ── Configuration ──────────────────────────────────────────────────────────────

MAX_EVENTS       = int(os.environ.get("DASHBOARD_MAX_EVENTS", "500"))
POLL_SECS        = int(os.environ.get("DASHBOARD_POLL_SECS", "60"))
_LOG_DIR_ENV     = "DRIFT_LOG_DIR"
_DEFAULT_LOG_ROOT = "./logs"

_CORS_ORIGINS = [
    o.strip()
    for o in os.environ.get("DRIFT_API_CORS_ORIGINS", "*").split(",")
    if o.strip()
]

# Path to the HTML frontend — same directory as this file
_HTML_PATH = Path(__file__).parent / "dashboard.html"


# ── Logger ─────────────────────────────────────────────────────────────────────

_logger = logging.getLogger("dashboard_server")
if not _logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(
        logging.Formatter("%(asctime)s  %(levelname)-8s  %(name)s: %(message)s")
    )
    _logger.addHandler(_h)
_logger.setLevel(logging.INFO)
_logger.propagate = False


# ── Event buffer ───────────────────────────────────────────────────────────────

def _event_key(event: dict) -> str:
    """
    Deterministic deduplication key for one dashboard event.

    Combines the four fields most likely to be unique per monitoring decision.
    Two events with the same (timestamp, tenant_id, conversation_id, action_taken)
    are treated as identical — covers re-polled JSONL lines and duplicate webhooks.

    Reads action_taken from the nested runtime_action sub-dict as emitted by
    dashboard_feed._build_event() after the ConversationPressure / AssistantDrift /
    RuntimeAction refactor.
    """
    action = (event.get("runtime_action") or {}).get("action_taken", "")
    return (
        f"{event.get('timestamp', '')}|"
        f"{event.get('tenant_id', '')}|"
        f"{event.get('conversation_id', '')}|"
        f"{action}"
    )


def _parse_iso(ts: str) -> Optional[datetime]:
    """Parse an ISO 8601 string to a UTC-aware datetime.  Returns None on failure."""
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def _parse_date(date_str: str, end_of_day: bool = False) -> Optional[datetime]:
    """Parse a YYYY-MM-DD date string to a UTC-aware datetime."""
    try:
        d = datetime.strptime(date_str, "%Y-%m-%d")
        if end_of_day:
            d = d.replace(hour=23, minute=59, second=59)
        return d.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


class _EventBuffer:
    """
    Asyncio-safe, bounded in-memory buffer for dashboard events.

    Maintains insertion order (oldest first, newest last).  Deduplicates via
    a seen-key set so re-polled JSONL lines and duplicate webhook POSTs are
    silently discarded.  When the buffer is full, the oldest event is evicted
    to make room — its key is kept in the seen set to prevent re-insertion.
    """

    def __init__(self, maxsize: int) -> None:
        self._events:  list[dict] = []
        self._seen:    set[str]   = set()
        self._maxsize: int        = maxsize
        self._lock                = asyncio.Lock()

    async def add(self, event: dict) -> bool:
        """
        Add one event.

        Returns True if the event was added, False if it was a duplicate or
        not a valid dict.
        """
        if not isinstance(event, dict):
            return False
        key = _event_key(event)
        async with self._lock:
            if key in self._seen:
                return False
            if len(self._events) >= self._maxsize:
                self._events.pop(0)       # evict oldest; key stays in seen set
            self._events.append(event)
            self._seen.add(key)
            return True

    async def add_many(self, events: list[dict]) -> int:
        """Bulk-add events.  Returns count of newly added events."""
        added = 0
        for ev in events:
            if await self.add(ev):
                added += 1
        return added

    async def query(
        self,
        tenant_id:        Optional[str]   = None,
        conversation_id:  Optional[str]   = None,
        min_risk_score:   Optional[float] = None,
        action_type:      Optional[str]   = None,
        date_from:        Optional[str]   = None,
        date_to:          Optional[str]   = None,
    ) -> list[dict]:
        """
        Return filtered events sorted newest-first.

        All filters are additive (AND logic).  Unrecognised filter values
        return an empty list rather than raising.
        """
        async with self._lock:
            events = list(self._events)   # snapshot; release lock quickly

        dt_from = _parse_date(date_from)               if date_from else None
        dt_to   = _parse_date(date_to, end_of_day=True) if date_to   else None

        result: list[dict] = []
        for ev in events:
            if tenant_id and ev.get("tenant_id") != tenant_id:
                continue
            if conversation_id and ev.get("conversation_id") != conversation_id:
                continue
            if min_risk_score is not None:
                cp_score = float((ev.get("conversation_pressure") or {}).get("risk_score") or 0.0)
                if cp_score < min_risk_score:
                    continue
            ev_action = (ev.get("runtime_action") or {}).get("action_taken")
            if action_type and ev_action != action_type:
                continue
            if dt_from or dt_to:
                ev_ts = _parse_iso(ev.get("timestamp", ""))
                if ev_ts is None:
                    continue
                if dt_from and ev_ts < dt_from:
                    continue
                if dt_to and ev_ts > dt_to:
                    continue
            result.append(ev)

        result.sort(key=lambda e: e.get("timestamp", ""), reverse=True)
        return result

    async def tenants(self) -> list[str]:
        """Return sorted list of unique tenant_ids present in the buffer."""
        async with self._lock:
            return sorted({
                ev.get("tenant_id", "")
                for ev in self._events
                if ev.get("tenant_id")
            })

    async def size(self) -> int:
        async with self._lock:
            return len(self._events)


_event_buffer = _EventBuffer(maxsize=MAX_EVENTS)


# ── JSONL log polling ──────────────────────────────────────────────────────────

def _scan_jsonl_files_sync() -> list[dict]:
    """
    Synchronous JSONL scan — runs in the thread pool executor so it does not
    block the event loop.

    Walks <DRIFT_LOG_DIR>/<tenant_id>/dashboard_<YYYYMMDD>.jsonl following
    the path convention established in dashboard_feed.py.
    """
    log_root = Path(os.environ.get(_LOG_DIR_ENV, _DEFAULT_LOG_ROOT))
    if not log_root.exists():
        return []

    events: list[dict] = []
    for jsonl_file in sorted(log_root.glob("*/dashboard_*.jsonl")):
        try:
            with open(jsonl_file, encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        events.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
        except (IOError, OSError) as exc:
            _logger.warning("Could not read %s: %s", jsonl_file, exc)

    return events


async def _poll_logs() -> int:
    """
    Poll all JSONL log files and merge new events into the buffer.

    Runs the blocking file I/O in the thread pool to stay non-blocking.
    Returns the count of newly added events.
    """
    loop = asyncio.get_event_loop()
    events = await loop.run_in_executor(None, _scan_jsonl_files_sync)
    added = await _event_buffer.add_many(events)
    if added:
        _logger.info("JSONL poll: %d new event(s) added to buffer", added)
    return added


async def _poll_loop() -> None:
    """Background asyncio task: poll JSONL files every POLL_SECS seconds."""
    while True:
        await asyncio.sleep(POLL_SECS)
        try:
            await _poll_logs()
        except Exception as exc:
            _logger.error("JSONL poll error: %s", exc, exc_info=True)


# ── FastAPI application ────────────────────────────────────────────────────────

app = FastAPI(
    title="Synthreo Drift Monitor — MSP Dashboard",
    description=(
        "MSP dashboard for drift monitoring events.  "
        "Extends drift_api.py with event ingestion, storage, and a web UI.  "
        "Drift monitoring endpoints are also available at /drift/*."
    ),
    version=SUITE_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# Mount the existing drift API at /drift.
# All drift_api endpoints are preserved at /drift/health, /drift/monitor, etc.
# This avoids path conflicts and lets operators run both services from one process.
app.mount("/drift", _drift_app)


# ── Startup ────────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def _startup() -> None:
    added = await _poll_logs()
    _logger.info(
        "Dashboard server started — %d event(s) pre-loaded from JSONL logs "
        "(buffer max=%d, poll interval=%ds)",
        added, MAX_EVENTS, POLL_SECS,
    )
    asyncio.create_task(_poll_loop())


# ── HTML frontend ──────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse, include_in_schema=False,
         summary="MSP dashboard frontend")
async def dashboard_ui() -> HTMLResponse:
    """Serve the single-file MSP dashboard HTML frontend."""
    try:
        html = _HTML_PATH.read_text(encoding="utf-8")
    except FileNotFoundError:
        return HTMLResponse(
            content=(
                "<h2 style='font-family:monospace'>dashboard.html not found</h2>"
                "<p>Place <code>dashboard.html</code> in the same directory as "
                "<code>dashboard_server.py</code>.</p>"
            ),
            status_code=503,
        )
    return HTMLResponse(content=html)


# ── Webhook receiver ───────────────────────────────────────────────────────────

@app.post(
    "/webhook/events",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Receive dashboard events from DashboardEmitter (webhook mode)",
)
async def webhook_events(request: Request) -> dict:
    """
    Accept a DashboardEmitter event payload and store it in the in-memory buffer.

    To configure: set `webhook_url="http://localhost:8001/webhook/events"` on
    a TenantConfig, then use DashboardEmitter with mode="webhook" or mode="both".

    Returns 202 Accepted for both new and duplicate events — callers do not
    need to retry on duplicate detection.
    """
    try:
        event = await request.json()
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Request body must be valid JSON.",
        )

    if not isinstance(event, dict):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Event payload must be a JSON object, not an array or scalar.",
        )

    added = await _event_buffer.add(event)
    return {
        "accepted":    True,
        "duplicate":   not added,
        "buffer_size": await _event_buffer.size(),
    }


# ── GET /api/events ────────────────────────────────────────────────────────────

@app.get("/api/events", summary="Query buffered events with optional filters")
async def api_events(
    tenant_id:       Optional[str]   = None,
    conversation_id: Optional[str]   = None,
    min_risk_score:  Optional[float] = None,
    action_type:     Optional[str]   = None,
    date_from:       Optional[str]   = None,   # YYYY-MM-DD
    date_to:         Optional[str]   = None,   # YYYY-MM-DD
    limit:           int             = 200,
) -> dict:
    """
    Return filtered events from the in-memory buffer, sorted newest-first.

    All filters are additive (AND logic).  Omit a filter to match all values.

    Parameters
    ----------
    tenant_id        exact match on event.tenant_id
    conversation_id  exact match on event.conversation_id
    min_risk_score   minimum conversation_pressure.risk_score (0.0–1.0, inclusive)
    action_type      exact match on runtime_action.action_taken
                     ("allow" | "inject_grounding" | "alert" | "escalate" | "terminate")
    date_from        include events on or after this date  (YYYY-MM-DD UTC)
    date_to          include events on or before this date (YYYY-MM-DD UTC)
    limit            max events to return (default 200, hard cap 1000)
    """
    limit = min(max(1, limit), 1000)
    events = await _event_buffer.query(
        tenant_id=tenant_id,
        conversation_id=conversation_id,
        min_risk_score=min_risk_score,
        action_type=action_type,
        date_from=date_from,
        date_to=date_to,
    )
    return {
        "events":          events[:limit],
        "total_matching":  len(events),
        "returned":        min(len(events), limit),
        "buffer_size":     await _event_buffer.size(),
    }


# ── GET /api/tenants ───────────────────────────────────────────────────────────

@app.get("/api/tenants", summary="List tenant IDs present in the event buffer")
async def api_tenants() -> dict:
    """
    Return a sorted list of tenant_ids that have at least one event buffered.

    Used to populate the tenant selector in the dashboard UI.
    """
    return {"tenants": await _event_buffer.tenants()}


# ── GET /api/aggregate ─────────────────────────────────────────────────────────

@app.get("/api/aggregate", summary="Aggregated drift statistics by tenant")
async def api_aggregate(tenant_id: Optional[str] = None) -> dict:
    """
    Compute per-tenant aggregate statistics from the event buffer.

    Returned fields per tenant
    --------------------------
    tenant_id           : str
    event_count         : int   total events for this tenant
    drift_event_count   : int   events where action_taken != "allow"
    peak_risk_score     : float highest conversation_pressure.risk_score seen
    mean_risk_score     : float average conversation_pressure.risk_score across all events
    action_breakdown    : dict  action_type → count mapping

    Note: "domain" and "model" grouping will be available once Tenant Manager
    enriches events with those fields.  This endpoint groups by tenant_id in
    the interim.
    """
    events = await _event_buffer.query(tenant_id=tenant_id)

    groups: dict[str, dict[str, Any]] = {}
    for ev in events:
        tid    = ev.get("tenant_id") or "unknown"
        score  = float((ev.get("conversation_pressure") or {}).get("risk_score") or 0.0)
        action = (ev.get("runtime_action") or {}).get("action_taken") or "allow"

        if tid not in groups:
            groups[tid] = {
                "tenant_id":         tid,
                "event_count":       0,
                "drift_event_count": 0,
                "peak_risk_score":   0.0,
                "_scores":           [],
                "action_breakdown":  {},
            }

        g = groups[tid]
        g["event_count"]   += 1
        g["_scores"].append(score)
        g["peak_risk_score"] = max(g["peak_risk_score"], score)
        if action != "allow":
            g["drift_event_count"] += 1
        g["action_breakdown"][action] = g["action_breakdown"].get(action, 0) + 1

    aggregates: list[dict] = []
    for g in groups.values():
        scores = g.pop("_scores")
        g["mean_risk_score"] = round(sum(scores) / len(scores), 4) if scores else 0.0
        g["peak_risk_score"] = round(g["peak_risk_score"], 4)
        aggregates.append(g)

    aggregates.sort(key=lambda x: x["peak_risk_score"], reverse=True)

    return {
        "aggregates":    aggregates,
        "total_events":  len(events),
        "total_tenants": len(aggregates),
    }


# ── Development server ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    try:
        import uvicorn
    except ImportError:
        raise ImportError(
            "uvicorn is required to run dashboard_server.py directly.\n"
            "Install with: pip install uvicorn"
        )

    uvicorn.run(
        "dashboard_server:app",
        host=os.environ.get("DASHBOARD_HOST", "0.0.0.0"),
        port=int(os.environ.get("DASHBOARD_PORT", "8001")),
        reload=True,
        log_config=None,
    )
