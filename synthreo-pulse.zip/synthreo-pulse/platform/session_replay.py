# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
session_replay.py
Synthreo.ai — Session Replay Viewer

Steps through a logged harness conversation turn by turn.
Read-only — no API calls, no live model connection.

Usage:
    python session_replay.py results/run_abc123.json
    python session_replay.py results/run_abc123.json --auto         # auto-advance
    python session_replay.py results/run_abc123.json --auto --delay 1.5
    python session_replay.py results/run_abc123.json --jump 3       # start at turn 3
    python session_replay.py results/run_abc123.json --export replay_report.html
"""

import argparse
import json
import sys
import time
from pathlib import Path


# ── ANSI ──────────────────────────────────────────────────────────────────────

try:
    from .ansi_helpers import (
        RESET, BOLD, RED, YELLOW, GREEN, CYAN, BLUE, DIM, WHITE, BG_RED,
        c, score_color, score_str, bar, hr, clear_screen,
    )
except ImportError:
    from ansi_helpers import (
        RESET, BOLD, RED, YELLOW, GREEN, CYAN, BLUE, DIM, WHITE, BG_RED,
        c, score_color, score_str, bar, hr, clear_screen,
    )


# ── HTML export ────────────────────────────────────────────────────────────────

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Drift Session Replay — {run_id}</title>
<style>
  body {{ background:#06080a; color:#8899aa; font-family:'Courier New',monospace; font-size:13px; padding:32px; line-height:1.6; }}
  h1 {{ color:#e8962c; font-size:16px; letter-spacing:0.1em; text-transform:uppercase; border-bottom:1px solid #1c2128; padding-bottom:8px; }}
  .meta {{ color:#4a5a6a; font-size:11px; margin-bottom:24px; }}
  .turn {{ margin-bottom:24px; border:1px solid #1c2128; border-radius:3px; overflow:hidden; }}
  .turn-header {{ background:#0b0e12; padding:8px 14px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #1c2128; }}
  .turn-label {{ font-size:10px; letter-spacing:0.1em; text-transform:uppercase; }}
  .turn-label.user {{ color:#4a8ab8; }}
  .turn-label.assistant {{ color:#8899aa; }}
  .pressure-tag {{ font-size:9px; padding:2px 6px; border-radius:2px; background:#181e26; color:#6a7a8a; }}
  .turn-body {{ padding:12px 14px; white-space:pre-wrap; color:#c8d4e0; font-size:12px; line-height:1.7; }}
  .score-block {{ background:#0b0e12; border-top:1px solid #1c2128; padding:10px 14px; }}
  .score-row {{ display:flex; align-items:center; gap:10px; margin-bottom:4px; }}
  .score-label {{ font-size:9px; width:180px; text-transform:uppercase; letter-spacing:0.06em; color:#4a5a6a; }}
  .score-bar {{ height:4px; border-radius:2px; }}
  .score-val {{ font-size:11px; width:40px; }}
  .green {{ color:#38b878; }} .yellow {{ color:#d8c040; }} .red {{ color:#d84040; }}
  .bar-green {{ background:#38b878; }} .bar-yellow {{ background:#d8c040; }} .bar-red {{ background:#d84040; }}
  .event-marker {{ padding:6px 14px; font-size:10px; letter-spacing:0.08em; text-transform:uppercase; }}
  .event-drift {{ background:#181400; color:#d8c040; border-left:3px solid #d8c040; }}
  .event-cap {{ background:#180808; color:#ff6060; border-left:3px solid #d84040; }}
  .composite {{ font-size:16px; font-weight:bold; }}
  .verdict {{ display:inline-block; padding:3px 10px; border-radius:2px; font-size:11px; font-weight:bold; letter-spacing:0.08em; }}
  .verdict-HELD {{ background:#041808; color:#60d898; }}
  .verdict-DRIFTED {{ background:#181400; color:#d8c040; }}
  .verdict-CAPITULATED {{ background:#180808; color:#ff6060; }}
  .summary {{ margin-top:32px; padding:16px; background:#0b0e12; border:1px solid #1c2128; border-radius:3px; }}
  .flags {{ margin-top:4px; }}
  .flag {{ display:inline-block; font-size:9px; padding:1px 5px; border-radius:2px; background:#180808; color:#ff6060; margin-right:4px; }}
</style>
</head>
<body>
<h1>Drift Session Replay</h1>
<div class="meta">
  Run ID: {run_id} &nbsp;·&nbsp; Scenario: {scenario} &nbsp;·&nbsp;
  Domain: {domain} &nbsp;·&nbsp; Verdict: <span class="verdict verdict-{verdict}">{verdict}</span>
</div>
{turns_html}
<div class="summary">
  <b style="color:#e8962c">Summary</b><br>
  Peak Drift: <span class="{peak_class}">{peak:.3f}</span> &nbsp;·&nbsp;
  Cumulative: {cumulative:.3f} &nbsp;·&nbsp;
  First Drift Turn: {first_drift} &nbsp;·&nbsp;
  Break Turn: {break_turn}
</div>
</body>
</html>"""


def sc_html(s):
    return "red" if s >= 0.65 else "yellow" if s >= 0.4 else "green"


def build_html(result: dict, turns_analysis: list) -> str:
    turns_html = ""
    conversation = result.get("conversation", [])
    turn_results = result.get("turn_results", [])

    # Interleave conversation turns with scores
    asst_idx = 0
    msg_pairs = []
    i = 0
    while i < len(conversation):
        if conversation[i]["role"] == "user":
            user_msg = conversation[i]
            asst_msg = conversation[i+1] if i+1 < len(conversation) else None
            tr = turn_results[asst_idx] if asst_idx < len(turn_results) else None
            msg_pairs.append((user_msg, asst_msg, tr))
            if asst_msg:
                asst_idx += 1
                i += 2
            else:
                i += 1
        else:
            i += 1

    for idx, (user_msg, asst_msg, tr) in enumerate(msg_pairs):
        ptype = tr.get("pressure_type", "") if tr else ""
        sev = tr.get("pressure_severity", 0) if tr else 0
        drift = tr.get("drift_score", 0) if tr else 0
        dims = tr.get("dimension_scores", {}) if tr else {}
        flags = tr.get("flags", []) if tr else []

        is_first_drift = tr and idx == result.get("first_drift_turn", -1)
        is_cap = tr and idx == result.get("break_turn", -1)

        user_content = user_msg["content"].replace("<", "&lt;").replace(">", "&gt;")
        asst_content = (asst_msg["content"] if asst_msg else "").replace("<", "&lt;").replace(">", "&gt;")

        if is_first_drift:
            turns_html += '<div class="event-marker event-drift">⚡ DRIFT THRESHOLD CROSSED</div>'
        if is_cap:
            turns_html += '<div class="event-marker event-cap">⛔ CAPITULATION DETECTED</div>'

        # Score rows
        score_rows = ""
        dim_labels = {
            "epistemic_retreat": "Epistemic Retreat",
            "risk_disclosure_absent": "Risk Disclosure",
            "specificity_gradient": "Specificity Gradient",
            "emotional_substitution": "Emotional Substitution",
        }
        for dim, label in dim_labels.items():
            v = dims.get(dim, 0)
            pct = int(v * 100)
            sc = sc_html(v)
            score_rows += f"""
            <div class="score-row">
              <div class="score-label">{label}</div>
              <div style="flex:1;background:#1c2128;height:4px;border-radius:2px;">
                <div class="score-bar bar-{sc}" style="width:{pct}%;height:4px;border-radius:2px;"></div>
              </div>
              <div class="score-val {sc}">{v:.3f}</div>
            </div>"""

        flag_html = "".join(f'<span class="flag">{f}</span>' for f in flags)
        cs = sc_html(drift)

        turns_html += f"""
        <div class="turn">
          <div class="turn-header">
            <div class="turn-label user">Turn {idx} · User</div>
            <div class="pressure-tag">{ptype.upper()} · sev {sev}/5</div>
          </div>
          <div class="turn-body">{user_content}</div>
          <div class="turn-header" style="border-top:1px solid #1c2128;">
            <div class="turn-label assistant">Assistant Response</div>
            <div class="composite {cs}">{drift:.3f}</div>
          </div>
          <div class="turn-body">{asst_content}</div>
          <div class="score-block">
            {score_rows}
            <div class="flags">{flag_html}</div>
          </div>
        </div>"""

    peak = result.get("peak_drift", 0)
    cum = result.get("cumulative_drift", 0)
    verdict = result.get("verdict", "UNKNOWN")
    fd = result.get("first_drift_turn", -1)
    bt = result.get("break_turn", -1)
    fd_str = f"Turn {fd}" if fd != -1 else "None"
    bt_str = f"Turn {bt}" if bt != -1 else "None"

    return HTML_TEMPLATE.format(
        run_id=result.get("run_id", "unknown"),
        scenario=result.get("scenario_name", "unknown"),
        domain=result.get("domain", "unknown"),
        verdict=verdict,
        turns_html=turns_html,
        peak=peak,
        peak_class=sc_html(peak),
        cumulative=cum,
        first_drift=fd_str,
        break_turn=bt_str,
    )


# ── Terminal replay ────────────────────────────────────────────────────────────

DIMENSIONS = [
    ("epistemic_retreat",      "Epistemic Retreat     "),
    ("risk_disclosure_absent", "Risk Disclosure       "),
    ("specificity_gradient",   "Specificity Gradient  "),
    ("emotional_substitution", "Emotional Substitution"),
]


def render_score_block(tr: dict):
    dims = tr.get("dimension_scores", {})
    drift = tr.get("drift_score", 0)
    flags = tr.get("flags", [])

    print()
    print(c("  SCORES", CYAN))
    for dim, label in DIMENSIONS:
        v = dims.get(dim, 0)
        print(f"  {c(label, DIM)}  {bar(v, 18)}  {score_str(v)}")

    composite_c = score_color(drift)
    print(f"\n  {c('DRIFT SCORE', BOLD)}  {bar(drift, 28)}  {c(f'{drift:.3f}', BOLD + composite_c)}")

    if flags:
        print()
        for f in flags:
            print(f"  {c(f'⚑ {f}', YELLOW)}")


def replay_terminal(result: dict, auto: bool, delay: float, start_turn: int):
    conversation = result.get("conversation", [])
    turn_results = result.get("turn_results", [])
    verdict = result.get("verdict", "UNKNOWN")
    first_drift = result.get("first_drift_turn", -1)
    break_turn_r = result.get("break_turn", -1)

    # Pair up messages
    pairs = []
    i = 0
    asst_idx = 0
    while i < len(conversation):
        if conversation[i]["role"] == "user":
            user_msg = conversation[i]["content"]
            asst_msg = conversation[i+1]["content"] if i+1 < len(conversation) else ""
            tr = turn_results[asst_idx] if asst_idx < len(turn_results) else {}
            pairs.append((user_msg, asst_msg, tr))
            asst_idx += 1
            i += 2
        else:
            i += 1

    # Print header
    clear_screen()
    print()
    print(c("  SYNTHREO.AI — SESSION REPLAY", BOLD + CYAN))
    print(c(f"  Run: {result.get('run_id','?')}  ·  Scenario: {result.get('scenario_name','?').upper()}  ·  Domain: {result.get('domain','?')}", DIM))

    verdict_color = RED if verdict == "CAPITULATED" else YELLOW if verdict == "DRIFTED" else GREEN
    print(c(f"  Verdict: {verdict}  ·  {len(pairs)} turns  ·  Peak: {result.get('peak_drift',0):.3f}", verdict_color))
    print()
    hr(width=76)

    for idx, (user_msg, asst_msg, tr) in enumerate(pairs):
        if idx < start_turn:
            continue

        if idx == first_drift:
            print()
            print(c("  ⚡ DRIFT THRESHOLD CROSSED", BOLD + YELLOW))
            hr("─", 76, YELLOW)

        if idx == break_turn_r:
            print()
            print(c("  ⛔ CAPITULATION", BOLD + RED))
            hr("─", 76, RED)

        ptype = tr.get("pressure_type", "?")
        sev = tr.get("pressure_severity", 0)
        decision = tr.get("harness_decision", "")

        print()
        print(c(f"  TURN {idx}  ·  {ptype.upper()}  ·  Severity {sev}/5  ·  Harness: {decision}", BOLD + BLUE))
        hr("·", 76, DIM)

        print()
        print(c("  USER", BOLD + CYAN))
        for line in user_msg.strip().split("\n"):
            print(f"  {line}")

        print()
        print(c("  ASSISTANT", BOLD + WHITE))
        for line in asst_msg.strip().split("\n"):
            print(f"  {line}")

        render_score_block(tr)

        hr(width=76)

        if auto:
            time.sleep(delay)
        else:
            try:
                cmd = input(c(f"\n  [Enter] next  [q] quit  [t N] jump to turn N  > ", DIM)).strip().lower()
                if cmd == "q":
                    break
                if cmd.startswith("t "):
                    try:
                        jump = int(cmd.split()[1])
                        start_turn = jump
                        # restart loop
                        replay_terminal(result, auto, delay, start_turn)
                        return
                    except (ValueError, IndexError):
                        pass
            except (EOFError, KeyboardInterrupt):
                break

    # Final summary
    print()
    print(c("  REPLAY COMPLETE", BOLD + CYAN))
    print(f"  Verdict:     {c(verdict, verdict_color)}")
    print(f"  Peak drift:  {score_str(result.get('peak_drift', 0))}")
    print(f"  First drift: Turn {first_drift}" if first_drift != -1 else "  First drift: None")
    print(f"  Break turn:  Turn {break_turn_r}" if break_turn_r != -1 else "  Break turn:  Never")
    print()


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Step through a logged harness conversation turn by turn.")
    parser.add_argument("path", help="Path to a harness result JSON file")
    parser.add_argument("--auto", "-a", action="store_true", help="Auto-advance turns")
    parser.add_argument("--delay", "-d", type=float, default=2.0, help="Seconds between turns in auto mode (default 2.0)")
    parser.add_argument("--jump", "-j", type=int, default=0, help="Start at a specific turn number")
    parser.add_argument("--export", "-e", help="Export replay as HTML report file")
    args = parser.parse_args()

    path = Path(args.path)
    if not path.exists():
        print(f"File not found: {path}")
        sys.exit(1)

    with open(path) as f:
        data = json.load(f)

    # Handle list or single result
    if isinstance(data, list):
        result = data[0]
    elif "results" in data:
        result = data["results"][0]
    else:
        result = data

    if args.export:
        html = build_html(result, [])
        export_path = Path(args.export)
        export_path.write_text(html)
        print(f"HTML replay exported → {export_path}")
    else:
        replay_terminal(result, args.auto, args.delay, args.jump)


if __name__ == "__main__":
    main()
