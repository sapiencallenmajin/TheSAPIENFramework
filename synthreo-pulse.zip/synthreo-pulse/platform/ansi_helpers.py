# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
ansi_helpers.py
Synthreo Drift Detection — shared ANSI color/formatting utilities.

Extracted from baseline_runner, breaking_sequence_analyzer, cross_run_report,
drift_logger, handoff_planner, scorer_validator, and session_replay to eliminate
duplication. Import from here instead of redefining locally.
"""

# ── Constants ──────────────────────────────────────────────────────────────────

RESET     = "\033[0m"
BOLD      = "\033[1m"
DIM       = "\033[2m"
RED       = "\033[91m"
YELLOW    = "\033[93m"
GREEN     = "\033[92m"
CYAN      = "\033[96m"
BLUE      = "\033[94m"
WHITE     = "\033[97m"
BG_RED    = "\033[41m"
BG_YELLOW = "\033[43m"
BG_GREEN  = "\033[42m"


# ── Core helpers ───────────────────────────────────────────────────────────────

def c(text, code):
    """Wrap text in an ANSI color/style code, then reset."""
    return f"{code}{text}{RESET}"


# Alias used by breaking_sequence_analyzer.py
color = c


def score_color(s):
    """Return the ANSI color code for a drift score."""
    if s >= 0.65:
        return RED
    if s >= 0.40:
        return YELLOW
    return GREEN


def score_str(s):
    """Return a color-coded 3-decimal string for a drift score."""
    return c(f"{s:.3f}", score_color(s))


def bar(s, width=20):
    """Return a Unicode block progress bar colored by drift score."""
    filled = int(s * width)
    col = score_color(s)
    return c("█" * filled, col) + c("░" * (width - filled), DIM)


def hr(char="─", width=74, col=DIM):
    """Print a horizontal rule."""
    print(c(char * width, col))


def section(title):
    """Print a labeled section header between two horizontal rules."""
    print()
    hr()
    print(c(f"  {title}", BOLD + CYAN))
    hr()


def clear_screen():
    """Clear the terminal screen."""
    print("\033[2J\033[H", end="")
