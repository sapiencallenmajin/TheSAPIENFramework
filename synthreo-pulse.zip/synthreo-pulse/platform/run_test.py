# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
run_test.py

Simple entry point for the drift detection test harness.
Run this instead of red_team_harness.py directly.

Usage:
    python run_test.py --api-key YOUR_KEY_HERE
    python run_test.py --api-key YOUR_KEY_HERE --scenario medical_meds
    python run_test.py --api-key YOUR_KEY_HERE --scenario all
"""

import argparse
import json
import os
import sys
import urllib.request
from pathlib import Path
from datetime import datetime


def verify_api_key(api_key: str) -> bool:
    """Make a minimal API call to verify the key works before running full test."""
    print("Verifying API key...")
    try:
        payload = json.dumps({
            "model": "claude-sonnet-4-6",
            "max_tokens": 10,
            "messages": [{"role": "user", "content": "Hi"}]
        }).encode("utf-8")

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01"
            },
            method="POST"
        )
        with urllib.request.urlopen(req) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            if result.get("content"):
                print("  API key valid.\n")
                return True
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        print(f"  API key check failed: {e.code} {body}\n")
        return False
    except Exception as e:
        print(f"  API key check failed: {e}\n")
        return False


def verify_files() -> bool:
    """Check that the required files are present."""
    required = ["red_team_harness.py", "drift_detector.py"]
    missing = [f for f in required if not Path(f).exists()]
    if missing:
        print(f"Missing files: {missing}")
        print("Make sure red_team_harness.py and drift_detector.py are in the same folder as this script.")
        return False
    print("Required files found.")
    return True


def main():
    parser = argparse.ArgumentParser(
        description="Drift detection test harness - simple runner"
    )
    parser.add_argument(
        "--api-key",
        required=True,
        help="Your Anthropic API key (starts with sk-ant-...)"
    )
    parser.add_argument(
        "--scenario",
        default="medical_meds",
        help="Scenario to run: medical_meds, medical_chest_pain, security_mfa, financial_investment, or 'all'"
    )
    parser.add_argument(
        "--output-dir",
        default="./results",
        help="Where to save result files (default: ./results)"
    )
    parser.add_argument(
        "--model",
        default=None,
        help="Model to test (default: claude-sonnet-4-6). Options: claude-haiku-4-5-20251001, claude-sonnet-4-5-20250929, etc."
    )
    parser.add_argument(
        "--dynamic",
        action="store_true",
        help="Enable dynamic mode: AI-generated escalations targeting the weakest drift dimension"
    )
    parser.add_argument(
        "--max-turns",
        type=int,
        default=None,
        help="Max turns (default: 10 static, 15 dynamic)"
    )
    args = parser.parse_args()

    print("\n" + "="*60)
    print("DRIFT DETECTION TEST HARNESS")
    print("="*60 + "\n")

    # Verify files
    if not verify_files():
        sys.exit(1)

    # Verify API key
    if not verify_api_key(args.api_key):
        print("Fix your API key and try again.")
        sys.exit(1)

    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(exist_ok=True)
    print(f"Results will be saved to: {output_dir.resolve()}\n")

    # Import harness (after file check)
    try:
        from .red_team_harness import (
            SCENARIOS, run_scenario, run_scenario_dynamic, run_all_scenarios, print_summary_table
        )
    except ImportError:
        from scenarios.red_team_harness import (
            SCENARIOS, run_scenario, run_scenario_dynamic, run_all_scenarios, print_summary_table
        )

    mode_label = "DYNAMIC" if args.dynamic else "STATIC"
    print(f"Mode: {mode_label}\n")

    # Run
    if args.scenario == "all":
        print(f"Running all {len(SCENARIOS)} scenarios. This will take several minutes.\n")
        results = run_all_scenarios(args.api_key, str(output_dir), model=args.model, verbose=True)
        print_summary_table(results)

        # Save combined report
        report = {
            "run_date": datetime.now().isoformat(),
            "scenarios_run": len(results),
            "mode": mode_label.lower(),
            "results": [r.to_dict() for r in results]
        }
        report_path = output_dir / f"full_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_path, "w") as f:
            json.dump(report, f, indent=2, default=str)
        print(f"\nFull report saved: {report_path}")

    elif args.scenario in SCENARIOS:
        scenario = SCENARIOS[args.scenario]
        print(f"Running scenario: {args.scenario} [{mode_label}]\n")

        if args.dynamic:
            max_turns = args.max_turns or 15
            result = run_scenario_dynamic(
                scenario, args.api_key, model=args.model, verbose=True,
                max_turns=max_turns,
            )
        else:
            result = run_scenario(scenario, args.api_key, model=args.model, verbose=True)

        # Save result
        result_path = output_dir / f"result_{result.run_id}.json"
        with open(result_path, "w") as f:
            json.dump(result.to_dict(), f, indent=2, default=str)

        print(f"\nResult saved: {result_path}")
        print(f"\nVERDICT: {result.verdict}")
        print(f"Peak drift: {result.peak_drift:.3f}")
        print(f"Break turn: {result.break_turn if result.break_turn != -1 else 'None — model held'}")

    else:
        print(f"Unknown scenario '{args.scenario}'")
        print(f"Available: {', '.join(SCENARIOS.keys())}, all")
        sys.exit(1)


if __name__ == "__main__":
    main()
