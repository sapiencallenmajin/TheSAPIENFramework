# ──────────────────────────────────────────────────────────────────────────────
# Project Tokyo Drift — Synthreo Drift Detection Suite
# Copyright (c) 2026 Synthreo, Inc. All rights reserved.
#
# Licensed under the GNU Affero General Public License v3.0 (AGPL-3.0);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/agpl-3.0.html
#
# Reports and outputs generated using this software must include:
# "Assessed using Synthreo Drift Detection Methodology"
#
# For commercial licensing: https://synthreo.ai | support@synthreo.ai
# ──────────────────────────────────────────────────────────────────────────────
"""
drift_api.py
Synthreo.ai — Async FastAPI Monitoring Service

Exposes the two-tier drift monitoring stack as a production HTTP API.

Endpoints:
    GET  /health    — Service liveness + config summary
    POST /monitor   — Tier 1 on every call; auto-triggers Tier 2 if risk is high enough
    POST /score     — Force full Tier 2 LLM scoring (testing / manual review)

Design principles:
    - Stateless: caller passes full conversation context; nothing is stored
    - Per-tenant config: rate limits and thresholds keyed by tenant_id
    - Structured JSON logging: every request tagged with tenant_id / conversation_id / agent_id
    - CORS: configurable per-tenant allowed origins
    - Rate limiting: sliding window per tenant per endpoint

Requirements (not in base requirements.txt — install separately):
    pip install fastapi uvicorn

Run:
    uvicorn drift_api:app --host 0.0.0.0 --port 8000 --reload

Environment variables:
    ANTHROPIC_API_KEY              — default API key for all tenants
    ANTHROPIC_API_KEY_<TENANT_ID>  — per-tenant key override (TENANT_ID uppercased)
    TENANT_CONFIG_FILE             — path to JSON tenant config file (optional)
    DRIFT_API_LOG_LEVEL            — DEBUG | INFO | WARNING (default: INFO)
    DRIFT_API_CORS_ORIGINS         — comma-separated allowed origins (default: *)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from collections import deque
from contextlib import asynccontextmanager
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from functools import partial
from typing import Any, Literal, Optional

# ── FastAPI import ─────────────────────────────────────────────────────────────
try:
    from fastapi import FastAPI, HTTPException, Request, Response, status
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    from pydantic import BaseModel, Field
except ImportError:
    raise ImportError(
        "FastAPI is required for drift_api.py.\n"
        "Install with: pip install fastapi uvicorn"
    )

# ── Local imports ──────────────────────────────────────────────────────────────
try:
    from .drift_monitor import (
        run_tier1, run_tier2, _derive_action,
        monitor_agent_action, AgentAction, AgentActionResult,
    )
    from .custom_policies import PolicyManager, CustomPolicy, POLICY_TYPES, SEVERITY_LEVELS
    from .config import SUITE_VERSION
except ImportError:
    from monitor.drift_monitor import (
        run_tier1, run_tier2, _derive_action,
        monitor_agent_action, AgentAction, AgentActionResult,
    )
    from monitor.custom_policies import PolicyManager, CustomPolicy, POLICY_TYPES, SEVERITY_LEVELS
    from core.config import SUITE_VERSION


# ── Structured JSON logger ─────────────────────────────────────────────────────

class _StructuredJSONFormatter(logging.Formatter):
    """Emit log records as single-line JSON objects for log aggregators."""

    # Extra fields propagated from log calls via `extra={}` kwargs
    _CONTEXT_KEYS = (
        "tenant_id", "conversation_id", "agent_id", "request_id",
        "risk_level", "action", "risk_score", "tier2_triggered",
        "duration_ms", "endpoint",
    )

    def format(self, record: logging.LogRecord) -> str:
        entry: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level":     record.levelname,
            "message":   record.getMessage(),
            "logger":    record.name,
        }
        for key in self._CONTEXT_KEYS:
            if hasattr(record, key):
                entry[key] = getattr(record, key)
        if record.exc_info:
            entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(entry, default=str)


def _build_logger(name: str = "drift_api") -> logging.Logger:
    log_level = os.environ.get("DRIFT_API_LOG_LEVEL", "INFO").upper()
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, log_level, logging.INFO))
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(_StructuredJSONFormatter())
        logger.addHandler(handler)
    logger.propagate = False
    return logger


logger = _build_logger()


# ── Per-tenant configuration ───────────────────────────────────────────────────

@dataclass
class TenantConfig:
    """
    Per-tenant operational settings.

    Loaded from TENANT_CONFIG_FILE (JSON) at startup.
    Unknown tenants receive the default configuration.
    """
    tenant_id: str = "default"

    # Rate limits (requests per minute)
    monitor_rpm: int = 60
    score_rpm: int = 10

    # Tier 1 → Tier 2 trigger threshold (overrides drift_monitor default)
    tier2_trigger_threshold: float = 0.40

    # CORS
    allowed_origins: list[str] = field(default_factory=lambda: ["*"])

    # Anthropic API key for Tier 2 (falls back to env var if empty)
    api_key_env_var: str = ""   # e.g. "ANTHROPIC_API_KEY_TENANT_ACME"

    def to_dict(self) -> dict:
        return asdict(self)


_DEFAULT_TENANT_CONFIG = TenantConfig()

# Tenant registry: loaded once at startup
_TENANT_REGISTRY: dict[str, TenantConfig] = {}


def _load_tenant_configs(config_path: Optional[str] = None) -> None:
    """Load tenant configs from JSON file into _TENANT_REGISTRY."""
    path = config_path or os.environ.get("TENANT_CONFIG_FILE", "")
    if not path:
        return
    try:
        with open(path, encoding="utf-8") as fh:
            raw: list[dict] = json.load(fh)
        for entry in raw:
            tid = entry.get("tenant_id", "")
            if not tid:
                continue
            cfg = TenantConfig(
                tenant_id=tid,
                monitor_rpm=entry.get("monitor_rpm", _DEFAULT_TENANT_CONFIG.monitor_rpm),
                score_rpm=entry.get("score_rpm", _DEFAULT_TENANT_CONFIG.score_rpm),
                tier2_trigger_threshold=entry.get(
                    "tier2_trigger_threshold",
                    _DEFAULT_TENANT_CONFIG.tier2_trigger_threshold,
                ),
                allowed_origins=entry.get("allowed_origins", ["*"]),
                api_key_env_var=entry.get("api_key_env_var", ""),
            )
            _TENANT_REGISTRY[tid] = cfg
        logger.info("Loaded %d tenant config(s) from %s", len(_TENANT_REGISTRY), path)
    except FileNotFoundError:
        logger.warning("TENANT_CONFIG_FILE not found: %s — using defaults for all tenants", path)
    except json.JSONDecodeError as exc:
        logger.error("Failed to parse TENANT_CONFIG_FILE: %s", exc)


def _get_tenant_config(tenant_id: str) -> TenantConfig:
    return _TENANT_REGISTRY.get(tenant_id, _DEFAULT_TENANT_CONFIG)


def _resolve_api_key(config: TenantConfig) -> str:
    """
    Resolve the Anthropic API key for a tenant.

    Priority:
      1. env var named in config.api_key_env_var
      2. ANTHROPIC_API_KEY_<TENANT_ID> (uppercased, hyphens → underscores)
      3. ANTHROPIC_API_KEY (global fallback)
    """
    if config.api_key_env_var:
        key = os.environ.get(config.api_key_env_var, "")
        if key:
            return key

    tenant_env_var = f"ANTHROPIC_API_KEY_{config.tenant_id.upper().replace('-', '_')}"
    key = os.environ.get(tenant_env_var, "")
    if key:
        return key

    return os.environ.get("ANTHROPIC_API_KEY", "")


# ── Sliding-window rate limiter ────────────────────────────────────────────────

class _SlidingWindowRateLimiter:
    """
    In-process sliding window rate limiter, keyed by (tenant_id, endpoint).

    Thread-safe via asyncio.Lock — suitable for single-process deployments.
    For multi-process / distributed setups, replace with Redis-backed limiter.

    The asyncio.Lock is created lazily on first use so it is always bound to
    the running event loop (required in Python 3.10+ / 3.12+).
    """

    def __init__(self) -> None:
        self._windows: dict[str, deque[float]] = {}
        self._lock: Optional[asyncio.Lock] = None

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def is_allowed(
        self,
        tenant_id: str,
        endpoint: str,
        limit: int,
        window_seconds: int = 60,
    ) -> bool:
        """
        Returns True and records the request if under the limit.
        Returns False (without recording) if the limit is exceeded.
        """
        key = f"{tenant_id}:{endpoint}"
        now = time.monotonic()
        cutoff = now - window_seconds

        async with self._get_lock():
            if key not in self._windows:
                self._windows[key] = deque()
            window = self._windows[key]

            # Evict expired entries
            while window and window[0] < cutoff:
                window.popleft()

            if len(window) >= limit:
                return False

            window.append(now)
            return True

    async def remaining(
        self,
        tenant_id: str,
        endpoint: str,
        limit: int,
        window_seconds: int = 60,
    ) -> int:
        """Return how many requests remain in the current window."""
        key = f"{tenant_id}:{endpoint}"
        now = time.monotonic()
        cutoff = now - window_seconds
        async with self._get_lock():
            window = self._windows.get(key, deque())
            active = sum(1 for t in window if t >= cutoff)
            return max(0, limit - active)


_rate_limiter = _SlidingWindowRateLimiter()


# ── Admin authentication ───────────────────────────────────────────────────────
# Policy management endpoints require an X-Admin-Key header matching
# the DRIFT_ADMIN_KEY environment variable.  Set this variable before
# exposing policy endpoints in production.

_ADMIN_KEY_ENV = "DRIFT_ADMIN_KEY"


async def _require_admin(request: Request) -> None:
    """
    Enforce admin authentication via X-Admin-Key header.

    Raises HTTP 503 when DRIFT_ADMIN_KEY is not configured server-side.
    Raises HTTP 403 when the header is absent or does not match.
    """
    expected = os.environ.get(_ADMIN_KEY_ENV, "")
    if not expected:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "admin_not_configured",
                "message": (
                    f"The {_ADMIN_KEY_ENV} environment variable is not set. "
                    "Policy management is disabled until it is configured."
                ),
            },
        )
    provided = request.headers.get("X-Admin-Key", "")
    if not provided or provided != expected:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "forbidden",
                "message": "A valid X-Admin-Key header is required for this endpoint.",
            },
        )


# ── Pydantic request / response models ────────────────────────────────────────

class ConversationMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str

    model_config = {"str_strip_whitespace": True}


class MonitorRequest(BaseModel):
    """
    POST /monitor request body.

    The caller is responsible for passing the full conversation — this
    service is stateless and stores nothing between requests.
    """
    conversation_id: str = Field(default_factory=lambda: f"conv_{uuid.uuid4().hex[:8]}")
    tenant_id: str = "default"
    agent_id: Optional[str] = None
    conversation: list[ConversationMessage] = Field(min_length=1)

    # Optional per-request overrides
    tier2_trigger_threshold: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Override tenant's tier2_trigger_threshold for this request.",
    )
    force_tier2: bool = Field(
        default=False,
        description="Force Tier 2 regardless of Tier 1 score (overrides threshold).",
    )


class ScoreRequest(BaseModel):
    """POST /score request body — always runs full Tier 2 LLM scoring."""
    conversation_id: str = Field(default_factory=lambda: f"conv_{uuid.uuid4().hex[:8]}")
    tenant_id: str = "default"
    agent_id: Optional[str] = None
    conversation: list[ConversationMessage] = Field(min_length=1)


class PolicyCreateRequest(BaseModel):
    """
    POST /policies request body.

    policy_type must be one of: keyword_flag | sentiment_rule | behavioral_rule |
                                 value_alignment | topic_boundary
    severity must be one of: low | medium | high | critical
    config is policy-type-specific — see CustomPolicy docstring for schema.
    """
    tenant_id:   str = "default"
    created_by:  str = Field(description="User ID or email of the policy creator")
    policy_type: str = Field(description=" | ".join(sorted(POLICY_TYPES)))
    name:        str = Field(min_length=1, max_length=120)
    description: str = ""
    enabled:     bool = True
    severity:    str = Field(default="medium", description=" | ".join(SEVERITY_LEVELS))
    config:      dict = Field(default_factory=dict)


class AgentActionPayload(BaseModel):
    """
    Pydantic representation of AgentAction for the POST /monitor-action request.

    action_type — api_call | tool_use | data_access | send_message |
                  modify_record | delete | execute
    target      — endpoint URL, resource path, or message recipient
    """
    action_type: str
    target: str
    parameters: dict = Field(default_factory=dict)
    timestamp: str = ""
    conversation_turn: int = -1


class AgentConfigPayload(BaseModel):
    """
    Agent configuration extracted from Builder, passed per-request.

    allowed_actions    — action types the agent is permitted to perform;
                         None means unconfigured (no restriction enforced).
    tenant_boundary    — target prefix that data_access targets must start with.
    action_baseline    — {action_type: {param_key: baseline_value}} for anomaly detection.
    hard_stop          — True if the conversation is already hard-stopped (e.g. a prior
                         monitor call returned action="intervene").
    prior_action_types — action types taken by this agent earlier in the conversation.
    """
    allowed_actions: Optional[list[str]] = None
    tenant_boundary: str = ""
    action_baseline: dict = Field(default_factory=dict)
    hard_stop: bool = False
    prior_action_types: list[str] = Field(default_factory=list)


class MonitorActionRequest(BaseModel):
    """
    POST /monitor-action request body.

    Pass the action about to be (or just) executed, the full conversation so far,
    and the agent's Builder config.  The service evaluates anomalies and returns
    a recommended_action (allow / block / require_approval / alert).

    conversation is optional — omit only when there is no prior conversation context.
    """
    conversation_id: str = Field(default_factory=lambda: f"conv_{uuid.uuid4().hex[:8]}")
    tenant_id: str = "default"
    agent_id: Optional[str] = None
    action: AgentActionPayload
    conversation: list[ConversationMessage] = Field(default_factory=list)
    agent_config: AgentConfigPayload = Field(default_factory=AgentConfigPayload)


# ── FastAPI application ────────────────────────────────────────────────────────

_global_cors_origins = [
    o.strip()
    for o in os.environ.get("DRIFT_API_CORS_ORIGINS", "*").split(",")
    if o.strip()
]

@asynccontextmanager
async def _lifespan(_: FastAPI):
    """Replaces deprecated @app.on_event('startup')."""
    _load_tenant_configs()
    logger.info(
        "Drift Monitor API started",
        extra={"endpoint": "startup", "version": SUITE_VERSION},
    )
    yield


app = FastAPI(
    title="Synthreo Drift Monitor API",
    description=(
        "Two-tier conversation drift monitoring. "
        "Tier 1 is deterministic (zero LLM cost). "
        "Tier 2 is full LLM-based sycophantic drift scoring."
    ),
    version=SUITE_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=_lifespan,
)

_cors_allow_credentials = "*" not in _global_cors_origins  # credentials forbidden with wildcard origin
app.add_middleware(
    CORSMiddleware,
    allow_origins=_global_cors_origins,
    allow_credentials=_cors_allow_credentials,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


# ── Request logging middleware ─────────────────────────────────────────────────

@app.middleware("http")
async def _request_logger(request: Request, call_next) -> Response:
    request_id = request.headers.get("X-Request-ID", uuid.uuid4().hex[:12])
    t0 = time.monotonic()
    response: Response = await call_next(request)
    duration_ms = round((time.monotonic() - t0) * 1000, 1)
    logger.info(
        "%s %s %d",
        request.method,
        request.url.path,
        response.status_code,
        extra={
            "request_id": request_id,
            "endpoint": request.url.path,
            "duration_ms": duration_ms,
        },
    )
    response.headers["X-Request-ID"] = request_id
    return response


# ── Internal helpers ───────────────────────────────────────────────────────────

_RATE_LIMIT_WINDOW_SECONDS = 60  # single constant keeps is_allowed / remaining in sync

async def _check_rate_limit(tenant_id: str, endpoint: str, limit: int) -> None:
    """Raise HTTP 429 if tenant has exceeded their rate limit."""
    allowed = await _rate_limiter.is_allowed(
        tenant_id, endpoint, limit, window_seconds=_RATE_LIMIT_WINDOW_SECONDS
    )
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={
                "error": "rate_limit_exceeded",
                "tenant_id": tenant_id,
                "endpoint": endpoint,
                "message": f"Rate limit of {limit} req/min exceeded for this tenant.",
            },
        )


def _conversation_to_dicts(messages: list[ConversationMessage]) -> list[dict]:
    return [{"role": m.role, "content": m.content} for m in messages]


async def _run_in_executor(fn, *args):
    """Run a synchronous function in the default thread pool executor."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, partial(fn, *args))


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/health", summary="Service health check")
async def health() -> dict:
    """
    Returns service liveness and basic configuration summary.
    Always fast — no LLM calls.
    """
    return {
        "status": "ok",
        "version": SUITE_VERSION,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "tenants_configured": len(_TENANT_REGISTRY),
        "default_tier2_trigger_threshold": _DEFAULT_TENANT_CONFIG.tier2_trigger_threshold,
        "default_monitor_rpm": _DEFAULT_TENANT_CONFIG.monitor_rpm,
        "default_score_rpm": _DEFAULT_TENANT_CONFIG.score_rpm,
    }


@app.post("/monitor", summary="Two-tier conversation monitor")
async def monitor(req: MonitorRequest, request: Request) -> JSONResponse:
    """
    Run Tier 1 (deterministic) on the conversation.
    Automatically runs Tier 2 (LLM) if Tier 1 risk score crosses the threshold.

    Caller passes the full conversation — no state is stored server-side.
    """
    config = _get_tenant_config(req.tenant_id)

    # Rate limit
    await _check_rate_limit(req.tenant_id, "monitor", config.monitor_rpm)

    # Resolve threshold: per-request override > tenant config > default
    threshold = (
        req.tier2_trigger_threshold
        if req.tier2_trigger_threshold is not None
        else config.tier2_trigger_threshold
    )

    conversation = _conversation_to_dicts(req.conversation)
    request_id = request.headers.get("X-Request-ID", "")

    log_ctx = {
        "tenant_id": req.tenant_id,
        "conversation_id": req.conversation_id,
        "agent_id": req.agent_id or "",
        "request_id": request_id,
        "endpoint": "/monitor",
    }

    t0 = time.monotonic()

    # ── Tier 1 (sync, runs in executor to stay non-blocking) ──────────────────
    tier1_result = await _run_in_executor(run_tier1, conversation, threshold)

    logger.info(
        "Tier 1 complete: risk_level=%s score=%.4f trigger_tier2=%s",
        tier1_result.risk_level,
        tier1_result.risk_score,
        tier1_result.trigger_tier2,
        extra={
            **log_ctx,
            "risk_level": tier1_result.risk_level,
            "risk_score": tier1_result.risk_score,
        },
    )

    # ── Tier 2 (conditional) ──────────────────────────────────────────────────
    tier2_dict: Optional[dict] = None
    tier2_triggered = tier1_result.trigger_tier2 or req.force_tier2

    if tier2_triggered:
        api_key = _resolve_api_key(config)
        if not api_key:
            logger.warning(
                "Tier 2 skipped — no API key for tenant",
                extra={**log_ctx, "tier2_triggered": True},
            )
            tier2_dict = {
                "error": "no_api_key",
                "message": (
                    "Tier 2 scoring requires ANTHROPIC_API_KEY "
                    f"(or ANTHROPIC_API_KEY_{req.tenant_id.upper()}) to be set."
                ),
            }
        else:
            try:
                tier2_dict = await _run_in_executor(
                    run_tier2, conversation, api_key, req.conversation_id
                )
                logger.info(
                    "Tier 2 complete: flagged=%s cumulative_drift=%.3f",
                    tier2_dict.get("flagged"),
                    tier2_dict.get("cumulative_drift", 0.0),
                    extra={
                        **log_ctx,
                        "tier2_triggered": True,
                        "risk_level": tier1_result.risk_level,
                    },
                )
            except Exception as exc:
                logger.error(
                    "Tier 2 scoring failed: %s",
                    exc,
                    exc_info=True,
                    extra={**log_ctx, "tier2_triggered": True},
                )
                tier2_dict = {"error": str(exc), "flagged": False}

    # ── Derive action ──────────────────────────────────────────────────────────
    action = _derive_action(tier1_result, tier2_dict)

    total_ms = round((time.monotonic() - t0) * 1000, 1)

    logger.info(
        "Monitor complete: action=%s",
        action,
        extra={**log_ctx, "action": action, "duration_ms": total_ms},
    )

    remaining = await _rate_limiter.remaining(
        req.tenant_id, "monitor", config.monitor_rpm, window_seconds=_RATE_LIMIT_WINDOW_SECONDS
    )

    response_body = {
        "conversation_id": req.conversation_id,
        "tenant_id": req.tenant_id,
        "agent_id": req.agent_id,
        "action": action,
        "processing_time_ms": total_ms,
        "tier1": tier1_result.to_dict(),
        "tier2": tier2_dict,
    }
    return JSONResponse(
        content=response_body,
        headers={"X-RateLimit-Remaining": str(remaining)},
    )


@app.post("/score", summary="Force full Tier 2 LLM scoring")
async def score(req: ScoreRequest, request: Request) -> JSONResponse:
    """
    Always runs full Tier 2 LLM drift scoring, skipping Tier 1 threshold logic.

    Intended for:
      - Manual review of flagged conversations
      - Regression testing of the LLM scorer
      - Audit / compliance workflows

    Caller passes the full conversation — no state is stored server-side.
    """
    config = _get_tenant_config(req.tenant_id)

    await _check_rate_limit(req.tenant_id, "score", config.score_rpm)

    request_id = request.headers.get("X-Request-ID", "")
    log_ctx = {
        "tenant_id": req.tenant_id,
        "conversation_id": req.conversation_id,
        "agent_id": req.agent_id or "",
        "request_id": request_id,
        "endpoint": "/score",
    }

    api_key = _resolve_api_key(config)
    if not api_key:
        logger.error("Score request rejected — no API key", extra=log_ctx)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "no_api_key",
                "message": (
                    "Tier 2 scoring requires ANTHROPIC_API_KEY "
                    f"(or ANTHROPIC_API_KEY_{req.tenant_id.upper()}) to be set."
                ),
            },
        )

    conversation = _conversation_to_dicts(req.conversation)
    t0 = time.monotonic()

    try:
        tier2_dict = await _run_in_executor(
            run_tier2, conversation, api_key, req.conversation_id
        )
    except Exception as exc:
        logger.error("Tier 2 scoring failed: %s", exc, exc_info=True, extra=log_ctx)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail={"error": "scorer_failed", "message": str(exc)},
        )

    total_ms = round((time.monotonic() - t0) * 1000, 1)

    logger.info(
        "Score complete: flagged=%s cumulative_drift=%.3f",
        tier2_dict.get("flagged"),
        tier2_dict.get("cumulative_drift", 0.0),
        extra={**log_ctx, "duration_ms": total_ms},
    )

    remaining = await _rate_limiter.remaining(
        req.tenant_id, "score", config.score_rpm, window_seconds=_RATE_LIMIT_WINDOW_SECONDS
    )

    response_body = {
        "conversation_id": req.conversation_id,
        "tenant_id": req.tenant_id,
        "agent_id": req.agent_id,
        "processing_time_ms": total_ms,
        "result": tier2_dict,
    }
    return JSONResponse(
        content=response_body,
        headers={"X-RateLimit-Remaining": str(remaining)},
    )


@app.post("/policies", summary="Create a custom drift policy for a tenant (admin)")
async def create_policy(req: PolicyCreateRequest, request: Request) -> JSONResponse:
    """
    Create a tenant-specific custom drift policy through Tenant Manager.

    Requires X-Admin-Key header matching the DRIFT_ADMIN_KEY environment variable.

    Policy types:
      keyword_flag     — flag when assistant uses specified phrases or regex patterns
      sentiment_rule   — flag when assistant sentiment toward an entity falls below threshold
      behavioral_rule  — flag when assistant exhibits described behaviors (deterministic + optional LLM)
      value_alignment  — flag when assistant responses diverge from tenant's stated values (LLM)
      topic_boundary   — flag when assistant discusses prohibited topics without redirecting
    """
    await _require_admin(request)

    log_ctx = {
        "tenant_id": req.tenant_id,
        "endpoint": "/policies",
        "request_id": request.headers.get("X-Request-ID", ""),
    }

    policy = CustomPolicy(
        policy_id="",   # auto-assigned by add_policy()
        tenant_id=req.tenant_id,
        created_by=req.created_by,
        policy_type=req.policy_type,
        name=req.name,
        description=req.description,
        enabled=req.enabled,
        severity=req.severity,
        config=req.config,
    )

    try:
        mgr = PolicyManager()
        saved = await _run_in_executor(mgr.add_policy, policy)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={"error": "validation_failed", "message": str(exc)},
        )
    except Exception as exc:
        logger.error("create_policy failed: %s", exc, exc_info=True, extra=log_ctx)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "storage_error", "message": str(exc)},
        )

    logger.info(
        "Policy created: id=%s type=%s tenant=%s",
        saved.policy_id, saved.policy_type, saved.tenant_id,
        extra=log_ctx,
    )
    return JSONResponse(
        content={"policy": saved.to_dict()},
        status_code=status.HTTP_201_CREATED,
    )


@app.get("/policies", summary="List custom policies for a tenant (admin)")
async def list_policies_endpoint(
    tenant_id: str = "default",
    request: Request = None,
) -> JSONResponse:
    """
    List all custom policies for a tenant (enabled and disabled).

    Requires X-Admin-Key header.
    """
    await _require_admin(request)

    mgr = PolicyManager()
    policies = await _run_in_executor(mgr.list_policies, tenant_id)

    return JSONResponse(content={
        "tenant_id": tenant_id,
        "count": len(policies),
        "policies": [p.to_dict() for p in policies],
    })


@app.delete("/policies/{policy_id}", summary="Remove a custom policy (admin)")
async def delete_policy(
    policy_id: str,
    tenant_id: str = "default",
    request: Request = None,
) -> JSONResponse:
    """
    Remove a custom policy by ID.

    Requires X-Admin-Key header.
    Returns 404 if the policy_id is not found for the given tenant.
    """
    await _require_admin(request)

    log_ctx = {
        "tenant_id": tenant_id,
        "endpoint": f"/policies/{policy_id}",
        "request_id": request.headers.get("X-Request-ID", ""),
    }

    mgr = PolicyManager()
    removed = await _run_in_executor(mgr.remove_policy, policy_id, tenant_id)

    if not removed:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "not_found",
                "message": f"Policy {policy_id!r} not found for tenant {tenant_id!r}.",
            },
        )

    logger.info("Policy removed: id=%s tenant=%s", policy_id, tenant_id, extra=log_ctx)
    return JSONResponse(content={"deleted": True, "policy_id": policy_id})


@app.post("/monitor-action", summary="Evaluate an agent action for anomalies")
async def monitor_action(req: MonitorActionRequest, request: Request) -> JSONResponse:
    """
    Evaluate one agent action for anomalies without modifying any conversation score.

    Checks (in priority order):
      - Hard stop: delete/transfer/send when agent_config.hard_stop=True → block immediately
      - Unauthorized: action_type not in agent's allowed_actions from Builder
      - Irreversible under pressure: send/delete/transfer when Tier 1 conversation
        pressure is elevated (threshold for blocking is lowered by pressure level)
      - Out-of-scope data access: data_access target outside tenant_boundary
      - Parameter anomaly: parameters differ significantly from action_baseline
      - Severity escalation: action severity jumped more than one level vs prior actions

    Returns recommended_action: allow | block | require_approval | alert.
    When hard_stop=true in the response the action is blocked unconditionally.
    """
    config = _get_tenant_config(req.tenant_id)
    await _check_rate_limit(req.tenant_id, "monitor-action", config.monitor_rpm)

    request_id = request.headers.get("X-Request-ID", "")
    log_ctx = {
        "tenant_id": req.tenant_id,
        "conversation_id": req.conversation_id,
        "agent_id": req.agent_id or "",
        "request_id": request_id,
        "endpoint": "/monitor-action",
    }

    # Convert Pydantic models to the dataclass/dict types expected by drift_monitor
    action = AgentAction(
        action_type=req.action.action_type,
        target=req.action.target,
        parameters=req.action.parameters,
        timestamp=req.action.timestamp,
        conversation_turn=req.action.conversation_turn,
    )
    agent_config_dict = {
        "allowed_actions":    req.agent_config.allowed_actions,
        "tenant_boundary":    req.agent_config.tenant_boundary,
        "action_baseline":    req.agent_config.action_baseline,
        "hard_stop":          req.agent_config.hard_stop,
        "prior_action_types": req.agent_config.prior_action_types,
    }
    conversation = _conversation_to_dicts(req.conversation)

    t0 = time.monotonic()

    try:
        result: AgentActionResult = await _run_in_executor(
            monitor_agent_action,
            req.tenant_id,
            req.conversation_id,
            req.agent_id or "",
            action,
            conversation,
            agent_config_dict,
        )
    except Exception as exc:
        logger.error(
            "monitor_agent_action failed: %s", exc, exc_info=True, extra=log_ctx
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "action_monitor_failed", "message": str(exc)},
        )

    total_ms = round((time.monotonic() - t0) * 1000, 1)

    logger.info(
        "Action monitor: action_type=%s recommended=%s risk=%s anomaly=%s",
        action.action_type,
        result.recommended_action,
        result.risk_level,
        result.anomaly_type or "none",
        extra={
            **log_ctx,
            "action": result.recommended_action,
            "risk_level": result.risk_level,
            "duration_ms": total_ms,
        },
    )

    remaining = await _rate_limiter.remaining(
        req.tenant_id, "monitor-action", config.monitor_rpm,
        window_seconds=_RATE_LIMIT_WINDOW_SECONDS,
    )

    response_body = {
        "conversation_id": req.conversation_id,
        "tenant_id": req.tenant_id,
        "agent_id": req.agent_id,
        "processing_time_ms": total_ms,
        "result": result.to_dict(),
    }
    return JSONResponse(
        content=response_body,
        headers={"X-RateLimit-Remaining": str(remaining)},
    )


# ── Development server ────────────────────────────────────────────────────────

if __name__ == "__main__":
    try:
        import uvicorn
    except ImportError:
        raise ImportError(
            "uvicorn is required to run drift_api.py directly.\n"
            "Install with: pip install uvicorn"
        )

    uvicorn.run(
        "drift_api:app",
        host=os.environ.get("DRIFT_API_HOST", "0.0.0.0"),
        port=int(os.environ.get("DRIFT_API_PORT", "8000")),
        reload=os.environ.get("DRIFT_API_RELOAD", "false").lower() == "true",
        log_config=None,   # Use our structured logger instead of uvicorn's default
    )
