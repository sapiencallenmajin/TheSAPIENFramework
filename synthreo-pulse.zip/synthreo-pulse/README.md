Scoring methodology based on the SAPIEN Behavioral Safety Framework — https://github.com/sapiencallenmajin/TheSAPIENFramework
